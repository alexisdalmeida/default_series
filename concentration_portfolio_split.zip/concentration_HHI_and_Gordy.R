





compute_capital_mult<- function(excl_flag, method, use_exp_total, data_bank, exposure_total, capital_p1 ){
  
  # remove high and low PD values
  if( max(data_bank$pd)>.95){data_bank<- data_bank[ -which(data_bank$pd>.95), ]}
  if( min(data_bank$pd)==0){data_bank<- data_bank[ -which(data_bank$pd==0), ]}
  # remove low exposure values smaller than 0.5m
  if( min(data_bank$exposure)<0.5){data_bank<- data_bank[ -which(data_bank$exposure<0.5), ]}
  
  
  # define the exposure total - either the exposure total provided by the bank or the sum of the exp vector
  if(use_exp_total == 'yes'){
    exposure_total_adj<- exposure_total
    rwa_total_adj<- capital_p1 / 0.105
  }else{
    exposure_total_adj<- sum(data_bank$exposure)
    rwa_total_adj<- sum(data_bank$rwa)
  }
  
  # define the exclusions
  
  if(excl_flag == 'yes'){
    # order accordingly
    data_bank<- data_bank[ order(-data_bank$exposure_after_exclusions)    , ]
    
    exposure_vect<- data_bank$exposure_after_exclusions
    exclusions<- sum(data_bank$exclusions)
    exposure_total_adj<- exposure_total_adj - exclusions
    
    rwa_exclusions<- data_bank$exclusions / data_bank$exposure * data_bank$rwa
    rwa_vect<- data_bank$rwa - rwa_exclusions
    rwa_total_adj <- rwa_total_adj - sum(rwa_exclusions)
    
  }else{
    # order accordingly
    data_bank<- data_bank[ order(-data_bank$exposure)    , ]
    
    exposure_vect<- data_bank$exposure
    rwa_vect<- data_bank$rwa
  } 
  
  
  # compute the hhi index and map against the regulatory tables
  if( method == 'hhi_sp_0.25' ){
    n<- min(length(exposure_vect), 1000)
    hhi<- sum(exposure_vect[1:n]^2) / exposure_total_adj^2 * 100
    y<- hhi_mult$spanish_mult_0.25
    x<- hhi_mult$hhi
    temp1<- lapply(hhi, function(blah){approx(x, y, xout=blah)})
    capital_mult<- temp1[[1]]$y
    ga_mult <- NA # GA is NA since it is the the gordi method
    
  }else if( method =='hhi_sp_0.5' ){
    n<- min(length(exposure_vect), 1000)
    hhi<- sum(exposure_vect[1:n]^2) / exposure_total_adj^2 * 100
    y<- hhi_mult$spanish_mult_0.5
    x<- hhi_mult$hhi
    temp1<- lapply(hhi, function(blah){approx(x, y, xout=blah)})
    capital_mult<- temp1[[1]]$y
    ga_mult <- NA # GA is NA since it is the the gordi method
    
  }else if( method =='hhi_uk' ){
    
    hhi<- sum(rwa_vect^2) / rwa_total_adj^2 * 100
    y<- hhi_mult$uk_mult
    x<- hhi_mult$hhi
    temp2<- lapply(hhi, function(blah){approx(x, y, xout=blah)})
    capital_mult<- temp2[[1]]$y
    ga_mult <- NA
    
  }else if( method =='gordi' ){
    
    pd_vect<- data_bank$pd
    lgd_vect<-data_bank$lgd
    m_vect<- data_bank$tenor_corrected
    s_vect<-  exposure_vect/sum(exposure_vect)
    s_sqr_vect<- ( exposure_vect/sum(exposure_vect) ) ^2
    v_lgd_vect<- lgd_vect * (1-lgd_vect) * lgd_vol
    c_vect<- (v_lgd_vect + lgd_vect^2)/lgd_vect
    r_vect<- lgd_vect * pd_vect
    
    rho_vect<- 0.12 * (1-exp(-50 * pd_vect )) / (1-exp(-50)) + 0.24 * (1-(1-exp(-50 *pd_vect)))/(1-exp(-50) )
    b_vect<- (0.11852 - 0.05478 * log(pd_vect))^2
    
    part1<- lgd_vect * pnorm(qnorm( pd_vect)*(1-rho_vect)^-0.5+qnorm(alpha_perc)*(rho_vect/(1-rho_vect))^ 0.5) - pd_vect * lgd_vect 
    part2<-  (1 + (m_vect- 2.5)*b_vect) / (1-1.5 * b_vect)
    k_vect<- part1 * part2
    
    ga_vect<- s_sqr_vect * c_vect * (delta_adj * (k_vect + r_vect) - k_vect )
    ga_vect<- ifelse(is.nan(ga_vect),0,ga_vect)
    k_star<- sum(k_vect* s_vect)
    ga_mult<- 1/(2 * k_star) * sum(ga_vect) 
    
    capital_mult <-  ga_mult * exposure_total_adj / capital_p1
    hhi<- NA
  } 
  
  prop_exp<-  cumsum(exposure_vect/sum(exposure_vect))
  exp_top5<- prop_exp[5]
  exp_top20<- prop_exp[20]
  num_exp50pc<- which( min( abs(0.5-prop_exp))== abs(0.5-prop_exp)  )
  
  ead<- sum(exposure_vect)
  result<- data.frame(capital_mult, hhi, ga_mult, exp_top5, exp_top20, num_exp50pc, exposure_total_adj, ead)
  return(result)
}




compute_metrics<- function(excl_flag, use_exp_total, data_bank, exposure_total, capital_p1 ){

  # remove high PD values
  if( max(data_bank$pd)>.95){data_bank<- data_bank[ -which(data_bank$pd>.95), ]} 
  
  # define the exposure total - either the exposure total provided by the bank or the sum of the exp vector
  if(use_exp_total == 'yes'){
    exposure_total_adj<- exposure_total
  }else{
    exposure_total_adj<- sum(data_bank$exposure)
  }
  
  # define the exclusions
  
  if(excl_flag == 'yes'){
    data_bank<- data_bank[ order(-data_bank$exposure_after_exclusions)    , ]
    
    exposure_vect<- data_bank$exposure_after_exclusions
    exclusions<- sum(data_bank$exclusions)
    exposure_total_adj<- exposure_total_adj - exclusions
  }else{
    data_bank<- data_bank[ order(-data_bank$exposure)    , ]
    
    exposure_vect<- data_bank$exposure
  } 

  # compute HHI
  n<- min(length(exposure_vect), 1000)
  hhi_1000<- sum(exposure_vect[1:n]^2) / exposure_total_adj^2 * 100
  
  n<- length(exposure_vect)
  hhi<- sum(exposure_vect[1:n]^2) / exposure_total_adj^2 * 100
  
  # compute 
  prop_exp<-  cumsum(exposure_vect/exposure_total_adj)
  exp_top5<- prop_exp[5]
  exp_top20<- prop_exp[20]
  acc_num<- length(exposure_vect)
  #num_exp50pc<- which( min( abs(0.5-prop_exp))== abs(0.5-prop_exp)  )
  
  result<- data.frame(hhi_1000, hhi,exp_top5, exp_top20,acc_num)
  return(result)
  
}

