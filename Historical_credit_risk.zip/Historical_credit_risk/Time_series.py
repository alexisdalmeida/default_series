# -*- coding: utf-8 -*-
"""
Created on Wed Dec 24 13:35:24 2025


"""

import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d


#Import files
path1 = "C:/Users/alexis.dalmeida/Documents/Python/Historical_credit_risk/data/ADIB"


file = "/Perf_Corp_ADIB.csv"
temp = path1 + file
data = pd.read_csv(temp)

# Get headers as a list

 = list(data.columns)

# Convert to date type and sort by dates
data['Reporting date (DD/MM/YYYY)']  = pd.to_datetime(data['Reporting date (DD/MM/YYYY)'] ,format = "%d/%m/%Y" )
data = data.sort_values(by='Reporting date (DD/MM/YYYY)')

# Create a vector of dates
dates_vect = data['Reporting date (DD/MM/YYYY)']
dates_vect = pd.to_datetime(dates_vect,format = "%d/%m/%Y" )
dates_vect.sort_values()
dates_unique = dates_vect.unique()
segment_vect = data['Portfolio Segmentation used by the Bank at Reporting Date'].unique()


# ===========  Segment analysis =========


pd.pivot_table(data, 
               values='CustomerID', 
               index='Portfolio Segmentation used by the Bank at Reporting Date', 
               columns= 'Reporting date (DD/MM/YYYY)', 
               aggfunc= 'count',    
               fill_value=0)  




# ==========  Get default data ==========


# select LC only
data_sub = data[data['Portfolio Segmentation used by the Bank at Reporting Date']== 'LARGE CORPORATE' ]
# get total list of clients
customer_vect_unique = data_sub['CustomerID'].unique()
type(customer_vect_unique)
customer_total=len(customer_vect_unique)
dates_unique

# === Create a large matrix to be populated with defaults
df_def = pd.DataFrame(None, index=customer_vect_unique, columns=dates_unique)

# populate the matrix with 0 and 1
for i in range(0,len(dates_unique)-1):
    # cut data at a given date
    data_cut_date = data_sub[ (data_sub['Reporting date (DD/MM/YYYY)']== dates_unique[i])]
    # create a small df just with ID and default
    a = data_cut_date['CustomerID']
    b = data_cut_date['Default Flag at Reporting Date (if any of the facilities is in default, then Customer should be tagged as 1, else 0)']
    df_default_flag = pd.DataFrame({'CustomerID': a, 'Def_flag': b})
    # populate the matrix with the default at a given date
    x= df_default_flag['CustomerID']
    df_def.loc[ x, dates_unique[i] ] = df_default_flag[ 'Def_flag'].values

print(df_def)

# === Adjust the default to take the first default event only

# Duplicate the data frame
df_def_adj = df_def.copy()
N = len(dates_unique)-1 # used as position refrence
# 
nCure = 12
# loop through the matrix
for iCust in range(0,customer_total-1):
        for jDate in range(0,N-1): # stop at N-1 because of the forward loop
            
        # loop back over the cure, in case of default
            if df_def.iloc[iCust,jDate ] == 1:
                
                for k in range(1,min(nCure, N-jDate ) +1):
                    if df_def.iloc[ iCust,jDate+k ]  == 1:
                        df_def_adj.iloc[ iCust,jDate+k ]  = 0

# check
jDate = 0
iCust = 4
df_def_adj.iloc[ iCust, ].values

# export the default matrices
path2 = "C:/Users/alexis.dalmeida/Documents/Python/Historical_credit_risk/output"
file = "/Perf_Corp_out.csv"
temp = path2 + file
data = df_def.to_csv(temp, index=False)

path2 = "C:/Users/alexis.dalmeida/Documents/Python/Historical_credit_risk/output"
file = "/Perf_Corp_out_2.csv"
temp = path2 + file
data = df_def_adj.to_csv(temp, index=False)


# == Create a time series of default by using the maxtrix above

# = first get the exposure
for i in range(0,len(dates_unique)):
    # Subset of the data - surrent date
    data_sub = data[ (data['Reporting date (DD/MM/YYYY)']== dates_unique[i]) &
                     (data['Portfolio Segmentation used by the Bank at Reporting Date']== 'LARGE CORPORATE') ]

    exposure_total = np.sum( data_sub['Total Outstanding Balance at Reporting Date (for Revolving facilities only)'])
 
    # create df with the sums
    data_temp = {
        'date': [dates_unique[i]],
        'exposure_total': [exposure_total],
    }
    df_temp = pd.DataFrame(data_temp)

    # concatenate
    if i == 0:   
        df_exp = df_temp
    else:
        df_exp = pd.concat([df_exp, df_temp], axis=0)

# Align the index
df_exp.index = dates_unique


# ======= compute default rates
df_def_adj.sum(axis=0)
a = (df_def_adj == 0).sum(axis=0)
b = (df_def_adj == 1).sum(axis=0)
c = df_def_adj.isna().sum(axis=0)
# Check
a+b+c

# ======= prepare a df
data_temp = {
    'cases_def': b,
    'cases_non_def': a,
    'cases_total': a+b,
    'exposure_total': df_exp['exposure_total'].values,
}
df_series = pd.DataFrame(data_temp)
print(df_series)

# == export
df_series = df_series.reset_index() #move the index to the first col
path2 = "C:/Users/alexis.dalmeida/Documents/Python/Historical_credit_risk/output"
file = "/Perf_Corp_out_series_3.csv"
temp = path2 + file
data = df_series.to_csv(temp, index=False)


# ==== new default based on DPD

data['DPD derived default'] =  (data['Maximum Current Delinquency status in DPD at Reporting Date '] >90).astype(int)





# =================================
# =========== Old code


#loop through dates

data_sub_previous_date = pd.DataFrame()
for i in range(0,len(dates_unique)-1):

    # Subset of the data - surrent date
    data_sub = data[ (data['Reporting date (DD/MM/YYYY)']== dates_unique[i]) &
                     (data['Portfolio Segmentation used by the Bank at Reporting Date']== 'LARGE CORPORATE') ]
    
    # compare
    if i>0 : 
        a = data_sub_previous_date[ data_sub_previous_date['Default Flag at Reporting Date (if any of the facilities is in default, then Customer should be tagged as 1, else 0)'  ] == 1]['CustomerID']
        b = data_sub[ data_sub['Default Flag at Reporting Date (if any of the facilities is in default, then Customer should be tagged as 1, else 0)'  ] == 1]['CustomerID']
        overlap = set(a) & set(b) 
        overlap_number = len(overlap)

    # sum aross customer for the given date 
    exposure_total = np.sum( data_sub['Total Outstanding Balance at Reporting Date (for Revolving facilities only)'])
    cases_def = np.sum( data_sub['Default Flag at Reporting Date (if any of the facilities is in default, then Customer should be tagged as 1, else 0)'])
    cases_def = cases_def - overlap_number
    cases_total = len( data_sub['CustomerID'])
    
    # create df with the sums
    data_temp = {
        'date': [dates_unique[i]],
        'exposure_total': [exposure_total],
        'cases_def': [cases_def],
        'cases_total': [cases_total]
    }
    df_temp = pd.DataFrame(data_temp)
    
  
    # concatenate
    if i == 0:   
        df = df_temp
    else:
        df = pd.concat([df, df_temp], axis=0)
          
    # populate the data for previous date at the end of the loop 
    data_sub_previous_date = data_sub

# === end of the for loop