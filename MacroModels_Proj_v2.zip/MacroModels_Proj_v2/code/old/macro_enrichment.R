
library(xts)
library(quantmod)
library(forecast)
library(car)
library(lmtest)
library(data.table)

#********************************************************************************
#************* PART1: FILE CONSTRUCTION  *******************************************************

#  extract and clean data
#path1<- "//Fileprintho/Deptfolders/Credir Risk Management/model validation/06. Macroeconomics/8. Macro Enrichment/R_code/"
#path1<- "C:/Users/006804/Documents/9. macro_model/"

path1<- "~/R/Enrichment_Proj/data"

file<- "/macro.csv"
path2<- paste( path1, file, sep=""  )
DF <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
DF$date<- as.Date(DF$date, format='%d/%m/%y')
mdf<- as.xts(DF[-1], order.by = DF$date)
x11()
plot(mdf$x_2) ; lines(mdf$x_3, col='black') ; lines(mdf$x_4, col='red')
#file<- "variable_list.csv"
#path3<- paste( path1, file, sep=""  )
#DF_list <- read.csv(path3, stringsAsFactors=FALSE, check.names = TRUE)

#smooth roocupancy occupancy upfront
smooth<- rollmean(na.omit(mdf$x_2), 4) #; mdf$room_occ_AD_base[index(smooth)]<-smooth  
smooth<- rollmean(na.omit(mdf$x_2), 4) #; mdf$room_occ_DB_base[index(smooth)]<-smooth 
smooth<- rollmean(na.omit(mdf$x_2), 4) #; mdf$room_occ_AD_stress[index(smooth)]<-smooth 
smooth<- rollmean(na.omit(mdf$x_2), 4) #; mdf$room_occ_DB_stress[index(smooth)]<-smooth ;
plot(na.omit(mdf$x_2) ) ;lines(smooth)


#extract macro, separate between levels and perc
select_level<- DF_list$Scenario[DF_list$Scen_type =='base' & DF_list$Type == 'level'  ]
m_sub_level<- mdf[,select_level] ; ncol(m_sub_level) ; names(m_sub_level) ; ncol(m_sub_level) # select macro
select_perc<- DF_list$Scenario[DF_list$Scen_type =='base' & DF_list$Type == 'perc'  ]
m_sub_perc<- mdf[,select_perc] ; ncol(m_sub_perc) ; names(m_sub_perc) ; ncol(m_sub_perc)  # select macro
#compute returns on levels
m_ret<- apply(m_sub_level,2,function(x){ Delt(x, k=4, type="arithmetic")}) # compute returns
m_ret<- as.xts(m_ret, order.by = DF$date)
#merge
m<- cbind(m_ret, m_sub_perc ) ; names(m) ; ncol(m)
#compute abs return on gov balance to GDP
gb<- m$Gov_BaltoGDP_base ; dgb<- diff(gb, 4) #; plot(dgb) ; lines(gb)
m$Gov_BaltoGDP_base[index(dgb)]<- dgb
# remove duplicated base
remove<- match(c('ECI_base', 'ECI_nonOil_base', 'Oil_Brent_base', 'CPI_base') , names(m)   )
m_noduplicate<- m[,-remove] ; names(m_noduplicate)

# extract macro, separate between cbuae and moody's

# m containts similar variables between cbuae and moodys - return
source<- DF_list$Source[ match( names(m) , DF_list$Scenario  )] 
cb<- m[ ,which(source == 'CBUAE')] ; mo<-  m[ ,which(source == 'Moodys')] #contain base only

# get the past data - return
par(mfrow=c(2,1))
cb_past<- cb[ "1990-03-01/2017-12-01"]; mo_past<- mo[ "1990-03-01/2017-12-01"] #selecting only the past
plot(na.omit(cb_past$eci_chg_base)) ; lines(na.omit(mo_past$GDP_base), col='red') #check

# == get the base and stress forecast
#first get the level and perc
select_level<- DF_list$Scenario[DF_list$Scen_type =='stress' & DF_list$Type == 'level'  ]
m_sub_level<- mdf[,select_level] ; ncol(m_sub_level) ; names(m_sub_level) ; ncol(m_sub_level) # select macro
select_perc<- DF_list$Scenario[DF_list$Scen_type =='stress' & DF_list$Type == 'perc'  ]
m_sub_perc<- mdf[,select_perc] ; ncol(m_sub_perc) ; names(m_sub_perc) ; ncol(m_sub_perc)  # select macro
#compute returns on levels
m_ret<- apply(m_sub_level,2,function(x){ Delt(x, k=4, type="arithmetic")}) # compute returns
m_ret<- as.xts(m_ret, order.by = DF$date)
#merge - return
cb_stress<- cbind(m_ret, m_sub_perc ) ; names(cb_stress) 
plot(na.omit(cb_stress$oil_stress)) ; lines(na.omit(cb$oil_base), col='red') #check
plot(na.omit(cb_stress$re_AD_stress)) ; lines(na.omit(cb$re_AD_base), col='red') #check
# extract CBUAE forecast only
cb_f_stress<- cb_stress[ "2016-03-01/2020-12-01"]
cb_f_base  <- cb[ "2016-03-01/2020-12-01"]
cb_past
mo_past


#********************************************************************************
#************* PART2: INVESTIGATION  *******************************************************
par(mfrow=c(1,1))
# ==== Investigation : Projecting Moody's with simple reg===
# parameters
mo_numb<- 1 # macro variable number
#univ
Y<- mdf[,mo_numb] ; 
macro<- mdf[ , -c(1:7)]
macro<- macro[ , c(1:10)]
#macro2<- macro[order(index(macro)),  ] 
  
names(Y) ; print(mo_name) ; acf(na.omit(Y))

a<- univariate(d=macro, Y=Y , pos=TRUE )
#multireg
r<- multireg_simple(univ_sort = a, d=cb_past, Y=Y)
r_sort<- r[order(-r$Rsq_vect),]
# remove negative coef
r_sort<- r_sort[ -c( which(r_sort$coef_vect1<0), which(r_sort$coef_vect2<0) ),  ]
r_sort<- r_sort[ -c( which(r_sort$p_vect1>0.15), which(r_sort$p_vect2>0.15)),  ]
r_sort<- cbind( 1:nrow(r_sort), r_sort)
# plot background chart
mo_stress<- mo_stress_store
plot(mo_stress[, mo_name], main=mo_name)
# predict and plot
start<- 1 ; end<- nrow(r_sort) #model number
out<- pred_multireg(start=start, end=end, colour='red', r_sort=r_sort, case_flag='stress', Y=Y) ; predicted<- out[[1]] ; fitted<- out[[2]]
lines(predicted, col='red', lwd = 3) ; lines(fitted, col='blue', lwd = 1) ; r_sort[start, ]

# == Check selection of multireg
model_num<-37 ; lines(predicted,col='purple', lwd = 4)
x1<- cb_past[ ,toString(r_sort$name_vect1[model_num]) ] ; x2<- cb_past[ ,toString(r_sort$name_vect2[model_num]) ]
l1<- r_sort$Lag_vect1[model_num] ; l2<- r_sort$Lag_vect2[model_num]
#construct model
mer<- merge( Y , lag(x1,l1), lag(x2, l2)) ; mer<- na.omit(mer)
fit<- lm(mer[,1]~ mer[,2]+mer[,3])
# check rsq equality
r_sort$Rsq_vect[model_num] == summary(fit)$r.squared
# check error terms and test
mer_err<- na.omit(merge(Y, fit$fitted.values)) ; err<- mer_err[,2]-mer_err[,1] 
acf<- acf(err,plot = TRUE)$acf 
validation_test(fit=fit, mer=mer)

# ======================================================
# ==== Investigation: Projecting Moody's with Arimax ===
mo_numb<- 9 # macro variable number
# plot background
Y<- mo_past[,mo_numb] ; mo_name<- names(Y) 
plot(mo_stress[, mo_name], main=mo_name)
#univ
a<- univariate(d=cb_past, Y=Y , pos=TRUE )
# arimax
r<- arimax(univ_sort = a, d=cb_past, Y=Y, inter=TRUE)
r_sort<- r[order(-r$Rsq_vect),]
# remove negative coef
r_sort<- r_sort[ -c( which(r_sort$coef_vect2<0), which(r_sort$coef_vect3<0)),  ]
r_sort<- r_sort[ -c( which(r_sort$p_vect2>0.15), which(r_sort$p_vect3>0.15)),  ]
r_sort<- cbind( 1:nrow(r_sort), r_sort) ; r_sort
# predict and plot
start<- 1 ; end<- nrow(r_sort)#model number
out2<- pred_arimax(start=start, end=end, colour='green', r_sort=r_sort, case_flag='stress', Y=Y) ; predicted<- out2[[1]] ; fitted<- out2[[2]]
lines(predicted, lwd = 3) ; lines(fitted, col='blue', lwd = 2) ; 
#### choose lowest point
low<- apply(predicted["2017-03-01/2019-03-01"], 2, min); dfm<- data.frame(low, model_num<- 1:ncol(predicted)) ; names(dfm)<- c('low','model_num')
dfm_sort<- dfm[order(dfm$low, decreasing = TRUE),] 
q1<- quantile(dfm_sort$low, .45) ; q2<- quantile(dfm_sort$low, .55) 
n1<- which.min(abs(dfm_sort$low - q1)) ; n2<- which.min(abs(dfm_sort$low - q2)) 
model_range<- dfm_sort[n1:n2,]
# plot again
plot(mo_stress[, mo_name], main=mo_name)
for (k in 1:nrow(model_range)){
  num<- model_range[k,2] ; end<- start
  lines(predicted[,num], col=k,lwd = 3) ; lines(fitted[,num], col=k, lwd = 1) 
}
lines(predicted[,num], col=k,lwd = 3)
r_sort[model_range$model_num,] #list of models

# == Check selection of Arimax
model_num<-11 ; lines(predicted[,model_num],col='purple', lwd = 4)
x2<- cb_past[ ,toString(r_sort$name_vect2[model_num]) ] ; x3<- cb_past[ ,toString(r_sort$name_vect3[model_num]) ]
l2<- r_sort$Lag_vect2[model_num] ; l3<- r_sort$Lag_vect3[model_num]
#construct model
mer<- merge( Y , lag(Y,1), lag(x2,l2), lag(x3, l3)) #; plot.xts(lag(x2,4)) ; lines(x2)
mer<- na.omit(mer)
fit<- lm(mer[,1]~ mer[,2]+mer[,3]+mer[,4])
# check rsq equality
r_sort$Rsq_vect[model_num] == summary(fit)$r.squared
# check error terms and test
mer_err<- na.omit(merge(Y, fit$fitted.values)) ; err<- mer_err[,2]-mer_err[,1] 
acf<- acf(err,plot = TRUE)$acf 
validation_test(fit=fit, mer=mer)
# plot
lines(predicted[,model_num],col='purple', lwd = 2)

# =========================================================
# ==== Investigation: Projecting Moody's with ARIMAX_2 ===

mo_numb<-4 # macro variable number
# plot background
Y<- mo_past[,mo_numb] ; mo_name<- names(Y) 
plot(mo_stress[, mo_name], main= sub('_base','', mo_name)  )
#plot(mo_stress$ECI_base/100, main= sub('_base','', mo_name) , col='blue' )
#lines(mo_stress$GDP_base, col='black')
#addLegend( legend.loc ='topright', legend.names= c('GDP growth', "ECI growth"), col=c('black', 'red'), lwd=2)
#addlegend( 'topright', legend= 'fsfsd', col='red', lwd=2)

#univ
a<- univariate(d=cb_past, Y=Y , pos=TRUE )
# arimax2
onlyAR2<- FALSE
out3<- arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=0.2, onlyAR2 = onlyAR2, cb_f_stress=cb_f_stress, cb_f_base=cb_f_base, box_cut=.01)
modlist<- out3[[1]]; predicted<- out3[[3]] ; fitted<- out3[[4]]
# plot
lines(predicted, lwd = 2) ; lines(fitted, col='blue', lwd = 2) ; print(modlist)
#### choose lowest point
low<- apply(predicted["2017-03-01/2020-09-01"], 2, min); dfm<- data.frame(low, modlist$count_vect) ; names(dfm)<- c('low','model_num')
dfm_sort<- dfm[order(dfm$low, decreasing = TRUE),] 
q1<- quantile(dfm_sort$low, .0) ; q2<- quantile(dfm_sort$low, .45) 
n1<- which.min(abs(dfm_sort$low - q1)) ; n2<- which.min(abs(dfm_sort$low - q2)) 
model_range<- dfm_sort[n1:n2,]
# plot again
plot(mo_stress[, mo_name], main=mo_name)
for (k in 1:nrow(model_range)){
  num<- model_range[k,2] ; end<- start
  predicted<- out3[[3]] ; fitted<- out3[[4]]
  lines(predicted[,num], col=k,lwd = 3) ; lines(fitted[,num], col='blue', lwd = 1) 
}
lines(predicted[,model_range[1,2]],col=k, lwd = 3)

#  Check selection of ARIMAX2
model_num<-3
x1<- cb_past[ ,toString(modlist$name_vect1[model_num]) ] ; x2<- cb_past[ ,toString(modlist$name_vect2[model_num]) ]
l1<- modlist$Lag_vect1[model_num] ; l2<- modlist$Lag_vect2[model_num]
#construct model
mer<- merge( Y , lag(x1,l1), lag(x2, l2)) #; plot.xts(lag(x2,4)) ; lines(x2)
mer<- na.omit(mer)
if(onlyAR2==TRUE){fit<- arima(mer[,1], order=c(2,0,0),xreg = mer[,2:3])
}else{fit<- auto.arima(mer[,1],  xreg = mer[,2:3]) }   
fit<- arima(mer[,1], order=c(2,1,0), xreg = mer[,2], include.mean = FALSE) 
# check rsq
y_fitted<- as.xts(as.numeric( fit$residuals) + as.numeric(mer[,1]), index(mer) )
as.numeric(cor( as.numeric(y_fitted), as.numeric(mer[,1]))^2) == modlist$Rsq_vect[model_num]
# TEST model
mer_err<- na.omit(merge(Y, fitted[,model_num])) ; err<- mer_err[,2]-mer_err[,1] 
acf<- acf(err,plot = TRUE)$acf ; dw<- sum( na.omit((err-lag(err,1))^2))/sum(err^2) ; print(dw) 
validation_test(fit=fit, mer=mer)
# plot
lines(predicted[,model_num],col='purple', lwd = 3)

get_param_and_test_arimax2(modlist=modlist, model_num=model_num, cb_past=cb_past, Y=Y, onlyAR2=onlyAR2 )

c<- coeftest(fit) 

#********************************************************************************
#************* PART3: SELECTION  *******************************************************


#initialise final recipient for Moody's data and remove dates beyond 2020: recipients are mo_base and mo_stress
mo_stress<- mo 
end<- which( index(mo_stress)=="2021-03-01") ; mo_stress<- mo_stress[-c(end:nrow(mo_stress)) , ] # end date
first<- "2001-03-01" ; n<- which( index(mo_stress)==first) ; mo_stress<- mo_stress[-c(1:n) , ] # start date
mo_base<- mo_stress ; mo_stress_store<- mo_stress ; mo_base_store<-mo_base ; names(mo_base)
mo_fitted<- mo_base["2001-03-01/2017-12-01"]
#initialise model recipient
Y<- mo_past[,2] ; a<- univariate(d=cb_past, Y=Y , pos=TRUE ) 
out<- arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=0.30, onlyAR2 = TRUE, cb_f_stress=cb_f_stress, cb_f_base=cb_f_base, box_cut=.05) ; modlist<- out[[1]]
model_mat<- get_param_and_test_arimax2(modlist=modlist, model_num=1, cb_past=cb_past, Y=Y, onlyAR2=TRUE ) ; model_mat[1]<-"to be removed"


# ==== GO through each variable

mo_name<- 'GDP_base' #1 - directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$eci_chg_stress ; predicted_base<- cb_f_base$eci_chg_base ; fitted<- cb_past$eci_chg_base; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"] 
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- 'Domestic_Demand_base' #2- option 3, model6
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=6, option=3, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]

mo_name<- 'ADX_base' #3 - arimax 3
#not modelled

mo_name<- 'Export_base' #4- option 4, 
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=3, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.01)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]


mo_name<- 'Private_Consumption_base' #5- option 4, model 39
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=39, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]


mo_name<- "Capital_Formation_base" #6- option 4 model 9
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num= 9, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]

mo_name<- "Gov_Consumption_base"  #7
# cannot be modelled
plot(mo_base[,mo_name], main=mo_name)
predicted_base<- as.xts(rep(0,13), index(predicted_base))
predicted_stress<- as.xts(rep(-0.05,13), index(predicted_base)) ; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) 
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]

mo_name<- "Import_base" #8- Option 4 model 30
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=11, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3) 
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]

mo_name<- "Gov_Expenditure_base"  #9- option4 model4
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=4, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.1, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]

mo_name<- "Gov_Revenue_base"  #10- Option 4 model 13 (or 6)
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=13, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.1, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]
print(toString(model_mat[2,ncol(model_mat)-1])) ; print( toString(model_mat[2,ncol(model_mat)]))

#===== # Level Inferred from gov revenue and expenditure
mo_name<- "Gov_Balance_base"  #11
plot(mdf$Gov_Balance_base["2003-12-01/2020-12-01"], main=mo_name)
# base
rev_level_b<- get_f_level(mo_name="Gov_Revenue_base", mo_ret=mo_base, mdf=mdf)  
exp_level_b<- get_f_level(mo_name="Gov_Expenditure_base", mo_ret=mo_base, mdf=mdf) 
bal_level_b<- rev_level_b - exp_level_b ; bal_level_b<- rbind(mdf$Gov_Balance_base["2006-03-01/2017-12-01"], bal_level_b)
# stress
rev_level_s<- get_f_level(mo_name="Gov_Revenue_base", mo_ret=mo_stress, mdf=mdf)  
exp_level_s<- get_f_level(mo_name="Gov_Expenditure_base", mo_ret=mo_stress, mdf=mdf) 
bal_level_s<- rev_level_s - exp_level_s ; bal_level_s<- rbind(mdf$Gov_Balance_base["2006-03-01/2017-12-01"], bal_level_s)
#fitted
bal_level_fit<- mdf$Gov_Revenue_base["2003-12-01/2020-12-01"] - mdf$Gov_Expenditure_base["2003-12-01/2020-12-01"]
# plot
lines(bal_level_b,col='blue') ; lines(bal_level_s,col='red') ; lines(bal_level_fit, col='green')
#======

mo_name<- "Real_Estate_base"  #12 Directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$re_DB_stress ; predicted_base<- cb_f_base$re_DB_base ; fitted<- cb_past$re_DB_base; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- "Expenditure_nonOil_base"  #13- option 4 model 66
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=66, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]
print(toString(model_mat[nrow(model_mat),ncol(model_mat)-1])) ; print( toString(model_mat[nrow(model_mat),ncol(model_mat)]))


mo_name<- "Expenditure_Oil_base"  #14- Option 4, model 9
plot(mo_base[,mo_name], main=mo_name)
out<- selection_full(macro_name=mo_name, model_num=9, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2, box_cut=0.05)
predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"]
print(toString(model_mat[nrow(model_mat),ncol(model_mat)-1])) ; print( toString(model_mat[nrow(model_mat),ncol(model_mat)]))

mo_name<- "Oil_WTI_base"  
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$oil_stress ; predicted_base<- cb_f_base$oil_base ; fitted<- cb_past$oil_base; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- "Oil_Brent_base"   #16- directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$oil_stress ; predicted_base<- cb_f_base$oil_base ; fitted<- cb_past$oil_base; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- "CPI_base"   #17- directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$cpi_chg_stress ; predicted_base<- cb_f_base$cpi_chg_base ; fitted<- cb_past$cpi_chg_base; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- "Current_Acc_Bal_base"  #18- Arimax 1
#not modelled

mo_name<- "Gov_BaltoGDP_base"   #19- option 4, model 1
plot(mo_base[,mo_name], main=mo_name)
#out<- selection_full(macro_name=mo_name, model_num=1, option=4, mo_base=mo_base, mo_stress=mo_stress, model_mat=model_mat, rsq_cut=0.2)
#predicted_base<- out[[1]] ; predicted_stress<- out[[2]] ; fitted<- out[[3]] ; mo_base<- out[[4]] ; mo_stress<- out[[5]] ; model_mat<- out[[6]]
#lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
#lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')
#mo_fitted["2006-03-01/2017-12-01",mo_name]<- fitted["2006-03-01/2017-12-01"] 
#print(toString(model_mat[nrow(model_mat),ncol(model_mat)-1])) ; print( toString(model_mat[nrow(model_mat),ncol(model_mat)]))
# ===inferred from gov rev and expenditure
gdp_b<- get_f_level(mo_name="GDP_base", mo_ret=mo_base, mdf=mdf) ; gdp_b<- rbind(mdf$GDP_base["2016-03-01/2017-12-01"], gdp_b   )
gdp_s<- get_f_level(mo_name="GDP_base", mo_ret=mo_stress, mdf=mdf) ; gdp_s<- rbind(mdf$GDP_base["2016-03-01/2017-12-01"], gdp_s   )
ratio_b<- bal_level_b["2016-03-01/2020-12-01"] / gdp_b *100 ; ratio_s<- bal_level_s["2016-03-01/2020-12-01"] / gdp_s *100
predicted_base<- diff(ratio_b, 4)["2017-12-01/2020-12-01"]  ; predicted_base["2017-12-01"]<- mo_base["2017-12-01",mo_name]
predicted_stress<- diff(ratio_s, 4)["2017-12-01/2020-12-01"] ; predicted_stress["2017-12-01"]<- mo_stress["2017-12-01", mo_name]
fitted<- diff( mdf$Gov_Balance_base["2001-03-01/2017-12-01"] / mdf$GDP_base["2001-03-01/2017-12-01"] * 100,4)
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"] 
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)


mo_name<- "ECI_base"   #20- directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$eci_chg_stress*100 ; predicted_base<- cb_f_base$eci_chg_base*100 ; fitted<- cb_past$eci_chg_base*100; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

mo_name<- "ECI_nonOil_base"   #21- directly mapped
plot(mo_base[,mo_name], main=mo_name)
predicted_stress<- cb_f_stress$eci_nonoil_chg_stress*100 ; predicted_base<- cb_f_base$eci_nonoil_chg_base*100 ; fitted<- cb_past$eci_nonoil_chg_base*100; 
mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress["2017-12-01/2020-12-01"]
mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base["2017-12-01/2020-12-01"]
lines(predicted_stress,col='red', lwd=3) ;lines(predicted_base,col='blue', lwd=3) ; lines(fitted,col='green', lwd=3)
lines( mo_stress[,mo_name], col='grey') ; lines( mo_base[,mo_name], col='grey')

# === full list
"GDP_base"                 "Domestic_Demand_base"     "ADX_base"                 "Export_base"             
"Private_Consumption_base" "Capital_Formation_base"   "Gov_Consumption_base"     "Import_base"             
"Gov_Expenditure_base"     "Gov_Revenue_base"         "Gov_Balance_base"         "Real_Estate_base"        
"Expenditure_nonOil_base"  "Expenditure_Oil_base"     "Oil_WTI_base"             "Oil_Brent_base"          
"CPI_base"                 "Current_Acc_Bal_base"     "Gov_BaltoGDP_base"        "ECI_base"                
"ECI_nonOil_base"   


# === Finally reconstruct levels in a final output files called mdf_stress and 
# mo_base and mo_stress (changes) --> go into mdf_base and mdf_stress (levels)

#create recipients
DF_list_mo<- DF_list[ which(DF_list$Source == "Moodys"),  ]
mdf_base<-mdf ; mdf_stress<-mdf 
mdf_base<- mdf_base[ ,DF_list_mo$Scenario ] ; mdf_stress<- mdf_stress[ ,DF_list_mo$Scenario ]
# loop through moodys variables
for (row in 1:nrow(DF_list_mo)){  
  mo_name<- DF_list_mo[row,3]
  if(DF_list_mo$Type[row]=="level" ){
    level<- mdf[ "2017-03-01/2020-12-01"  ,mo_name]
    
    #populate base
    change<- mo_base["2017-03-01/2020-12-01", mo_name] 
    mer<- merge(level,change) 
    y_pred<- as.xts(rep(0,12), order.by=index(mo_stress["2018-03-01/2020-12-01"])) 
    for (t in 1:4){y_pred[t,1]<-  as.numeric(mer[t,1]) * as.numeric((1+mer[t+4,2])) }
    for (t in 5:12){y_pred[t,1]<- as.numeric(y_pred[t-4,1]) * as.numeric((1+mer[t+4,2]))}
    mdf_base["2018-03-01/2020-12-01", mo_name]<- y_pred
    
    # populate stress
    change<- mo_stress["2017-03-01/2020-12-01", mo_name] 
    mer<- merge(level,change) 
    y_pred<- as.xts(rep(0,12), order.by=index(mo_stress["2018-03-01/2020-12-01"])) 
    for (t in 1:4){y_pred[t,1]<-  as.numeric(mer[t,1]) * as.numeric((1+mer[t+4,2])) }
    for (t in 5:12){y_pred[t,1]<- as.numeric(y_pred[t-4,1]) * as.numeric((1+mer[t+4,2]))}
    mdf_stress["2018-03-01/2020-12-01", mo_name]<- y_pred
    
  }else{
    mdf_base["2018-03-01/2020-12-01", mo_name]<-mo_base["2018-03-01/2020-12-01", mo_name]
    mdf_stress["2018-03-01/2020-12-01", mo_name]<-mo_stress["2018-03-01/2020-12-01", mo_name]
  }
  
  # === specific treatment 
  mo_name<- "Gov_Balance_base"
  mdf_base["2017-12-01/2020-12-01",mo_name]<- bal_level_b["2017-12-01/2020-12-01"]
  mdf_stress["2017-12-01/2020-12-01",mo_name]<- bal_level_s["2017-12-01/2020-12-01"]
  # === specific treatment 
  mo_name<- "Gov_BaltoGDP_base" ; level<- mdf[ "2017-03-01/2020-12-01"  ,mo_name]
  #populate base
  change<- mo_base["2017-03-01/2020-12-01", mo_name] 
  mer<- merge(level,change) 
  for (t in 1:4){y_pred[t,1]<-  as.numeric(mer[t,1]) + as.numeric(mer[t+4,2]) }
  for (t in 5:12){y_pred[t,1]<- as.numeric(y_pred[t-4,1]) + as.numeric(mer[t+4,2])}
  mdf_base["2018-03-01/2020-12-01", mo_name]<- y_pred
  # populate stress
  change<- mo_stress["2017-03-01/2020-12-01", mo_name] 
  mer<- merge(level,change) 
  for (t in 1:4){y_pred[t,1]<-  as.numeric(mer[t,1]) + as.numeric(mer[t+4,2]) }
  for (t in 5:12){y_pred[t,1]<- as.numeric(y_pred[t-4,1]) + as.numeric(mer[t+4,2])}
  mdf_stress["2018-03-01/2020-12-01", mo_name]<- y_pred
}


#==== checks ===
mo_name<- names(mo_stress)[12]
a<- mdf[,mo_name] ; a<- a["2005-03-01/2020-12-01"]
b<- mdf_base[,mo_name] ; b<- b["2005-03-01/2020-12-01"]
c<- mdf_stress[,mo_name] ; c<- c["2005-03-01/2020-12-01"]
plot( c, main=mo_name, col='red'); lines( b, col='blue') ; lines( a, col='black', lwd=2)
ret<- Delt(c, type='arithmetic', k=4) ; 
data<- na.omit(merge(ret,mo_stress[,mo_name])) ;  plot(as.numeric(data[,1]), as.numeric(data[,2]))
#check for gov balance
mm<- na.omit(merge(ratio_s, mdf_stress[,"Gov_BaltoGDP_base"]))
plot(as.numeric(mm[,1]), as.numeric(mm[,2]))

#==== Adj ret for balances ===
mo_base$Gov_Balance_base["2001-06-01/2020-12-01"]<- diff(mdf_base$Gov_Balance_base["2001-06-01/2020-12-01"], 4)
mo_stress$Gov_Balance_base["2001-06-01/2020-12-01"]<- diff(mdf_stress$Gov_Balance_base["2001-06-01/2020-12-01"], 4)
mo_fitted$Gov_Balance_base["2006-06-01/2017-12-01"]<- diff(mdf_stress$Gov_Balance_base["2006-06-01/2017-12-01"], 4)


mo_base$Gov_BaltoGDP_base["2001-06-01/2020-12-01"]<- diff(mdf_base$Gov_BaltoGDP_base["2001-06-01/2020-12-01"], 4)
mo_stress$Gov_BaltoGDP_base["2001-06-01/2020-12-01"]<- diff(mdf_stress$Gov_BaltoGDP_base["2001-06-01/2020-12-01"], 4)
mo_fitted$Gov_BaltoGDP_base["2006-06-01/2017-12-01"]<- diff(mdf_stress$Gov_BaltoGDP_base["2006-06-01/2017-12-01"], 4)

#== individual charts
par(mfrow=c(1,2))
#return
ind<- index( mo_base[,n]) ; s<- seq.int(from =1 , to=78, by=4 )
plot( mo_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(yoy absolute change)')) 
lines(mo_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) 
g<- lines(mo_fitted[,n], col='blue') 
#level
plot( mdf_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(level)')) 
g1<- lines(mdf_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) 
print(g) ; print(g1)
# level for private consumption
tp<- mdf_base[,n] ; tp["2017-12-01/2020-12-01"]<- mdf_stress["2017-12-01/2020-12-01",n]
plot( tp, format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.8, main = paste(sub('_base','', n), '(level)')) 
lines(mdf_base[,n], col='black', lwd=2) 
lines(mdf_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) 


# === write PDF
mdf_base<- mdf_base[ "2001-03-01/2020-12-01", ]
mdf_stress<- mdf_stress[ "2001-03-01/2020-12-01", ]
mo_fitted <- mo_fitted["2006-03-01/2020-12-01"]
remove<- c("ADX_base","Gov_Consumption_base" , "Current_Acc_Bal_base")
var_list<- DF_list_mo$Scenario[-match(remove,DF_list_mo$Scenario) ]
file<- paste( path1, "Enriched_macro.pdf", sep=""  )

pdf(file,width=9,height=7)
par(mfrow=c(2,1))
for (k in 1:length(var_list)){
  n<- var_list[k] 
  if( n == 'Gov_BaltoGDP_base'| n == 'Gov_Balance_base'){
    ind<- index( mo_base[,n]) ; s<- seq.int(from =1 , to=78, by=4 )
    plot( mo_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(yoy absolute change)')) 
    lines(mo_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) 
    g<- lines(mo_fitted[,n], col='blue') ; print(g)
    plot( mdf_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(level)')) 
    g<- lines(mdf_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) ; print(g)
  }else{
    ind<- index( mo_base[,n]) ; s<- seq.int(from =1 , to=78, by=4 )
    plot( mo_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(yoy relative change)')) 
    lines(mo_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) 
    g<- lines(mo_fitted[,n], col='blue') ; print(g)
    plot( mdf_base[,n], format.labels = "%b-%y", major.ticks = 'years', grid.ticks.on = "years", cex.axis = 0.7, main = paste(sub('_base','', n), '(level)')) 
    g<- lines(mdf_stress["2017-12-01/2020-12-01",n], col='red', lwd=2) ; print(g)
  } 
}
dev.off()



#=== For analysis ===
name_ret<- names(mo_stress)
low1<- apply( mo_stress["2006-06-01/2010-12-01"], 2, min)
low2<- apply( mo_stress["2011-03-01/2017-09-01"], 2, min)
low3<- apply( mo_stress["2017-12-01/2020-12-01"], 2, min)
df_low_ret<- data.frame(name_ret, low1, low2, low3) ; names(df_low_ret)<- c( 'Macro'  ,'2005-2010', '2011-2017', '2017-2020')
low1<- apply( mdf_stress["2006-06-01/2010-12-01"], 2, min)
low2<- apply( mdf_stress["2011-03-01/2017-09-01"], 2, min)
low3<- apply( mdf_stress["2017-12-01/2020-12-01"], 2, min)
low4<- apply( mdf_stress["2017-12-01"], 2, min)
df_low_level<- data.frame(names(mdf_stress), low1, low2, low3,low4 ) ; names(df_low_level)<- c('Macro', '2005-2010 level', '2011-2017 level', '2017-2020 level', '2017 level')
#=align
level_align<- df_low_level
for(k in 1:length(low3)){ level_align[k,]<- df_low_level[name_ret[k] , ]}
df_low<- cbind(df_low_ret, level_align )

# === summary stats
name_ret<- names(mo_stress)
av1<- apply( mo_stress["2006-06-01/2010-12-01"], 2, mean)
av2<- apply( mo_stress["2011-03-01/2017-09-01"], 2, mean)
av3<- apply( mo_stress["2017-12-01/2020-12-01"], 2, mean)
df_av_ret<- data.frame(name_ret, av1, av2, av3) ; names(df_av_ret)<- c( 'Macro'  ,'2005-2010', '2011-2017', '2017-2020')
av1<- apply( mdf_stress["2006-06-01/2010-12-01"], 2, mean)
av2<- apply( mdf_stress["2011-03-01/2017-09-01"], 2, mean)
av3<- apply( mdf_stress["2017-12-01/2020-12-01"], 2, mean)
av4<- apply( mdf_stress["2017-12-01"], 2, mean)
df_av_level<- data.frame(names(mdf_stress), av1, av2, av3,av4 ) ; names(df_av_level)<- c('Macro', '2005-2010 level', '2011-2017 level', '2017-2020 level', '2017 level')
#=align
level_align<- df_av_level
for(k in 1:length(av3)){ level_align[k,]<- df_av_level[name_ret[k] , ]}
df_av<- cbind(df_av_ret, level_align )


# ===  EXPORT ==
remove<- c("ADX_base","Gov_Consumption_base" , "Current_Acc_Bal_base")
mdf_base_out<- mdf_base[,  -match(remove,names(mdf_base)) ]
mdf_stress_out<- mdf_stress[,  -match(remove,names(mdf_stress)) ]
#add time index
mdf_base_out<- mdf_base_out[ "2001-03-01/2020-12-01", ]
temp_base_out<- as.data.frame(mdf_base_out) ; temp_base_out<- cbind(index(mdf_base_out), temp_base_out  ) ; names(temp_base_out)[1]<-'Date'
mdf_stress<- mdf_stress_out[ "2001-03-01/2020-12-01", ]
names(mdf_stress_out)<- sub('base','stress', names(mdf_stress_out)) #replace base by stress
temp_stress_out<- as.data.frame(mdf_stress_out) ; temp_stress_out<- cbind(index(mdf_stress_out), temp_stress_out  ) ; names(temp_stress_out)[1]<-'Date'
#write
file<- paste( path1, "Moodys_enrichment_2018_base.csv", sep=""  )
write.csv(temp_base_out, file = file, row.names=FALSE)
file<- paste( path1, "Moodys_enrichment_2018_stress.csv", sep=""  )
write.csv(temp_stress_out, file = file, row.names=FALSE)
file<- paste( path1, "Moodys_enrichment_2018_models.csv", sep=""  )
write.csv(model_mat, file = file, row.names=FALSE)
file<- paste( path1, "Moodys_enrichment_2018_lowpoints.csv", sep=""  )
write.csv(df_low, file = file, row.names=FALSE)



#********************************************************************************
#************* PART4: VALIDATION *******************************************************

file<- "Moodys_enrichment_2018_stress.csv"
path4<- paste( path1, file, sep=""  )
DF <- read.csv(path4, stringsAsFactors=FALSE, check.names = TRUE)
DF$Date<- as.Date(DF$Date)
mdf_stress2<- as.xts(DF[-1], order.by = DF$Date)
#check
plot(as.numeric(mdf_stress2$Gov_BaltoGDP_stress), as.numeric(mdf_stress$Gov_BaltoGDP_base ))

DF_list_mo<- DF_list[ which(DF_list$Source == "Moodys"),  ]
remove<- c("ADX_base","Gov_Consumption_base" , "Current_Acc_Bal_base")
var_list<- DF_list_mo$Scenario[-match(remove,DF_list_mo$Scenario) ]

# = print and compute percentiles
file<- paste( path1, "Enriched_macro_hist.pdf", sep=""  )
pdf(file,width=9,height=8)
par(mfrow=c(2,1))

name_vect<- c() ; shock_vect<- c() ; prob_vect1<-c() ; prob_vect2<-c() 
for (k in 1: ncol(mdf_stress2 )){
  # get the shocks 
  macro_name<- var_list[k]
  
  #return
  v<- as.numeric(na.omit(mo_base[,macro_name]))
  min_shock<- min( mo_stress["2017-12-01/2020-12-01", macro_name]   )
  # levels
  #v<- as.numeric(na.omit(mdf_stress["/2017-12-01" ,macro_name]))
  #min_shock<- min( mdf_stress["2017-12-01/2020-12-01", macro_name]   )
  
  rank_v<- v[order(v)] 
  if( min_shock < min(rank_v)){
    prob_int<- 0
  }else{ 
    #prob of occurrence via rank ordering
    n<- findInterval(min_shock, rank_v)
    prob1<- n/length(rank_v) ; 
    prob2<- (n+1)/length(rank_v)
    prob_int<- prob1 + (prob2-prob1)/(rank_v[n+1] - rank_v[n]) * (min_shock- rank_v[n] )
  }
  # get the prob of occurrence via density
  d<- density(v) ; prob<- d$y/sum(d$y)
  n<- findInterval( min_shock, d$x)
  prob2<- sum( prob[1:n])
  
  name_vect<- c(name_vect, macro_name) 
  shock_vect<- c(shock_vect, min_shock)
  prob_vect1<- c(prob_vect, prob_int) ; prob_vect2<- c(prob_vect2, prob2)
  # print
  title<- paste(macro_name, '(y-o-y change)')
  hist(v, probability  =TRUE, breaks=10, col='grey', main = title ) 
  lines(d, col='blue')
  abline( v=min_shock,col='red', lwd=3)
  mult<- if( abs(min_shock)>1){1}else{100} 
  s<- paste( round(min_shock*mult, 2), "%", sep=""); 
  leg<- paste('shock of',s)
  legend( 'topright', legend= leg, col='red', lwd=3)
}

dev.off()
#==========================


df_res<- data.frame(name_vect, shock_vect, prob_vect, prob_vect2)
# print file
file<- paste( path1, "shocks_percentile_equivalent.csv", sep=""  )
write.csv(df_res, file = file, row.names=FALSE)




#******************************************************************************
#************* PART5: FUNCTIONS *******************************************************

#  get parameters and tests results for ARIMAX2
get_param_and_test_arimax2<-function(modlist, model_num, cb_past, Y, onlyAR2 ){
  x1<- cb_past[ ,toString(modlist$name_vect1[model_num]) ] ; x2<- cb_past[ ,toString(modlist$name_vect2[model_num]) ]
  l1<- modlist$Lag_vect1[model_num] ; l2<- modlist$Lag_vect2[model_num]
  #construct model
  mer<- merge( Y , lag(x1,l1), lag(x2, l2)) #; plot.xts(lag(x2,4)) ; lines(x2)
  mer<- na.omit(mer)
  if(onlyAR2==TRUE){fit<- arima(mer[,1], order=c(2,0,0),xreg = mer[,2:3])
  }else{fit<- auto.arima(mer[,1], xreg = mer[,2:3]) }
  # check rsq
  y_fitted<- as.xts(as.numeric( fit$residuals) + as.numeric(mer[,1]), index(mer) )
  if( as.numeric(cor( as.numeric(y_fitted), as.numeric(mer[,1]))^2) == modlist$Rsq_vect[model_num])
  {print('the model can be replicated')}else{print('the model cannot be replicated')}
  # get coeffs
  ar_num<- fit$arma[1] ; ma_num<- fit$arma[2] ; i_num<- fit$arma[6] ; model_order<- paste("(", ar_num,",", i_num, ",",ma_num, ")", sep="")
  ar1<- as.numeric(fit$coef['ar1']) ; ar2<- as.numeric(fit$coef['ar2']) ; ar3<- as.numeric(fit$coef['ar3'])
  ma1<- as.numeric(fit$coef['ma1']) ; ma2<- as.numeric(fit$coef['ma2']) ; ma3<- as.numeric(fit$coef['ma3']) ; int<- as.numeric(fit$coef['intercept'])
  beta1<-  fit$coef[toString(modlist$name_vect1[model_num])] ; beta2<-  fit$coef[toString(modlist$name_vect2[model_num])]
  # get pval
  c<- coeftest(fit)[,4] ; 
  beta1_p<-  c[toString(modlist$name_vect1[model_num])] ; beta2_p<- c[toString(modlist$name_vect2[model_num])]
  # compute validation tests
  autocor_test<- validation_test(fit=fit, mer=mer)[1] ; multicol_test<- validation_test(fit=fit, mer=mer)[2]
  # construct df
  df_param<- data.frame(modlist[1,1], model_num, modlist[1,3], 
                        model_order, int, ar1, ar2, ar3, ma1, ma2, ma3,
                        names(x1), l1, beta1, beta1_p, 
                        names(x2), l2, beta2, beta2_p , autocor_test, multicol_test)
  names(df_param)[c(1,3, 12,13,16,17)]<- c('Y_var' , 'Rsq', 'name_x1', 'lag1', 'name_x2', 'lag2' )
  row.names(df_param)<- ""
  return( df_param )
}


get_test_arimax<- function(r_sort, cb_past, model_num) {
  x2<- cb_past[ ,toString(r_sort$name_vect2[model_num]) ] ; x3<- cb_past[ ,toString(r_sort$name_vect3[model_num]) ]
  l2<- r_sort$Lag_vect2[model_num] ; l3<- r_sort$Lag_vect3[model_num]
  #construct model
  mer<- merge( Y , lag(Y,1), lag(x2,l2), lag(x3, l3)) ; mer<- na.omit(mer)
  fit<- lm(mer[,1]~ mer[,2]+ mer[,3]+ mer[,4])
  # check rsq equality
  if( r_sort$Rsq_vect[model_num] == summary(fit)$r.squared)
  {print('the model can be replicated')}else{print('the model cannot be replicated')}
  # check error terms and test
  out<- validation_test(fit=fit, mer=mer)
  return(out)
}

#===== statistical tests
validation_test<- function(fit, mer){
  b<- Box.test(fit$residuals,type='Ljung', lag=8)
  if(b$p.value<0.05){autocorrel<- 'fail'}else{autocorrel<- 'pass'}
  multicol1<- lm(mer[,1]~mer[,ncol(mer)-1] + mer[,ncol(mer)]) ; v<- vif(multicol1)[1]
  multicol2<- as.numeric(cor(mer[,ncol(mer)-1],mer[,ncol(mer)]))
  if( v > 7 & abs(multicol2)>.7  ){multicolin<- 'fail'}else{multicolin<- 'pass'}
  #if( err_test=='fail' | colin_test=='failt'){out<- 'reject'}else{out<-'accept'}
  return(data.frame(autocorrel, multicolin))
}

#==== get forecated levels from returns
get_f_level<- function(mo_name, mo_ret, mdf ){
  change<- mo_ret["2017-03-01/2020-12-01", mo_name]
  level<- mdf[ "2017-03-01/2020-12-01" , mo_name]
  mer<- merge(level,change) 
  y_pred<- as.xts(rep(0,12), order.by=index(mo_stress["2018-03-01/2020-12-01"])) 
  for (t in 1:4){y_pred[t,1]<-  as.numeric(mer[t,1]) * as.numeric((1+mer[t+4,2])) }
  for (t in 5:12){y_pred[t,1]<- as.numeric(y_pred[t-4,1]) * as.numeric((1+mer[t+4,2]))}
  return(y_pred)
}

#=== final selection

selection_full<-function(macro_name, model_num, option, mo_base, mo_stress, model_mat, rsq_cut, box_cut ){
  #univ
  Y<- mo_past[,macro_name]  ; mo_name<- names(Y) ; print(mo_name)
  a<- univariate(d=cb_past, Y=Y , pos=TRUE )
  
  # *** First get fitted and predicted for the model of choice
  if(option==1){
    #regression simple
    r<- multireg_simple(univ_sort = a, d=cb_past, Y=Y)
    r_sort<- r[order(-r$Rsq_vect),]
    # remove negative coef and large pvalues
    r_sort<- r_sort[ -c( which(r_sort$coef_vect1<0), which(r_sort$coef_vect2<0)),  ]
    r_sort<- r_sort[ -c( which(r_sort$p_vect1>0.15), which(r_sort$p_vect2>0.15)),  ]
    #prediction simple
    out_base<- pred_multireg(start=model_num, end=model_num, colour='red', r_sort=r_sort, case_flag = 'base', Y=Y) 
    predicted_base<- out_base[[1]] ; fitted<- out_base[[2]]
    out_stress<- pred_multireg(start=model_num, end=model_num, colour='red', r_sort=r_sort, case_flag = 'stress', Y=Y) 
    predicted_stress<- out_stress[[1]] 
  }else{
    if(option==2){
      #regression arimax
      r<- arimax(univ_sort = a, d=cb_past, Y=Y, inter=TRUE)
      r_sort<- r[order(-r$Rsq_vect),]
      # remove negative coef
      r_sort<- r_sort[ -c( which(r_sort$coef_vect2<0), which(r_sort$coef_vect3<0)),  ]
      r_sort<- r_sort[ -c( which(r_sort$p_vect2>0.15), which(r_sort$p_vect3>0.15)),  ]
      #prediction arimax
      out_base<- pred_arimax(start=model_num, end=model_num, colour='green', r_sort=r_sort, case_flag = 'base', Y=Y)
      predicted_base<- out_base[[1]] ; fitted<- out_base[[2]]
      out_stress<- pred_arimax(start=model_num, end=model_num, colour='green', r_sort=r_sort, case_flag = 'stress', Y=Y)
      predicted_stress<- out_stress[[1]] 
    }else{
      if(option==3){
        out<- arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=rsq_cut, onlyAR2 = TRUE, cb_f_stress=cb_f_stress, cb_f_base=cb_f_base, box_cut=box_cut)
        modlist<- out[[1]]; predicted_base<-out[[2]][,model_num] ; predicted_stress<-out[[3]][, model_num] ; fitted<- out[[4]][, model_num]
      }else{
        out<- arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=rsq_cut, onlyAR2 = FALSE, cb_f_stress=cb_f_stress, cb_f_base=cb_f_base, box_cut=box_cut)
        modlist<- out[[1]]; predicted_base<-out[[2]][,model_num] ; predicted_stress<-out[[3]][, model_num] ; fitted<- out[[4]][, model_num]
      }
    }
  }
  #populate predicted in recipient
  mo_base["2017-12-01/2020-12-01", mo_name]<- predicted_base
  mo_stress["2017-12-01/2020-12-01", mo_name]<- predicted_stress
  
  # *** Second get the model parameters and the statistical tests for the model of choice
  if(option==1){
  }else{
    if(option==2){
      stat_test<- get_test_arimax( r_sort=r_sort, cb_past=cb_past, model_num=model_num) # get stat tests
      temp<- model_mat[1,] ; select<- r_sort[ model_num, ] # create recipient
      temp$Y_var<- macro_name ; temp$model_num<- model_num ; temp$Rsq<-select$Rsq_vect ; temp$model_order<- '(1,0,0)'
      temp$int<- select$coef_vect0  ;temp$ar1<- select$coef_vect1 ; temp$ar2<- 0 ; temp$ar3<- 0 ; temp$ma2<- 0 ; temp$ma3<- 0
      temp$name_x1<- toString(select$name_vect2) ; temp$lag1<- select$Lag_vect2 ; temp$beta1<- select$coef_vect2 ; temp$beta1_p<- select$p_vect2
      temp$name_x2<- toString(select$name_vect3) ; temp$lag2<- select$Lag_vect3 ; temp$beta2<- select$coef_vect3 ; temp$beta2_p<- select$p_vect3
      temp$autocorrel<- stat_test$autocorrel ; temp$multicolin <- stat_test$multicolin 
    }else{
      if(option==3){temp<-get_param_and_test_arimax2(modlist=modlist, model_num=model_num, cb_past=cb_past, Y=Y, onlyAR2=TRUE )
      }else{        temp<-get_param_and_test_arimax2(modlist=modlist, model_num=model_num, cb_past=cb_past, Y=Y, onlyAR2=FALSE)}
    }
  }
  model_mat<- rbind(model_mat, temp)
  return(list(predicted_base, predicted_stress, fitted, mo_base, mo_stress, model_mat))
}   


#=== Prediction using multireg ==============
pred_multireg<- function(start,end,colour, r_sort, case_flag, Y=Y){
  pred_mat<- as.xts( rep(0,13), order.by = index(cb_f_stress["2017-12-01/2020-12-01"])) #create recipient
  fitted_mat<- as.xts( rep(0,49), order.by = index(mo_base["2005-12-01/2017-12-01"]) ) #create recipient
  
  for (k in start:end){
    #replicate model of choice
    choice<- k
    n1<- toString(r_sort$name_vect1[choice]) ; l1<-r_sort$Lag_vect1[choice]
    n2<- toString(r_sort$name_vect2[choice]) ; l2<- r_sort$Lag_vect2[choice]
    mer<- merge(Y, lag(cb_past[,n1], l1), lag(cb_past[,n2], l2) ) ; mer<- na.omit(mer)
    names(mer)<- c('y', 'x1', 'x2') ; fit<- lm( y ~ x1+x2, data=mer)
    # use model to predict
    if( case_flag == 'stress'){
      x1<- cb_f_stress[,match(n1,names(cb_f_base) ) ] ; x1<-lag(x1,l1) ; x1<- x1["2017-12-01/2020-12-01"]
      x2<- cb_f_stress[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2017-12-01/2020-12-01"]
    }else{
      x1<- cb_f_base[,match(n1,names(cb_f_base) ) ] ; x1<-lag(x1,l1) ; x1<- x1["2017-12-01/2020-12-01"]
      x2<- cb_f_base[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2017-12-01/2020-12-01"]
    }
    newdata<- merge(x1, x2) ; names(newdata)<- c('x1', 'x2')
    pred<- predict.lm(fit,newdata=newdata ) ; pred["2017-12-01"]<-Y["2017-12-01"]
    pred_xts<- as.xts(pred, order.by = index(x1))
    # extract fitted
    fitted<- lm( mer[,1] ~ mer[,2] + mer[,3])$fitted.values ; fitted["2017-12-01"]<-Y["2017-12-01"]
    # === on on top of background plot
    #lines(mo_stress[, mo_name]) ; lines(pred_xts, col='red', lwd = 2) # plot prediction
    #lines(fitted, col='blue') # plot fitted
    # add to recipient
    pred_mat<- cbind(pred_mat, pred_xts) 
    fitted_mat<- cbind(fitted_mat, fitted) 
  }
  # return a matrix of prediction
  pred_mat<- pred_mat[,-1] ; names(pred_mat)<-start:end
  fitted_mat<- fitted_mat[,-1] ; names(fitted_mat)<- start:end
  return(list( pred_mat, fitted_mat))
}


# ====== Prediction macro using arimax ============
pred_arimax<- function(start,end,colour, r_sort, case_flag, Y=Y){
  pred_mat<- as.xts( rep(0,13), order.by = index(cb_f_stress["2017-12-01/2020-12-01"])) #create recipient
  fitted_mat<- as.xts( rep(0,49), order.by = index(mo_base["2005-12-01/2017-12-01"]) ) #create recipient
  
  for (k in start:end){
    choice<- k
    a0<-r_sort$coef_vect0[choice] ; a1<-r_sort$coef_vect1[choice] 
    a2<-r_sort$coef_vect2[choice] ; a3<-r_sort$coef_vect3[choice]
    n2<- toString(r_sort$name_vect2[choice]) ; l2<-r_sort$Lag_vect2[choice]
    n3<- toString(r_sort$name_vect3[choice]) ; l3<- r_sort$Lag_vect3[choice]
    # retreive historical cb data
    mer<- merge(Y, lag(cb_past[,n2], l2), lag(cb_past[,n3], l3) ) ; mer<- na.omit(mer)
    # use model - first retrieve newdata
    if(case_flag=='stress'){
      x2<- cb_f_stress[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2017-12-01/2020-12-01"]
      x3<- cb_f_stress[,match(n3,names(cb_f_base) ) ] ; x3<-lag(x3,l3) ; x3<- x3["2017-12-01/2020-12-01"]
    }else{
      x2<- cb_f_base[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2017-12-01/2020-12-01"]
      x3<- cb_f_base[,match(n3,names(cb_f_base) ) ] ; x3<-lag(x3,l3) ; x3<- x3["2017-12-01/2020-12-01"]
    }
    newdata<- na.omit(merge(x2, x3)) ; names(newdata)<- c('x2', 'x3')
    # forecasted values - loop through 13 steps
    y_pred<- as.xts( rep(0,13), order.by = index(x2["2017-12-01/2020-12-01"]))
    y_pred[1]<- Y["2017-12-01"]
    for (t in 2:13){
      y_pred[t]<- a0 + as.numeric(a1*y_pred[t-1]) + as.numeric(a2*x2[t]) + as.numeric(a3*x3[t]) # x2 and x3 already include lags
    }
    # fitted values in history
    y_fitted<- as.xts( rep(0,nrow(mer)), order.by = index(mer)) ;  y_fitted[1]<- mer[1,1]
    for (t in 2:nrow(mer)){
      y_fitted[t]<- a0 + as.numeric(a1*mer[t-1,1]) + as.numeric(a2*mer[t,2]) + as.numeric(a3*mer[t,3]) # x2 and x3 already include lags
    }
    
    # add to recipient
    pred_mat<- cbind(pred_mat, y_pred) 
    fitted_mat<- cbind(fitted_mat, y_fitted) 
  }
  # return a matrix of prediction
  pred_mat<- pred_mat[,-1] ;   names(pred_mat)<-start:end
  fitted_mat<- fitted_mat[,-1] ; names(fitted_mat)<- start:end
  return(list(pred_mat, fitted_mat))
}




#======= univariate =================
univariate<- function(d, Y, pos ){
  LO<-Y
  name_var<- names(d)
  Rsq_vect<- c() ; name_vect<- c() ; Lag_vect<-c() ; ID_vect<- c() ; coef_vect0<- c();coef_vect1<- c()
  ' first loop on variables'
  for (i in 1:(ncol(d)) ) {
    ' second loop on lags'
    for (j in 0:4){
      Lag<-j
      mer<- merge(LO, lag(d[,i],j)) #; plot.xts(lag (m_ret[,i],j)) ; lines(m_ret[,i])
      mer<- na.omit(mer)
      #mer_n<- apply(mer[,1:ncol(mer)],2, function(x) { (x-mean(x))/ sd(x)}) # normalise
      fit<- lm(mer[,1] ~ mer[,2])
      s<- summary(fit) ; coef1<- s$coefficients[2,1]
      
      ' store results'
      if( if(pos==TRUE){coef1>0}else{coef1<0} ){ 
        Rsq<- summary(fit)$r.square 
        n<- name_var[i] 
        Rsq_vect<- c(Rsq_vect,Rsq)
        name_vect<- c(name_vect,n)
        Lag_vect<- c(Lag_vect,Lag)
        ID_vect<- c(ID_vect, i)
        coef0<- summary(fit)$coefficients[1,1] ; coef_vect0<- c(coef_vect0,coef0 )
        coef1<- summary(fit)$coefficients[2,1] ; coef_vect1<- c(coef_vect1,coef1 )
      }
      
    }
  }
  
  Res<- data.frame(name_vect,ID_vect, Lag_vect, Rsq_vect,coef_vect0, coef_vect1 )
  Res_sort<- Res[order(-Res$Rsq_vect),]
  par(mfrow=c(1,1)) ; a<- which(Res_sort[,4]>0.05) ; Res_sort[a,] ;  nrow(Res_sort[a,]) # ;plot(Res_sort[a,4] ) 
  return(Res_sort)
}


#========== ARIMAX=================
arimax<- function(univ_sort, d, Y, inter){    
  Res_sort<- univ_sort ; LO<- Y
  Rsq_vect<- c()
  name_vect0<- c() ; name_vect1<- c() ; name_vect2<- c() ; name_vect3<- c()
  coef_vect0<- c()  ; coef_vect1<- c() ; coef_vect2<- c() ; coef_vect3<- c()
  p_vect0<- c() ; p_vect1<- c() ; p_vect2<- c() ; p_vect3<- c()
  Lag_vect0<- c() ; Lag_vect1<- c() ; Lag_vect2<- c() ;  Lag_vect3<- c() ; 
  ID_vect1<- c() ; ID_vect2<- c()
  
  n<- max(which(Res_sort$Rsq_vect>0.05)) # get the numb of R^2 > 5%
  'loop over the first variable'
  for (i in 1:(n-1)) {
    #ID1<- Res_sort$ID_vect[i]
    ID1<- toString(Res_sort$name_vect[i])
    Lag1<-  Res_sort$Lag_vect[i]
    x1<-  d[,ID1] ; names(x1)
    
    'loop over the second variable'
    for (j in (i+1):(n)){
      #ID2<- Res_sort$ID_vect[j]
      ID2<- toString(Res_sort$name_vect[j])
      
      if(ID2!= ID1){ 
        ' == retrieve the second macro variable'
        Lag2<-  Res_sort$Lag_vect[j]
        x2<- d[,ID2]
        ' == construct the joined data'
        
        LO_lag<- Lag(LO,1) 
        mer<- merge( LO , LO_lag, lag(x1,Lag1), lag(x2, Lag2)) #; plot.xts(lag(x2,4)) ; lines(x2)
        mer<- na.omit(mer)
        if (inter==TRUE){    fit<- lm(mer[,1] ~ mer[,2]+ mer[,3] + mer[,4]) 
        } else {          fit<- lm(mer[,1] ~ mer[,2]+ mer[,3] + mer[,4] -1)} 
        
        s<- summary(fit)
        
        '== Store results'
        ' Extract'
        Rsq<- summary(fit)$r.square 
        
        if (inter==TRUE){ n0<- 'intercept' ; n1<- 'LO_lag' ; n2<- ID1 ; n3<- ID2
        }else{                               n0<- 'LO_lag' ; n1<- ID1 ; n2<- ID2}
        
        coef0<- s$coefficients[1,1]
        coef1<- s$coefficients[2,1]
        coef2<- s$coefficients[3,1]
        if (inter==TRUE){coef3<- s$coefficients[4,1]}
        
        p0<- s$coefficients[1,4]
        p1<- s$coefficients[2,4]
        p2<- s$coefficients[3,4]
        if (inter==TRUE){p3<- s$coefficients[4,4]}
        
        '== Store in vectors'
        Rsq_vect<- c(Rsq_vect,Rsq)
        name_vect0<- c(name_vect0,n0)
        name_vect1<- c(name_vect1,n1)
        name_vect2<- c(name_vect2,n2)
        if (inter==TRUE){name_vect3<- c(name_vect3,n3)}
        
        coef_vect0<- c(coef_vect0,coef0)
        coef_vect1<- c(coef_vect1,coef1)
        coef_vect2<- c(coef_vect2,coef2)
        if (inter==TRUE){coef_vect3<- c(coef_vect3,coef3)}
        
        p_vect0<- c(p_vect0,p0)
        p_vect1<- c(p_vect1,p1)
        p_vect2<- c(p_vect2,p2)
        if (inter==TRUE){p_vect3<- c(p_vect3,p3)}
        
        if (inter==TRUE){ Lag_vect1<- c(Lag_vect1,1) ; Lag_vect2<- c(Lag_vect2,Lag1) ; Lag_vect3<- c(Lag_vect3,Lag2)
        }else{           Lag_vect0<-   c(Lag_vect0,1) ; Lag_vect1<- c(Lag_vect1,Lag1) ; Lag_vect2<- c(Lag_vect2,Lag2)}
        
      }
    }
    
  }
  
  
  'intercept'
  if(inter==TRUE){
    Res_mult<- data.frame(Rsq_vect,
                          name_vect0, coef_vect0, p_vect0,
                          name_vect1, coef_vect1, p_vect1, Lag_vect1,
                          name_vect2, coef_vect2, p_vect2, Lag_vect2,
                          name_vect3, coef_vect3, p_vect3, Lag_vect3)
  }else{
    Res_mult<- data.frame(Rsq_vect,
                          name_vect0, coef_vect0, p_vect0, Lag_vect0,
                          name_vect1, coef_vect1, p_vect1, Lag_vect1,
                          name_vect2, coef_vect2, p_vect2, Lag_vect2)
  }
  return(Res_mult)
}



# ============= multireg ====================

multireg_simple<- function(univ_sort, d, Y){    
  Res_sort<- univ_sort ; LO<- Y
  Rsq_vect<- c()
  name_vect0<- c() ; name_vect1<- c() ; name_vect2<- c() ; name_vect3<- c()
  coef_vect0<- c()  ; coef_vect1<- c() ; coef_vect2<- c() ; coef_vect3<- c()
  p_vect0<- c() ; p_vect1<- c() ; p_vect2<- c() ; p_vect3<- c()
  Lag_vect0<- c() ; Lag_vect1<- c() ; Lag_vect2<- c() ;  Lag_vect3<- c() ; 
  ID_vect1<- c() ; ID_vect2<- c()
  
  n<- max(which(Res_sort$Rsq_vect>0.05)) # get the numb of R^2 > 5%
  'loop over the first variable'
  for (i in 1:(n-1)) {
    #ID1<- Res_sort$ID_vect[i]
    ID1<- toString(Res_sort$name_vect[i])
    Lag1<-  Res_sort$Lag_vect[i]
    x1<-  d[,ID1] ; names(x1)
    
    'loop over the second variable'
    for (j in (i+1):(n)){
      #ID2<- Res_sort$ID_vect[j]
      ID2<- toString(Res_sort$name_vect[j])
      
      if(ID2!= ID1){ 
        ' == retrieve the second macro variable'
        Lag2<-  Res_sort$Lag_vect[j]
        x2<- d[,ID2]
        ' == construct the joined data'
        
        mer<- merge( LO , lag(x1,Lag1), lag(x2, Lag2)) #; plot.xts(lag(x2,4)) ; lines(x2)
        mer<- na.omit(mer)
        fit<- lm(mer[,1] ~ mer[,2]+ mer[,3]) 
        s<- summary(fit)
        
        '== Store results'
        ' Extract'
        Rsq<- summary(fit)$r.square 
        
        n0<- 'intercept' ; n1<- ID1 ; n2<- ID2
        
        coef0<- s$coefficients[1,1]
        coef1<- s$coefficients[2,1]
        coef2<- s$coefficients[3,1]
        
        p0<- s$coefficients[1,4]
        p1<- s$coefficients[2,4]
        p2<- s$coefficients[3,4]
        
        '== Store in vectors'
        Rsq_vect<- c(Rsq_vect,Rsq)
        name_vect0<- c(name_vect0,n0)
        name_vect1<- c(name_vect1,n1)
        name_vect2<- c(name_vect2,n2)
        
        coef_vect0<- c(coef_vect0,coef0)
        coef_vect1<- c(coef_vect1,coef1)
        coef_vect2<- c(coef_vect2,coef2)
        
        p_vect0<- c(p_vect0,p0)
        p_vect1<- c(p_vect1,p1)
        p_vect2<- c(p_vect2,p2)
        
        Lag_vect1<- c(Lag_vect1,Lag1) ; Lag_vect2<- c(Lag_vect2,Lag2)
        
      }
    }
    
  }
  Res_mult<- data.frame(Rsq_vect,
                        name_vect0, coef_vect0, p_vect0,
                        name_vect1, coef_vect1, p_vect1, Lag_vect1,
                        name_vect2, coef_vect2, p_vect2, Lag_vect2)
  return(Res_mult)
}

#******************************************************************


#========== ARIMAX2 with forecast package =================
#out<- arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=0.2)
#pred<- out[[3]] ; lines(pred) ; lines(out[[4]])
arimax_2(univ_sort=a, d=cb_past, Y=Y, rsq_cut=0.3 , onlyAR2 = FALSE, cb_f_stress=cb_f_stress, cb_f_base=cb_f_base, box_cut=.05)

arimax_2<- function(univ_sort, d, Y, rsq_cut, onlyAR2,cb_f_stress, cb_f_base, box_cut  ){ 
  #create recipients
  pred_mat_stress<- as.xts( rep(0,13), order.by = index(cb_f_stress["2017-12-01/2020-12-01"])) #create recipient
  pred_mat_base<- as.xts( rep(0,13), order.by = index(cb_f_stress["2017-12-01/2020-12-01"])) #create recipient
  fitted_mat<- as.xts( rep(0,49), order.by = index(mo_base["2005-12-01/2017-12-01"]) ) #create recipient
  
  Res_sort<- univ_sort ; LO<- Y
  Rsq_vect<- c()
  name_vect0<- c() ; name_vect1<- c() ; name_vect2<- c() ; name_vect3<- c()
  Lag_vect0<- c() ; Lag_vect1<- c() ; Lag_vect2<- c() ;  Lag_vect3<- c() ; 
  i_vect<- c() ; j_vect<- c()
  # prepare loop
  n<- max(which(Res_sort$Rsq_vect>rsq_cut)) 
  count<-0 ; count_vect<-c()
  'loop over the first variable'
  for (i in 1:(n-1)) {
    #ID1<- Res_sort$ID_vect[i]
    ID1<- toString(Res_sort$name_vect[i])
    Lag1<-  Res_sort$Lag_vect[i]
    x1<-  d[,ID1] ; names(x1) 
    
    'loop over the second variable'
    for (j in (i+1):(n)){
      #ID2<- Res_sort$ID_vect[j]
      ID2<- toString(Res_sort$name_vect[j])
      
      if(ID2!= ID1){ 
        ' == retrieve the second macro variable'
        Lag2<-  Res_sort$Lag_vect[j]
        x2<- d[,ID2]
        ' == construct the joined data'
        
        mer<- merge( LO , lag(x1,Lag1), lag(x2, Lag2)) #; plot.xts(lag(x2,4)) ; lines(x2)
        mer<- na.omit(mer) ; xreg<-mer[,2:3]
        
        if( onlyAR2==TRUE){
          fit<- arima(mer[,1], order=c(2,0,0), xreg = xreg)
        }else{fit<- auto.arima(mer[,1], xreg = xreg, max.p=3, max.q=3, max.d=1, max.P=0, max.Q=0, max.D=0)}
        
        #get p value fo the macro variable
        #c<- coeftest(fit)[,4] ; 
        #beta1_p<-  c[length(c)-1] ; beta2_p<- c[length(c)] 
        # get Ljung-Box test p
        b<- Box.test(fit$residuals,type='Ljung', lag=8)
        
        # Proceed if (i) coefs are positives (ii) macro val are significant and (iii) errors are not autocorrelated 
        if (fit$coef[length(fit$coef)]>0 & fit$coef[length(fit$coef)-1]>0 & b$p.value> box_cut) { #& beta1_p<.2 & beta2_p<.2
          count<-count+1 ; count_vect<-c(count_vect, count)
          i_vect<- c(i_vect, i) ; j_vect<- c(j_vect, j)
          name_vect1<- c(name_vect1,ID1 ) ; name_vect2<- c(name_vect2,ID2 ) 
          Lag_vect1<- c(Lag_vect1, Lag1) ; Lag_vect2<- c(Lag_vect2, Lag2) 
          
          # == forecast
          newdata_stress<- get_newdata(n1=ID1, n2=ID2, l1=Lag1, l2=Lag2, case_flag='stress', cb_f_stress=cb_f_stress, cb_f_base=cb_f_base)
          fc_stress<- forecast(fit, xreg = newdata_stress, h=nrow(newdata_stress) ) 
          y_pred_stress<- as.xts(as.numeric(fc_stress$mean), order.by=index(newdata_stress)) 
          y_pred_stress<- rbind(LO['2017-12-01'], y_pred_stress) #add the starting point
          pred_mat_stress<- cbind(pred_mat_stress, y_pred_stress)
          
          newdata_base<- get_newdata(n1=ID1, n2=ID2, l1=Lag1, l2=Lag2, case_flag='base', cb_f_stress=cb_f_stress, cb_f_base=cb_f_base)
          fc_base<- forecast(fit, xreg=newdata_base, h=nrow(newdata_base) ) 
          y_pred_base<- as.xts(as.numeric(fc_base$mean), order.by=index(newdata_base))  
          y_pred_base<- rbind(LO['2017-12-01'], y_pred_base)
          pred_mat_base<- cbind(pred_mat_base, y_pred_base)
          
          # extract fitted
          y_fitted<- as.xts(as.numeric( fit$residuals) + as.numeric(mer[,1]), index(mer) )
          fitted_mat<- cbind(fitted_mat, y_fitted) 
          Rsq<- cor( as.numeric(y_fitted), as.numeric(mer[,1]))^2 ; Rsq_vect<- c(Rsq_vect, Rsq)
        }
      }
    }
    cat("\r", i, "of", n) 
    flush.console()
  }
  
  df_result<- data.frame( rep(names(Y), length(count_vect)), count_vect, Rsq_vect, name_vect1, Lag_vect1 , name_vect2, Lag_vect2)
  pred_mat_base<- pred_mat_base[,-1] ; pred_mat_stress<- pred_mat_stress[,-1] ;fitted_mat<- fitted_mat[,-1]
  names(pred_mat_base)<- count_vect ; names(pred_mat_stress)<- count_vect ; names(fitted_mat)<- count_vect
  return( list(df_result, pred_mat_base, pred_mat_stress, fitted_mat))
}

#=== get data ====

get_newdata<- function(n1, n2, l1, l2, case_flag, cb_f_stress, cb_f_base){
  # use model - first retrieve newdata
  if(case_flag=='stress'){
    x1<- cb_f_stress[,match(n1,names(cb_f_base) ) ] ; x1<-lag(x1,l1) ; x1<- x1["2018-03-01/2020-12-01"]
    x2<- cb_f_stress[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2018-03-01/2020-12-01"]
  }else{
    x1<- cb_f_base[,match(n1,names(cb_f_base) ) ] ; x1<-lag(x1,l1) ; x1<- x1["2018-03-01/2020-12-01"]
    x2<- cb_f_base[,match(n2,names(cb_f_base) ) ] ; x2<-lag(x2,l2) ; x2<- x2["2018-03-01/2020-12-01"]
  }
  newdata<- na.omit(merge(x1, x2)) ; names(newdata)<- c(n1, n2)
  return(newdata)
}


# ===== Percentile check ============
qt<- data.frame(  .9, .95, .99) ; names(qt)<- c( '90%', '95%', '99%')
var_name<- c(); mo_select<- mo_past[ "2011-01-01/2017-12-01" ]

n<- 'GDP_base' ; pos<- match(n, names(mo_past))
qt<- rbind( qt, getperc(pos)); var_name<- n
n<- 'Oil_Brent_base' ; pos<- match(n, names(mo_select))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
n<- 'Domestic_Demand_base' ; pos<- match(n, names(mo_select))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
n<-  'Private_Consumption_base' ; pos<- match(n, names(mo_select))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
n<- 'Import_base' ; pos<- match(n, names(mo_past))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
n<- "Real_Estate_base" ; pos<- match(n, names(mo_select))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
n<- "Gov_BaltoGDP_base" ; pos<- match(n, names(mo_select))
qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)

qt<- cbind( var_name, qt[-1,])      

file<- paste( path1, "Marco_perc_temp.csv", sep=""  )
write.table(qt, "clipboard", sep="\t", row.names=TRUE, col.names=TRUE)

getperc<- function (num_macro){
  a1<- quantile( mo_select[,num_macro], .1, na.rm=TRUE)
  a2<- quantile( mo_select[,num_macro], .05, na.rm=TRUE)
  a3<- quantile( mo_select[,num_macro], .01, na.rm=TRUE)
  row<- c( a1, a2, a3) ; names(row)<- c('90%', '95%', '99%')
  return(row)
}


