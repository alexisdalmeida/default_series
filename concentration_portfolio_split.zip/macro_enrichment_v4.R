
library(xts)
library(quantmod)
#library(forecast)
library(car)
#library(lmtest)
library(data.table)
#library(CADFtest)
#library(MALDIquant)

#***********************************************************************************************
#************* PART1: FILE CONSTRUCTION  *******************************************************
path1<- "~/R/Concentration_Risk_Proj/data"

file1<- "/raw_data_banks.csv"
path2<- paste( path1, file1, sep=""  )
DF <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)

file2<- "/hhi_mult.csv"
path3<- paste( path1, file2, sep=""  )
hhi_tables <- read.csv(path3, stringsAsFactors=FALSE, check.names = TRUE)

#Create total dataset with the total EAD (lines 0 - one for total and one for total with exclusions)
total_vector <- DF[1,]
total_vector_excl <- DF[2,]

#Remove PD and LGD columns
total_vector <- total_vector[-c(3,4,5,7,8,9)]
total_vector_excl <- total_vector_excl[-c(3,4,5,7,8,9)]

#Remove total EAD (lines 0) from the dataset
DF <- DF[-1,]
DF <- DF[-1,]

#Transform NAs to 0
DF[is.na(DF)] <- 0

#Add columns with the square of EAD
#Portfolio
DF$adib_ead_sq <- DF$adib_ead^2
DF$dib_ead_sq <- DF$dib_ead^2

#Total
total_vector$adib_ead_sq <- total_vector$adib_ead^2
total_vector$dib_ead_sq <- total_vector$dib_ead^2

total_vector_excl$adib_ead_sq <- total_vector_excl$adib_ead^2
total_vector_excl$dib_ead_sq <- total_vector_excl$dib_ead^2

#Set the exposure share
total <- (colSums(DF,na.rm=TRUE))

DF$share_adib <- DF$adib_ead/total[2]
DF$share_dib <- DF$dib_ead/total[6]

#Check
sum(DF$share_adib)
sum(DF$share_dib)

#Square the share
DF$share_adib_sq <- DF$share_adib^2
DF$share_dib_sq <- DF$share_dib^2

#***********************************************************************************************
#************* PART2: HHI INDICES  *************************************************************

#For Spain approach use only the exclusion=0 records
sum(DF$adib_ead_sq[which(DF$adib_exclusion==0)])

a_adib_s <- sum(DF$adib_ead_sq[which(DF$adib_exclusion==0)])
a_adib_uk <- sum(DF$adib_ead_sq)
b_adib_s <- total_vector_excl$adib_ead_sq
b_adib_uk <- total_vector$adib_ead_sq
a_dib_s <- sum(DF$dib_ead_sq[which(DF$dib_exclusion==0)])
a_dib_uk <- sum(DF$dib_ead_sq)
b_dib_s <- total_vector_excl$dib_ead_sq
b_dib_uk <- total_vector$dib_ead_sq

mults_adib <- function_hhi(a=a_adib_s,b=b_adib_s,hhi_tables=hhi_tables,country="spain")
multu_adib <- function_hhi(a=a_adib_uk,b=b_adib_uk,hhi_tables=hhi_tables,country="uk")

mults_dib <- function_hhi(a=a_dib_s,b=b_dib_s,hhi_tables=hhi_tables,country="spain")
multu_dib <- function_hhi(a=a_dib_uk,b=b_dib_uk,hhi_tables=hhi_tables,country="uk")


#***********************************************************************************************
#************* PART3: GORDY INDICES  ***********************************************************

#Gordy parameters
vol_lgd=0.25
prob=0.999
delta=4.83

adib_exp <- 103623692.026463
adib_cap <- 9875852.02579238
dib_exp <- 199191246.320439
dib_cap <- 16982487.69

DF_G <- DF

#ADIB
DF_G$adib_v_lgdi <- DF_G$adib_lgd*(1-DF_G$adib_lgd)*vol_lgd
DF_G$adib_ci <- (DF_G$adib_v_lgdi+DF_G$adib_lgd^2)/DF_G$adib_lgd
DF_G$adib_ri <- DF_G$adib_pd*DF_G$adib_lgd
DF_G$adib_r <- 0.12*(1-exp(-50*DF_G$adib_pd))/(1-exp(-50))+0.24*(1-(1-exp(-50*DF_G$adib_pd)))/(1-exp(-50))
DF_G$adib_b <- (0.11852-0.05478*log(DF_G$adib_pd))^2
DF_G$adib_ki <- (DF_G$adib_lgd*pnorm(qnorm(DF_G$adib_pd)*(1-DF_G$adib_r)^-0.5+qnorm(prob)*(DF_G$adib_r/(1-DF_G$adib_r))^0.5)-DF_G$adib_pd*DF_G$adib_lgd)*(1+(DF_G$adib_m-2.5)*DF_G$adib_b)/(1-1.5*DF_G$adib_b)
DF_G$adib_gai <- DF_G$share_adib_sq*DF_G$adib_ci*((delta*(DF_G$adib_ki+DF_G$adib_ri))-DF_G$adib_ki)
DF_G$adib_prodk <- DF_G$share_adib*DF_G$adib_ki
adib_ga <- (1/(sum(DF_G$adib_prodk,na.rm=TRUE)*2))*sum(DF_G$adib_gai,na.rm=TRUE)*sum(DF_G$adib_ead,na.rm=TRUE)/adib_cap

#DIB
DF_G$dib_v_lgdi <- DF_G$dib_lgd*(1-DF_G$dib_lgd)*vol_lgd
DF_G$dib_ci <- (DF_G$dib_v_lgdi+DF_G$dib_lgd^2)/DF_G$dib_lgd
DF_G$dib_ri <- DF_G$dib_pd*DF_G$dib_lgd
DF_G$dib_r <- 0.12*(1-exp(-50*DF_G$dib_pd))/(1-exp(-50))+0.24*(1-(1-exp(-50*DF_G$dib_pd)))/(1-exp(-50))
DF_G$dib_b <- (0.11852-0.05478*log(DF_G$dib_pd))^2
DF_G$dib_ki <- (DF_G$dib_lgd*pnorm(qnorm(DF_G$dib_pd)*(1-DF_G$dib_r)^-0.5+qnorm(prob)*(DF_G$dib_r/(1-DF_G$dib_r))^0.5)-DF_G$dib_pd*DF_G$dib_lgd)*(1+(DF_G$dib_m-2.5)*DF_G$dib_b)/(1-1.5*DF_G$dib_b)
DF_G$dib_gai <- DF_G$share_dib_sq*DF_G$dib_ci*((delta*(DF_G$dib_ki+DF_G$dib_ri))-DF_G$dib_ki)
DF_G$dib_prodk <- DF_G$share_dib*DF_G$dib_ki
dib_ga <- (1/(sum(DF_G$dib_prodk,na.rm=TRUE)*2))*sum(DF_G$dib_gai,na.rm=TRUE)*(sum(DF_G$dib_ead,na.rm=TRUE))/1000/dib_cap


#***********************************************************************************************
#************* PART4: INDICES TABLE  ***********************************************************

#Create table with the indices

index<-matrix(c(adib_exp,adib_cap,mults_adib,multu_adib,adib_ga,dib_exp,dib_cap,mults_dib,multu_dib,dib_ga),ncol=5,byrow=TRUE)
rownames(index)<-c("ADIB","DIB")
colnames(index)<-c("Exposure","Capital","HHI Spain","HHI UK","Gordy")
index <- as.data.frame(index)

#Export to Excel
write.csv(index, "C:\\Users\\sofia.oliveira\\Documents\\R\\Concentration_Risk_Proj\\output\\index.csv", row.names=TRUE)

#***********************************************************************************************
#************* PART5: FUNCTIONS  *******************************************************

#HHI Multiplier Function
function_hhi <- function(a,b,hhi_tables,country) {
  k <- if (country=="spain") {2} else {3}
  hhi <- (a/b)*100
  
  position <- which.min(abs(hhi_tables$hhi - hhi))
  
  if (hhi_tables$hhi[position] < hhi) {
    x <-c(hhi_tables$hhi[position],hhi_tables$hhi[position+1])
    y <-c(hhi_tables[position,k],hhi_tables[position+1,k])
  } else {
    x <-c(hhi_tables$hhi[position-1],hhi_tables$hhi[position])
    y <-c(hhi_tables[position-1,k],hhi_tables[position,k])
  }

  data_temp <- data.frame(x,y)

  mult <- y[1] + (y[2]-y[1])/(x[2]-x[1])*(hhi-x[1])

  return(mult)
}

