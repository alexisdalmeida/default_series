

#corrmat_shocked<- shock_corrmat_function( corrmat,2.5)
#out<- get_EC(excl_flag='no', data_bank=data, nsimul=10000, conf_level = 0.999,
             #rho_mult=1.2, corrmat_shocked = corrmat_shocked)

# ================ function to compute EC ====================

get_EC<- function(excl_flag, data_bank, nsimul, conf_level, rho_mult, corrmat_shocked){   
  
  # ===================  get data ============
  if(excl_flag == 'yes'){
    exposure_vect<- data_bank$exposure_after_exclusions
    exclusions<- sum(data_bank$exclusions)
    # exposure_total_adj<- exposure_total_adj - exclusions
  }else{
    exposure_vect<- data_bank$exposure
  } 
  
  ead_vect<- exposure_vect
  pd_vect<- data_bank$pd
  lgd_vect<-data_bank$lgd
  sector_vect<- data_bank$sector
  rho_vect<- 0.12 * (1-exp(-50 * pd_vect )) / (1-exp(-50)) + 0.24 * (1-(1-exp(-50 *pd_vect)))/(1-exp(-50) )
  # multiplier applied to rho
  assetcorr_vect<- rho_vect * rho_mult
  maxpop<- 100000
  #nsimul<- 1000
  
  #Simulate
  loss_vect<- simulate(pd_vect=pd_vect, lgd_vect=lgd_vect, ead_vect=ead_vect, assetcorr_vect=assetcorr_vect, 
                       maxpop=maxpop , nsimul=nsimul,sector_vect=sector_vect, corrmat_shocked=corrmat_shocked  )
  hist(loss_vect, col='grey')
  
  # Get percentile
  ead_total = sum(ead_vect[1: min(maxpop, length(ead_vect))  ]      )
  Q<- quantile(loss_vect, conf_level)  ; Qpc<- Q/ead_total ; Av<- mean(loss_vect)                         
  Res<- data.frame( conf_level, ead_total, Av, Q, Qpc  ) ; 
  names(Res)<- c("QLevel", "EAD", "MeanLoss", "QLoss", "Qpc" )
  
  # Get EVD percentile
  # conf from which the EVD will be estimated
  x1<- conf_level * .995/.999  # the second number is just a scaler
  x2<- conf_level * .994/.999
  x3<- conf_level * .993/.999
  
  evd1<- EVD(loss_vect, x1, conf_level) 
  evd2<- EVD(loss_vect, x2, conf_level)  
  evd3<- EVD(loss_vect, x3, conf_level) 
  evd_av<- mean(evd1, evd2, evd3)
  evd_pc<- evd_av/ead_total
  Res<- cbind(Res, evd_av, evd_pc) ;  print(Res)                        # bind all 
  
  return(Res)  
}
  
  


# ==== Function to simulate name concentration ====

simulate<- function( pd_vect, lgd_vect, assetcorr_vect, ead_vect, maxpop, nsimul,sector_vect, corrmat_shocked ){   
  
  #loop through borrowers, scenarios are vectorised
  popsize<- min( length(pd_vect), maxpop) 
  loss<- rep(0, nsimul)

  # simulate industry correlated Z outside of the obligor loop
  #corrmat_shocked<- shock_corrmat_function( corrmat, corr_mat_shock )  #stress the corr_mat
  z_mat<-   GenCopul(2,nsimul, corrmat= corrmat_shocked) 
  # check cor(z_vect)
  #pairs.panels(z_mat[,1:4])
  
  k<- 0
  for(i in 1 : popsize){
    k<- k+1
    z_vect <- z_mat[, which(sector_vect[i]== colnames(corrmat)) ]  # get the industry factor
    e<- rnorm(nsimul,0,1)                   # Generate idiosyncratic term
    d<- qnorm(pd_vect[i], 0,1)              # Compute threshold
    ead_vect[i]<- max(0, ead_vect[i])
    A<-  assetcorr_vect[i]^0.5 * z_vect + (1-assetcorr_vect[i])^0.5 * e
    loss<- ifelse( A<d, loss + max(0,ead_vect[i]) * lgd_vect[i], loss)  # sum the losses from obligor, loop afer loop
    
    #DefMat[,i]<- ifelse( A<d, 1, 0)                                   # for extraction only 
    #LossMat[,i]<- ifelse( A<d,EAD[i]*LGD[i] , 0)                      # for extraction only
    
    cat("\r", i, "of", popsize,"total population" ) 
    flush.console()
  }
  
  return(loss)
}


# == Function for EVD ====

#cut<- .995 ; alpha<- .999
EVD<- function( loss, cut, alpha){
  q<- quantile(loss,cut)
  excess<- rep(0, length(loss)) ; excess<- sapply( loss, function(x){max(x-q,0)})
  l<- loss[excess!=0] ; e<- excess[excess != 0]
  
  loglike<- function(x){
    beta<- x[1] ; ksi<- x[2]
    ml<- sapply( e, function(x){ -log(beta)-(1+1/ksi)*log(1+x*ksi/beta) })
    return(-sum(ml))
  }
  
  # === test the minimisation function 
  #e<- c(9480, 3589, 3419, 3147, 1965, 1794, 1536, 1386, 1027, 923, 680, 316, 314, 243, 77)
  #out<- optim(par=c(1,0.1) , fn=loglike, method = "L-BFGS-B", lower=c(0.01,0.01), upper=c(300000000,3000000))
  #out$par ;# should be  c(1701,0.148)
  
  #===== 
  out_min<- optim(par=c(1,0.1) , fn=loglike, method = "L-BFGS-B", lower=c(0.01,0.01), upper=c(300000000,3000000))
  beta<- out_min$par[1] ; ksi<- out_min$par[2] ; N<- length(loss) ; n<- length(e)
  var<- as.numeric(q) + beta/ksi * (( (1 - alpha) * N/n)^(-ksi) - 1 )
  return(var)
}

# =========== Function to generate copula =============

GenCopul<- function(type, nsimul, corrmat){
  L <- t(chol(corrmat)) ; nvariables = dim(L)[1]
  #Simulation of z in one step
  z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) #hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) #; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree)# ; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) #; pairs.panels(z_NCop_NMarg[,1:4])
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) #; pairs.panels(z_TCop_NMarg[,1:4])
  # Choose systemic factor
  temp<- list(z_NCop_NMarg, z_TCop_NMarg) ; zsys<- temp[[type]]
  return(zsys)
}

# =========== Function to stress corr mat =============

shock_corrmat_function<- function(corrmat, shock){
  n<- length(corrmat[1,])
  eigen_object<- eigen(corrmat)
  eigen_val<-  eigen_object$values ; eigen_vect<-  eigen_object$vectors
  
  eigen_val_stress<- eigen_val
  eigen_val_stress[1]<- eigen_val[1] + eigen_val[1]* shock
  eigen_val_stress[2:n]<- eigen_val[2:n] - eigen_val[1]*(shock)/(n-1)
  
  sum(eigen_val_stress) == sum(eigen_val)
  corrmat_stress<- eigen_vect %*% diag(eigen_val_stress) %*% solve(eigen_vect)
  
  flooratone<- function(x){return(min(x,1))}
  corrmat_stress <- apply(corrmat_stress, c(1,2), flooratone)
  return(corrmat_stress)
}
 


# =================Not used ============================================
#   ======  simulate industries if needed 


# *************** Function: Generate various Copulas **********
GenCopul<- function(type, nsimul, corrmat){
  L <- t(chol(corrmat)) ; nvariables = dim(L)[1]
  #Simulation of z in one step
  z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) #hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) #; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree) #; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
  # Choose systemic factor
  temp<- list(z_NCop_NMarg, z_TCop_NMarg) ; zsys<- temp[[type]]
  return(zsys)
}


##### generte a corr matrix

#seed<- 30

#x1 <- rnorm(1000)
#x2 <- rnorm(1000) + 0.2 * x1
#x3 <- runif(1000) + 0.1 * x1 - 0.2 * x2
#temp<- data.frame(x1, x2, x3)
#corrmat<- cor(temp)


# systemic factor
#nsimul<- 1000
#set.seed(seed) ; 
#zsys<- GenCopul(2, nsimul = n, corrmat = corrmat) ;   pairs.panels(zsys)



