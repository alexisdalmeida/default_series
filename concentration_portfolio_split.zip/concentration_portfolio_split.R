

portfolio_split<- function( data, split, cutoff_exp_pc) { 
  
  # sort data
  data_sort<- data[ order(-data$exposure),]
  
  exposure_vect<- data_sort$exposure
  
  prop_exp<-  cumsum(exposure_vect/sum(exposure_vect))
  num_exp_pc<- which( min( abs(cutoff_exp_pc-prop_exp))== abs(cutoff_exp_pc-prop_exp)  )
  cutoff<- num_exp_pc
  row_total<- nrow(data_sort)
  
  
  data_new<- data.frame(0,0,0,0)
  names(data_new)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')  
  
  #=== part1 - Split the top until the cutoff
  
  for( k in 1:cutoff){
    
    # create new split loans
    ead_split<- rep( data_sort$exposure[k]/split, split)
    ead_excl_split<- rep( data_sort$exposure_after_exclusions[k]/split, split)
    pd_split<- rep(data_sort$pd[k], split)
    lgd_split<- rep(data_sort$lgd[k], split) 
    temp<- data.frame(ead_split, ead_excl_split, pd_split, lgd_split)
    names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
    
    # add to the main data frame
    data_new<- rbind(data_new, temp)
  }
  
  data_new<- data_new[-1,] # remove the first line containing zeros
  
  #=== part2 - add the rest after the cutoff
  
  ead_rest<- data_sort$exposure[(cutoff+1):row_total]
  ead_excl_rest<- data_sort$exposure_after_exclusions[(cutoff+1):row_total]
  pd_rest<- data_sort$pd[(cutoff+1):row_total]
  lgd_rest<- data_sort$lgd[(cutoff+1):row_total]
  temp<- data.frame(ead_rest, ead_excl_rest, pd_rest, lgd_rest)
  names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
  # add to the main data frame
  data_new<- rbind(data_new, temp)
  
  #======= Part3 re-order
  data_new_sort<- data_new[ order(-data_new$exposure),]
  
  # == Part4 checks and analysis
  sum(data_sort$exposure)
  sum(data_new_sort$exposure)
  #x11()
  # plot before and after exclusions
  #plot(cumsum(data_sort$exposure), type='l')
  #lines(cumsum(data_sort$exposure_after_exclusions), col='blue')
  
  # relative
  c1<- cumsum(data_sort$exposure)/sum(data_sort$exposure)
  c2<- cumsum(data_sort$exposure_after_exclusions)/sum(data_sort$exposure_after_exclusions)
  #plot(c1, type='l'); lines(c2, lty=2)   
  
  # ALL EXP - plot before and after split
  c3<- cumsum(data_new_sort$exposure)/sum(data_new_sort$exposure)
  #plot(c1, type='l'); lines(c3, col='red') 
  # WITH EXCL - plot before and after split 
  c4<- cumsum(data_new_sort$exposure_after_exclusions)/sum(data_new_sort$exposure_after_exclusions)
  #plot(c2, type='l'); lines(c4, col='red') 
  
  # plot together  
  par(mfrow=c(1,2))
  plot(c1, type='l',lty=1, main='All exposures'); lines(c3,lty=2 )
  plot(c2, col='red', type='l', main ='With exclusions') ; lines(c4, lty=2, col='red')
  
  return(data_new) 
}



portfolio_split_v3<- function( data, split, cutoff_exp_pc, excl_flag) { 
  
  # sort data
  
  if( excl_flag=='yes'){
      data_sort<- data[ order(-data$exposure_after_exclusions),]
      exposure_vect<- data_sort$exposure_after_exclusions
  }else{
      data_sort<- data[ order(-data$exposure),]
      exposure_vect<- data_sort$exposure
  }

  prop_exp<-  cumsum(exposure_vect/sum(exposure_vect))
  num_exp_pc<- which( min( abs(cutoff_exp_pc-prop_exp))== abs(cutoff_exp_pc-prop_exp)  )
  cutoff<- num_exp_pc
  row_total<- nrow(data_sort)
  
  #=== part1 - Split the top until the cutoff
  data_new<- data.frame(0,0,0,0)
  names(data_new)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')  

  for( k in 1:cutoff){
    
    # create new split loans
    ead_split<- rep( data_sort$exposure[k]/split, split)
    ead_excl_split<- rep( data_sort$exposure_after_exclusions[k]/split, split)
    pd_split<- rep(data_sort$pd[k], split)
    lgd_split<- rep(data_sort$lgd[k], split) 
    temp<- data.frame(ead_split, ead_excl_split, pd_split, lgd_split)
    names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
    
    # add to the main data frame
    data_new<- rbind(data_new, temp)
  }
  
  data_new<- data_new[-1,] # remove the first line containing zeros
  
  #=== part2 - add the rest after the cutoff
  
  ead_rest<- data_sort$exposure[(cutoff+1):row_total]
  ead_excl_rest<- data_sort$exposure_after_exclusions[(cutoff+1):row_total]
  pd_rest<- data_sort$pd[(cutoff+1):row_total]
  lgd_rest<- data_sort$lgd[(cutoff+1):row_total]
  temp<- data.frame(ead_rest, ead_excl_rest, pd_rest, lgd_rest)
  names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
  # add to the main data frame
  data_new<- rbind(data_new, temp)
  
  #======= Part3 re-order
  
  if( excl_flag=='yes'){
    data_new_sort<- data_new[ order(-data_new$exposure_after_exclusions),]
  }else{
    data_new_sort<- data_new[ order(-data_new$exposure),]
  }
  
  
  # == Part4 checks and analysis
  sum(data_sort$exposure)
  sum(data_new_sort$exposure)
  sum(data_sort$exposure_after_exclusions)
  sum(data_new_sort$exposure_after_exclusions)
  nrow(data_sort) ; nrow(data_new_sort)
  #x11()
  # plot before and after exclusions
  #plot(cumsum(data_sort$exposure), type='l')
  #lines(cumsum(data_sort$exposure_after_exclusions), col='blue')
  
  # Before
  c1<- cumsum(data_sort$exposure)/sum(data_sort$exposure)
  c2<- cumsum(data_sort$exposure_after_exclusions)/sum(data_sort$exposure_after_exclusions)
  client_cum_conc<- c(1:nrow(data_sort))/nrow(data_sort)
  
  # After 
  c3<- cumsum(data_new_sort$exposure)/sum(data_new_sort$exposure)
  c4<- cumsum(data_new_sort$exposure_after_exclusions)/sum(data_new_sort$exposure_after_exclusions)
  client_cum_granu<- c(1:nrow(data_new_sort))/nrow(data_new_sort)
  
  pos<- which( min( abs( client_cum_conc[1] - client_cum_granu))== abs( client_cum_conc[1] - client_cum_granu))
  #etc... continue to plot on the same chart
  
  # plot together  
  par(mfrow=c(2,2))
  plot(client_cum_conc, c1, type='l',lty=1, main='All exposures'); 
  plot(client_cum_granu, c3,lty=2 , type='l')
  plot(client_cum_conc, c2, col='red', type='l', main ='With exclusions', lty=1) ; 
  plot(client_cum_granu, c4, lty=2,type='l' ,col='red')
  
  return(data_new_sort) 
}



get_prop<- function(exp_vect){
  exp_cum<- cumsum(exp_vect)/sum(exp_vect)
  client_cum<- c(1:length(exp_vect))/length(exp_vect) 
  
  client_target<- 0.3
  pos<- which( min( abs( client_target - client_cum))== abs( client_target - client_cum))
  a<- round(exp_cum[pos], 3)[1]
  paste('30% of customer have', a,' exposure')
  
  exp_target<- 0.5
  pos<- which( min( abs( exp_target - exp_cum))== abs( exp_target - exp_cum))
  b<- round(client_cum[pos], 3)[1]
  paste(b ,' of clients have 50% of exposure')
  
  df<- data.frame(b, 0.5) 
  df<- rbind(df,c(0.3, a) )
  names(df)<- c('prop clients', 'prop exp')
  return(df)
}

# ============== MOVING SPLIT =====================

portfolio_moving_split<- function( data, excl_flag) { 
  
  # sort data
  
  if( excl_flag=='yes'){
    data_sort<- data[ order(-data$exposure_after_exclusions),]
    exposure_vect<- data_sort$exposure_after_exclusions
  }else{
    data_sort<- data[ order(-data$exposure),]
    exposure_vect<- data_sort$exposure
  }
  #data_sort<- data_sort[  -which(exposure_vect==0),  ]
  
  # ===== find split
  row_total<- nrow(data_sort)
  target_size<- sum(exposure_vect)/row_total
  #target_size<- quantile( exposure_vect[ -which(exposure_vect == 0)  ], .5)
  n_split_vect<-0
  for (k in 1:row_total){
    n_split<- max( 1, round( exposure_vect[k]/target_size, 0))
    n_split_vect<- c(n_split_vect, n_split)
  }
  n_split_vect<- n_split_vect[-1]
  
  cutoff<- which(1==n_split_vect)[1]-1
    
  #=== part1 - Split 
  data_new<- data.frame(0,0,0,0)
  names(data_new)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')  
  
  for( k in 1:cutoff){
    
    split<- n_split_vect[k]
    # create new split loans
    ead_split<- rep( data_sort$exposure[k]/split, split)
    ead_excl_split<- rep( data_sort$exposure_after_exclusions[k]/split, split)
    pd_split<- rep(data_sort$pd[k], split)
    lgd_split<- rep(data_sort$lgd[k], split) 
    temp<- data.frame(ead_split, ead_excl_split, pd_split, lgd_split)
    names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
    
    # add to the main data frame
    data_new<- rbind(data_new, temp)
  }
  
  data_new<- data_new[-1,] # remove the first line containing zeros
  
  #=== part2 - add the rest after the cutoff
  
  ead_rest<- data_sort$exposure[(cutoff+1):row_total]
  ead_excl_rest<- data_sort$exposure_after_exclusions[(cutoff+1):row_total]
  pd_rest<- data_sort$pd[(cutoff+1):row_total]
  lgd_rest<- data_sort$lgd[(cutoff+1):row_total]
  temp<- data.frame(ead_rest, ead_excl_rest, pd_rest, lgd_rest)
  names(temp)<- c('exposure', 'exposure_after_exclusions', 'pd', 'lgd')
  # add to the main data frame
  data_new<- rbind(data_new, temp)
  
  #======= Part3 re-order
  
  if( excl_flag=='yes'){
    data_new_sort<- data_new[ order(-data_new$exposure_after_exclusions),]
  }else{
    data_new_sort<- data_new[ order(-data_new$exposure),]
  }
  
  
  # == Part4 checks and analysis
  sum(data_sort$exposure)
  sum(data_new_sort$exposure)
  sum(data_sort$exposure_after_exclusions)
  sum(data_new_sort$exposure_after_exclusions)
  nrow(data_sort) ; nrow(data_new_sort)
  #x11()
  # plot before and after exclusions
  #plot(cumsum(data_sort$exposure), type='l')
  #lines(cumsum(data_sort$exposure_after_exclusions), col='blue')
  
  # Before
  c1<- cumsum(data_sort$exposure)/sum(data_sort$exposure)
  c2<- cumsum(data_sort$exposure_after_exclusions)/sum(data_sort$exposure_after_exclusions)
  client_cum_conc<- c(1:nrow(data_sort))/nrow(data_sort)
  
  # After 
  c3<- cumsum(data_new_sort$exposure)/sum(data_new_sort$exposure)
  c4<- cumsum(data_new_sort$exposure_after_exclusions)/sum(data_new_sort$exposure_after_exclusions)
  client_cum_granu<- c(1:nrow(data_new_sort))/nrow(data_new_sort)
  
  pos<- which( min( abs( client_cum_conc[1] - client_cum_granu))== abs( client_cum_conc[1] - client_cum_granu))
  #etc... continue to plot on the same chart
  
  # plot together  
  par(mfrow=c(2,2))
  plot(client_cum_conc, c1, type='l',lty=1, main='All exposures'); 
  plot(client_cum_granu, c3,lty=2 , type='l')
  plot(client_cum_conc, c2, col='red', type='l', main ='With exclusions', lty=1) ; 
  plot(client_cum_granu, c4, lty=2,type='l' ,col='red')
  
  return(data_new_sort) 
}

