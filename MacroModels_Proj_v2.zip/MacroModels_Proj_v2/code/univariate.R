



#======= univariate =================
univariate<- function(d, Y, pos ){
  LO<-Y
  name_var<- names(d)
  Rsq_vect<- c() ; name_vect<- c() ; Lag_vect<-c() ; ID_vect<- c() ; coef_vect0<- c();coef_vect1<- c()
  ' first loop on variables'
  for (i in 1:(ncol(d)) ) {
    ' second loop on lags'
    for (j in 0:4){
      Lag<-j
      mer<- merge(LO, lag(d[,i],j)) #; plot.xts(lag (m_ret[,i],j)) ; lines(m_ret[,i])
      mer<- na.omit(mer)
      #mer_n<- apply(mer[,1:ncol(mer)],2, function(x) { (x-mean(x))/ sd(x)}) # normalise
      fit<- lm(mer[,1] ~ mer[,2])
      s<- summary(fit) ; coef1<- s$coefficients[2,1]
      
      ' store results'
      if( if(pos==TRUE){coef1>0}else{coef1<0} ){ 
        Rsq<- summary(fit)$r.square 
        n<- name_var[i] 
        Rsq_vect<- c(Rsq_vect,Rsq)
        name_vect<- c(name_vect,n)
        Lag_vect<- c(Lag_vect,Lag)
        ID_vect<- c(ID_vect, i)
        coef0<- summary(fit)$coefficients[1,1] ; coef_vect0<- c(coef_vect0,coef0 )
        coef1<- summary(fit)$coefficients[2,1] ; coef_vect1<- c(coef_vect1,coef1 )
      }
      
    }
  }
  
  Res<- data.frame(name_vect,ID_vect, Lag_vect, Rsq_vect,coef_vect0, coef_vect1 )
  Res_sort<- Res[order(-Res$Rsq_vect),]
  par(mfrow=c(1,1)) ; a<- which(Res_sort[,4]>0.05) ; Res_sort[a,] ;  nrow(Res_sort[a,]) # ;plot(Res_sort[a,4] ) 
  return(Res_sort)
}

normalise<- function(x){
  return((x-mean(x, na.rm=TRUE))/sd(x, na.rm = TRUE))
}



