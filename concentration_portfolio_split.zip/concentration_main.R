path<- "C:/Users/alexis.dalmeida/Documents/R/packages_20210817"
.libPaths(path)
.libPaths()

library(xts)
library(quantmod)
library(forecast)
library(car)
library(lmtest)
library(data.table)
library(CADFtest)
library(psych)
library(dplyr)
library(reshape)

path1<- "~/R/Concentration_Risk_Proj/data"

file<- "/data_overall.csv"
path2<- paste( path1, file, sep=""  )
data_overall <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
file<- "/hhi_mult.csv"
path2<- paste( path1, file, sep=""  )
hhi_mult <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)

# === gordi parameters
lgd_vol<- 0.25
delta_adj<- 4.83
alpha_perc<- 0.999

# = ============================================
# == Regulatory Capital Multipliers ===
source("~/R/Concentration_Risk_Proj/code/concentration_HHI_and_Gordy.R")


bank_list<- c('ADCB_1', 'ADCB_2', 'ADCB_3', 'ADIB_new', 'CBD','DIB_new', 'ENBD', 'FAB', 'HSBC_adj', 'MASHQ', 'SCB')

bank_name<- 'ADCB_1'
bank_name<- 'FAB'
bank_name<- 'ADIB_new'

#====== loop through banks to get the standard measures =======

for (k in 1:length(bank_list)){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  
  # get exposure and Pillar1 capital 
  exposure_total<- data_overall$exposure[ which(data_overall$bank == bank_name) ]
  capital_p1<- data_overall$pillar1_capital[ which(data_overall$bank == bank_name) ]
  
  # == no exclusions, total exposure
  a1<- compute_capital_mult(excl_flag='no' ,method ='hhi_sp_0.25', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  b1<- compute_capital_mult(excl_flag='no' ,method ='hhi_sp_0.5', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  c1<- compute_capital_mult(excl_flag='no' ,method ='hhi_uk', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  d1<- compute_capital_mult(excl_flag='no' ,method ='gordi' , use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  
  # == exclusions, total exposure
  a2<- compute_capital_mult(excl_flag='yes' ,method ='hhi_sp_0.25', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  b2<- compute_capital_mult(excl_flag='yes' ,method ='hhi_sp_0.5', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  c2<- compute_capital_mult(excl_flag='yes' ,method ='hhi_uk', use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  d2<- compute_capital_mult(excl_flag='yes' ,method ='gordi' , use_exp_total='yes',  data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  
    # == no exclusions, real exposure
  a3<- compute_capital_mult(excl_flag='no' ,method ='hhi_sp_0.25', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  b3<- compute_capital_mult(excl_flag='no' ,method ='hhi_sp_0.5', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  c3<- compute_capital_mult(excl_flag='no' ,method ='hhi_uk', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  d3<- compute_capital_mult(excl_flag='no' ,method ='gordi' , use_exp_total='no',  data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  
  # == exclusions, real exposure
  a4<- compute_capital_mult(excl_flag='yes' ,method ='hhi_sp_0.25', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  b4<- compute_capital_mult(excl_flag='yes' ,method ='hhi_sp_0.5', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  c4<- compute_capital_mult(excl_flag='yes' ,method ='hhi_uk', use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  d4<- compute_capital_mult(excl_flag='yes' ,method ='gordi' , use_exp_total='no',  data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  
  results<- data.frame(a1)    ; results<- rbind(results,b1) ; results<- rbind(results,c1) ; results<- rbind(results,d1)
  results<- rbind(results,a2) ; results<- rbind(results,b2) ; results<- rbind(results,c2) ; results<- rbind(results,d2)
  results<- rbind(results,a3) ; results<- rbind(results,b3) ; results<- rbind(results,c3) ; results<- rbind(results,d3)
  results<- rbind(results,a4) ; results<- rbind(results,b4) ; results<- rbind(results,c4) ; results<- rbind(results,d4)
  
  method_label<- c('hhi_sp_0.25', 'hhi_sp_0.5', 'hhi_uk', 'gordi', 
                   'hhi_sp_0.25', 'hhi_sp_0.5', 'hhi_uk', 'gordi',
                   'hhi_sp_0.25', 'hhi_sp_0.5', 'hhi_uk', 'gordi',
                   'hhi_sp_0.25', 'hhi_sp_0.5', 'hhi_uk', 'gordi')
  exclusion_label<- c('no_excl', 'no_excl', 'no_excl','no_excl',
                      'excl', 'excl','excl','excl',
                      'no_excl', 'no_excl', 'no_excl','no_excl',
                      'excl', 'excl', 'excl', 'excl' )
  exposure_label<- c('total','total','total','total','total','total','total','total',
                     'sum_EAD','sum_EAD','sum_EAD','sum_EAD','sum_EAD','sum_EAD','sum_EAD','sum_EAD')
  bank_label<- replicate(12, bank_name)
  
  results<- cbind(bank_name, method_label,exclusion_label, exposure_label,results )
  
  row_num<- nrow(data)
  if(k==1){ 
    results_all<- results
    row_num_vect<- row_num
  }else{ 
    results_all<- rbind( results_all, results)
    row_num_vect<- c( row_num_vect, row_num)
  }

}


write.table(results_all, "clipboard", sep="\t")

row_num_table<- data.frame(bank_list, row_num_vect)
write.table(row_num_table, "clipboard", sep="\t")

#=================================
# ======== Portfolio analysis =============

source("~/R/Concentration_Risk_Proj/code/concentration_HHI_and_Gordy.R")
bank_list<- c('ADCB_1', 'ADCB_2', 'ADCB_3', 'ADIB_2', 'ADIB_new','CBD', 'DIB_new', 'ENBD', 'FAB', 'HSBC_adj', 'MASHQ', 'SCB')

bank_name<- 'ADCB_1'
bank_name<- 'FAB'
bank_name<- 'ADIB_new'


for (k in 1:length(bank_list)){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  # data is for the main code, data_bank is for the functions
  
  # remove high and low PD values
  if( max(data$pd)>.95){data<- data[ -which(data$pd>.95), ]}
  if( min(data$pd)==0){data<- data[ -which(data$pd==0), ]}
  # remove low exposure values smaller than 0.5m
  if( min(data$exposure)<0.5){data<- data[ -which(data$exposure<0.5), ]}
  
  
  # get exposure and Pillar1 capital 
  exposure_total<- data_overall$exposure[ which(data_overall$bank == bank_name) ]
  capital_p1<- data_overall$pillar1_capital[ which(data_overall$bank == bank_name) ]
  # get HHI
  h1<- compute_metrics(excl_flag='no' , use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  h2<- compute_metrics(excl_flag='yes' , use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  h3<- compute_metrics(excl_flag='no' , use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  h4<- compute_metrics(excl_flag='yes' , use_exp_total='no', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)
  
  # get the weighted av PD and LGD - use 1000 to be conservative
  n<-1000
  PD_w<- sum( data$pd[1:n] * data$exposure[1:n] * data$lgd[1:n]) / sum(  data$exposure[1:n] * data$lgd[1:n])
  LGD_w<- sum( data$pd[1:n] * data$exposure[1:n] * data$lgd[1:n]) / sum(  data$exposure[1:n] * data$pd[1:n])
  PD_w_excl<- sum( data$pd[1:n] * data$exposure_after_exclusions[1:n] * data$lgd[1:n]) / sum(  data$exposure_after_exclusions[1:n] * data$lgd[1:n])
  LGD_w_excl<- sum( data$pd[1:n] * data$exposure_after_exclusions[1:n] * data$lgd[1:n]) / sum(  data$exposure_after_exclusions[1:n] * data$pd[1:n])
  PD_av<- c(PD_w, PD_w_excl, PD_w, PD_w_excl)
  LGD_av<- c(LGD_w, LGD_w_excl, LGD_w, LGD_w_excl)
  
  
  exclusion_label<- c('no_excl', 'excl', 'no_excl','excl' )
  exposure_label<- c('total','total','sum_EAD','sum_EAD')
  bank_label<- replicate(4, bank_name)
  
  results<- rbind(h1, h2, h3, h4)
  # add the number of rows after split
  data_new<-portfolio_moving_split(data, excl_flag='yes')
  acc_num_split<- rep(nrow(data_new) ,4)
  results<- cbind( results,  acc_num_split )
  # add other information
  results<- cbind(bank_name,exclusion_label, exposure_label,results)
  results<- cbind(results, PD_av, LGD_av)
  
  
  if(k==1){ 
    results_all<- results
  }else{ 
    results_all<- rbind( results_all, results)
  }
  
}

write.table(results_all, "clipboard", sep="\t")

# concentration
# PD
# LGD

# === Construct chart with all banks - portfolio concentration

bank_list<- c('ADCB_1', 'ADCB_2', 'ADCB_3', 'ADIB_2', 'ADIB_new','CBD', 'DIB_new', 'ENBD', 'FAB', 'HSBC_adj', 'MASHQ', 'SCB')

bank_name<- 'ADCB_1'
bank_name<- 'FAB'
bank_name<- 'ADIB_new'


for (k in 1:length(bank_list)){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  
  # get cumulatie exposure
  exp_vect<- data$exposure_after_exclusions
  prop_exp<-  cumsum(exp_vect/sum(exp_vect))
  n<- length(exp_vect) ; prop<- rep(1/n, n) ; prop_client<- cumsum(prop)
  
  # map to a unic grid
  n<- 100 ; prop<- rep(1/n, n) ; prop_grid<- cumsum(prop)
  pos<- function(x){  which( min( abs(x -prop_client)) == abs( x -prop_client)  )[1]  }
  pos_mapped<- sapply(prop_grid , FUN= pos)
  prop_exp_mapped<- prop_exp[ unlist(pos_mapped) ]
  
  if(k==1){ 
    df_out<- data.frame( prop_grid, prop_exp_mapped)
    names(df_out) = c('cumul_clients', bank_name)
  }else{
    temp<- data.frame(prop_exp_mapped) ; names(temp)<- bank_name
    df_out<- cbind(df_out, temp)
  }
}

write.table(df_out, "clipboard", sep="\t")


#================================================
# ======= EC simulation ==========

# === Adjust the PD 
x11()
hist(data$pd)
temp<- ifelse(data$pd > .1, NA, data$pd)
hist(temp)

data_adj<- data
data_adj$pd<- ifelse( data$pd<.01, 1-(1-data$pd)^2, data$pd)
plot(data_adj$pd, data$pd)

data_adj<- data_adj[ -which(data_adj$pd>.99), ] # remove high PD values



#  ==== Create a granular portfolio =================
source("~/R/Concentration_Risk_Proj/code/concentration_portfolio_split.R")
split<- 20
cutoff_exp_pc<- .60 # cutoff exposure percentage as the % cumulative exposure
data_new<- portfolio_split(data_adj, split, cutoff_exp_pc)
nrow(data_adj) ; nrow(data_new)
sum(data_adj$exposure) ; sum(data_new$exposure)
sum(data_adj$exposure*data_adj$pd)  ; sum(data_new$exposure*data_new$pd)
sum(data_adj$exposure*data_adj$lgd)  ; sum(data_new$exposure*data_new$lgd)
data_sort<- data_adj[ order(-data_adj$exposure),]
#head(data_sort, 10) ; head(data_new, 10)
# before
hhi<- sum(data_adj$exposure^2) / sum(data_adj$exposure)^2 * 100  ; hhi
#after
hhi<- sum(data_new$exposure^2) / sum(data_new$exposure)^2 * 100  ; hhi


# ==== get ECL simulation 
source("~/R/Concentration_Risk_Proj/code/concentration_ECap.R")
set.seed(29)
out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=60000, conf_level=.999); out_conc
out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=60000, conf_level=.999) ; out_granular
  
ratio1<- out_conc$QLoss/out_granular$QLoss ; ratio1
ratio2<- out_conc$evd_av/out_granular$evd_av ; ratio2

#====test several portfolios
set.seed(1234)
split_vect<- c(5, 10, 15, 30)
cutoff_exp_pc<- .6

for (trial in (1:4)){
  
  # create portfolio
  split<- split_vect[trial]
  data_new<- portfolio_split(data_adj, split, cutoff_exp_pc)
  
  #ECL simuation
  out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=20000, conf_level=.999); out_conc
  out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=20000, conf_level=.999) ; out_granular
  ratio1<- out_conc$QLoss/out_granular$QLoss
  ratio2<- out_conc$evd_av/out_granular$evd_av  
  
  # extract
  if(trial==1){trial_df<- data.frame(split, cutoff_exp_pc, ratio1, ratio2)
  }else{
    temp<- data.frame(split, cutoff_exp_pc, ratio1, ratio2)
    trial_df<- rbind( trial_df, temp)
  }
}
print(trial_df)




# ==== trials to observe stability

for (trial in (1:3)){
  set.seed(25+trial)
  out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=40000, conf_level=.999); out_conc
  out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=40000, conf_level=.999) ; out_granular
  
  if(trial==1){
    trial_df_conc <- out_conc
    trial_df_granular <- out_granular
    
  }else{
    trial_df_conc<- rbind(trial_df_conc, out_conc)
    trial_df_granular<- rbind(trial_df_granular, out_granular)
  }
}

ratio<- mean(trial_df_conc$evd_pc) / mean(trial_df_granular$evd_pc) 
write.table(trial_df_conc, "clipboard", sep="\t")
write.table(trial_df_granular, "clipboard", sep="\t")


plot(data_new$exposure_after_exclusions)


# ===============================================
#  ==== Search for a granular portfolio =================
source("~/R/Concentration_Risk_Proj/code/concentration_portfolio_split.R")
split<- 60
cutoff_exp_pc<- .3 # cutoff exposure percentage as the % cumulative exposure
#data_new<- portfolio_split(data_adj, split, cutoff_exp_pc)
data_new<- portfolio_split_v3(data_adj, split, cutoff_exp_pc, excl_flag='yes')


#before
exp_vect<- data_adj$exposure_after_exclusions
get_prop(exp_vect)
hhi<- sum(data_adj$exposure_after_exclusions^2) / sum(data_adj$exposure_after_exclusions)^2 * 100  ; hhi
# after
exp_vect<- data_new$exposure_after_exclusions
get_prop(exp_vect)
hhi<- sum(data_new$exposure_after_exclusions^2) / sum(data_new$exposure_after_exclusions)^2 * 100  ; hhi


#===== asymptotic portfolio
par(mfrow=c(1,1))
data_new<- data_adj
data_new$exposure_after_exclusions<- sum(data_adj$exposure_after_exclusions)/nrow(data_adj)
c1<- cumsum(data_adj$exposure_after_exclusions)/sum(data_adj$exposure_after_exclusions)
c2<- cumsum(data_new$exposure_after_exclusions)/sum(data_new$exposure_after_exclusions)
plot( c2, type='l',lty=2, main='With exclusions'); lines(c1, lty=1)

# ======== iterrative splitting
target_size<- sum(data_adj$exposure_after_exclusions)/nrow(data_adj)
n_split_vect<-0
for (k in 1:nrow(data_adj)){
  exp_vect<-   data_adj$exposure_after_exclusions
  n_split<- max( 1, round( exp_vect[k]/target_size, 0))
  n_split_vect<- c(n_split_vect, n_split)
}
n_split_vect<- n_split_vect[-1]



#======================================================
#============= Run across banks ===============
source("~/R/Concentration_Risk_Proj/code/concentration_portfolio_split.R")
source("~/R/Concentration_Risk_Proj/code/concentration_ECap.R")



bank_list<- c('ADCB_1', 'ADCB_2', 'ADCB_3', 'ADIB_2', 'ADIB_new', 'CBD', 'DIB_new', 'ENBD', 'FAB', 'HSBC_adj', 'MASHQ', 'SCB')

bank_name<- 'DIB_new'
bank_name<- 'FAB'
bank_name<- 'ADIB_new'
bank_name<- 'HSBC_adj'

#== start run
#bank_list<- c( 'ADCB_3', 'ADIB_new', 'DIB_new', 'ENBD', 'FAB')
x11()
start_time <- Sys.time()
n<- length(bank_list)
for (k in 1:n){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  
  # adjust PD if needed
  data_adj<- data
  data_adj$pd<- ifelse( data$pd<.8, 1-(1-data$pd)^1, data$pd)
  plot(data_adj$pd, data$pd)
  if( max(data_adj$pd)>.95){data_adj<- data_adj[ -which(data_adj$pd>.95), ]} # remove high PD values
  if( min(data_adj$pd)==0){data_adj<- data_adj[ -which(data_adj$pd==0), ]} # remove low PD values
  if( min(data_adj$exposure)<0.5){data_adj<- data_adj[ -which(data_adj$exposure<0.5), ]}   # remove low exposure values smaller than 0.5m
  
  # method 1: Construct asymptotic portfolio
  data_new<- data_adj
  data_new$exposure<- sum(data_adj$exposure)/nrow(data_adj)
  data_new$exposure_after_exclusions<- sum(data_adj$exposure_after_exclusions)/nrow(data_adj)
  c1<- cumsum(data_adj$exposure_after_exclusions)/sum(data_adj$exposure_after_exclusions)
  c2<- cumsum(data_new$exposure_after_exclusions)/sum(data_new$exposure_after_exclusions)
  plot( c2, type='l',lty=2, main='With exclusions'); lines(c1, lty=1)
  
  # method2: Construct split portfolio
  split<- 50
  cutoff_exp_pc<- .3
  data_new<- portfolio_split_v3(data=data_adj, split, cutoff_exp_pc, excl_flag='yes')
  
  # method3: Construct split portfolio with gradual split
  data_new<-portfolio_moving_split(data_adj, excl_flag='yes')

  # get the portfolio metrics before
  exp_vect<- data_adj$exposure_after_exclusions
  get_prop(exp_vect)
  exp_client30pc_conc<- get_prop(exp_vect)[ 2, 2]
  client_exp50pc_conc<- get_prop(exp_vect)[ 1, 1]
  hhi_conc<- sum(data_adj$exposure_after_exclusions^2) / sum(data_adj$exposure_after_exclusions)^2 * 100  ; hhi_conc
  mean_loss_conc<- sum(data_adj$exposure_after_exclusions * data_adj$pd * data_adj$lgd )/sum(data_adj$exposure_after_exclusions)
  mean_loss_conc
  # after
  exp_vect<- data_new$exposure_after_exclusions
  exp_client30pc_granu<- get_prop(exp_vect)[ 2, 2]
  client_exp50pc_granu<- get_prop(exp_vect)[ 1, 1]
  hhi_granu<- sum(data_new$exposure_after_exclusions^2) / sum(data_new$exposure_after_exclusions)^2 * 100  ; hhi_granu
  mean_loss_granu<- sum(data_new$exposure_after_exclusions * data_new$pd * data_new$lgd )/sum(data_new$exposure_after_exclusions)
  mean_loss_conc
  
  # run Economic Capital
  for (trial in (1:20)){
    set.seed(32+trial)
    out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=40000, conf_level=.999, rho_mult=1.2); out_conc
    out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=40000, conf_level=.999, rho_mult=1.2) ; out_granular
    
    if(trial==1){
      trial_df_conc <- out_conc
      trial_df_granular <- out_granular
      
    }else{
      trial_df_conc<- rbind(trial_df_conc, out_conc)
      trial_df_granular<- rbind(trial_df_granular, out_granular)
    }

  }
  # add to the dataframe
  type<- 'concentrated' ; trial_df_conc<-     cbind(bank_name, type, exp_client30pc_conc , client_exp50pc_conc , hhi_conc,  trial_df_conc)
  type<- 'granular' ;     trial_df_granular<- cbind(bank_name, type, exp_client30pc_granu, client_exp50pc_granu, hhi_granu, trial_df_granular)
  
  # aggregate all banks
  if(k==1){
    trial_df_conc_all<- trial_df_conc
    trial_df_granular_all<- trial_df_granular
  }else{
    trial_df_conc_all<- rbind( trial_df_conc_all, trial_df_conc)
    trial_df_granular_all<- rbind( trial_df_granular_all, trial_df_granular) 
  }

}

end_time <- Sys.time()
print(end_time-start_time)

# === end run

write.table(trial_df_conc_all, "clipboard", sep="\t")
write.table(trial_df_granular_all, "clipboard", sep="\t")

x<- trial_df_conc_all
y<- trial_df_granular_all



path_out<- "~/R/Concentration_Risk_Proj/output"
fileout<- "ECap_Loss_Concentrated.csv"
path_out2<- paste( path_out, fileout, sep="/"  )
write.csv(trial_df_conc_all, file = path_out2, row.names=FALSE)
fileout<- "ECap_Loss_Granular.csv"
path_out2<- paste( path_out, fileout, sep="/"  )
write.csv(trial_df_granular_all, file = path_out2, row.names=FALSE)

path_out<- "~/R/Concentration_Risk_Proj/output"
fileout<- "test.csv"
path_out2<- paste( path_out, fileout, sep="/"  )
write.csv(a, file = path_out2, row.names=FALSE)



#======================================================
#============= Run across DUMMY PORTFOLIOS ===============

bank_list<- c('dummy_hhi_2.4_pd_0.5',
              'dummy_hhi_1.65_pd_0.5',
              'dummy_hhi_1.2_pd_0.5',
              'dummy_hhi_0.6_pd_0.5',
              'dummy_hhi_0.3a_pd_0.5',
              'dummy_hhi_0.3b_pd_0.5',
              'dummy_hhi_0.15_pd_0.5')

pd_list<- c(0.005, 0.01, 0.02, 0.04)

#== start run

x11()
start_time <- Sys.time()

n<- length(bank_list)
for (k in 1:n){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  data_adj<- data
  # adjust PD and name
  data_adj$pd<- pd_list[1]
  bank_name<- sub("0.5", pd_list[1]*100,bank_name )  
  
  # method 1: Construct asymptotic portfolio
  data_new<- data_adj
  data_new$exposure<- sum(data_adj$exposure)/nrow(data_adj)
  data_new$exposure_after_exclusions<- sum(data_adj$exposure_after_exclusions)/nrow(data_adj)
  c1<- cumsum(data_adj$exposure_after_exclusions)/sum(data_adj$exposure_after_exclusions)
  c2<- cumsum(data_new$exposure_after_exclusions)/sum(data_new$exposure_after_exclusions)
  plot( c2, type='l',lty=2, main='With exclusions'); lines(c1, lty=1)
  
  # get the portfolio metrics before
  exp_vect<- data_adj$exposure_after_exclusions
  get_prop(exp_vect)
  exp_client30pc_conc<- get_prop(exp_vect)[ 2, 2]
  client_exp50pc_conc<- get_prop(exp_vect)[ 1, 1]
  hhi_conc<- sum(data_adj$exposure_after_exclusions^2) / sum(data_adj$exposure_after_exclusions)^2 * 100  ; hhi_conc
  mean_loss_conc<- sum(data_adj$exposure_after_exclusions * data_adj$pd * data_adj$lgd )/sum(data_adj$exposure_after_exclusions)
  mean_loss_conc
  # after
  exp_vect<- data_new$exposure_after_exclusions
  exp_client30pc_granu<- get_prop(exp_vect)[ 2, 2]
  client_exp50pc_granu<- get_prop(exp_vect)[ 1, 1]
  hhi_granu<- sum(data_new$exposure_after_exclusions^2) / sum(data_new$exposure_after_exclusions)^2 * 100  ; hhi_granu
  mean_loss_granu<- sum(data_new$exposure_after_exclusions * data_new$pd * data_new$lgd )/sum(data_new$exposure_after_exclusions)
  mean_loss_conc
  
  # run Economic Capital
  for (trial in (1:20)){
    set.seed(32+trial)
    out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=40000, conf_level=.999, rho_mult=1.2); out_conc
    out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=40000, conf_level=.999, rho_mult=1.2) ; out_granular
    
    if(trial==1){
      trial_df_conc <- out_conc
      trial_df_granular <- out_granular
      
    }else{
      trial_df_conc<- rbind(trial_df_conc, out_conc)
      trial_df_granular<- rbind(trial_df_granular, out_granular)
    }
    
  }
  # add to the dataframe
  type<- 'concentrated' ; trial_df_conc<-     cbind(bank_name, type, exp_client30pc_conc , client_exp50pc_conc , hhi_conc,  trial_df_conc)
  type<- 'granular' ;     trial_df_granular<- cbind(bank_name, type, exp_client30pc_granu, client_exp50pc_granu, hhi_granu, trial_df_granular)
  
  # aggregate all banks
  if(k==1){
    trial_df_conc_all<- trial_df_conc
    trial_df_granular_all<- trial_df_granular
  }else{
    trial_df_conc_all<- rbind( trial_df_conc_all, trial_df_conc)
    trial_df_granular_all<- rbind( trial_df_granular_all, trial_df_granular) 
  }
  
}

end_time <- Sys.time()
print(end_time-start_time)

# === end run

write.table(trial_df_conc_all, "clipboard", sep="\t")
write.table(trial_df_granular_all, "clipboard", sep="\t")

x<- trial_df_conc_all
y<- trial_df_granular_all



path_out<- "~/R/Concentration_Risk_Proj/output"
fileout<- "ECap_Loss_Concentrated.csv"
path_out2<- paste( path_out, fileout, sep="/"  )
write.csv(trial_df_conc_all, file = path_out2, row.names=FALSE)
fileout<- "ECap_Loss_Granular.csv"
path_out2<- paste( path_out, fileout, sep="/"  )
write.csv(trial_df_granular_all, file = path_out2, row.names=FALSE)


#=============== Dummy portfolio - Plot charts ===============

bank_list<- c('dummy_hhi_2.4_pd_0.5',
              'dummy_hhi_1.65_pd_0.5',
              'dummy_hhi_1.2_pd_0.5',
              'dummy_hhi_0.6_pd_0.5',
              'dummy_hhi_0.3a_pd_0.5',
              'dummy_hhi_0.15_pd_0.5')
x11()
par(mfrow=c(2,3))
n<- length(bank_list)
for (k in 1:n){  
  
  bank_name<- bank_list[k]
  
  # === read the specific file
  file<- paste("/data_", bank_name, ".csv", sep="")
  path2<- paste( path1, file, sep=""  )
  data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
  data_adj<- data
  # adjust PD and name
  data_adj$pd<- pd_list[1]
  bank_name<- sub("0.5", pd_list[1]*100,bank_name )  
  
  # method 1: Construct asymptotic portfolio
  data_new<- data_adj
  data_new$exposure<- sum(data_adj$exposure)/nrow(data_adj)
  data_new$exposure_after_exclusions<- sum(data_adj$exposure_after_exclusions)/nrow(data_adj)
  c1<- cumsum(data_adj$exposure_after_exclusions)/sum(data_adj$exposure_after_exclusions)
  c2<- cumsum(data_new$exposure_after_exclusions)/sum(data_new$exposure_after_exclusions)
  
  # get the portfolio metrics before
  exp_vect<- data_adj$exposure_after_exclusions
  get_prop(exp_vect)
  exp_client30pc_conc<- get_prop(exp_vect)[ 2, 2]
  client_exp50pc_conc<- get_prop(exp_vect)[ 1, 1]
  hhi_conc<- sum(data_adj$exposure_after_exclusions^2) / sum(data_adj$exposure_after_exclusions)^2 * 100  ; hhi_conc
  mean_loss_conc<- sum(data_adj$exposure_after_exclusions * data_adj$pd * data_adj$lgd )/sum(data_adj$exposure_after_exclusions)
  mean_loss_conc
  # plot
  plot( c2, type='l',lty=2, main=paste(round(hhi_conc,2), 'HHI', sep=' ')); lines(c1, lty=1)
  
  row_num<- nrow(data_adj)
  if( k==1){row_num_vect<- row_num}else{row_num_vect<- c( row_num_vect, row_num)}
}




# ======== test confidence interval

conf_vect<- c(.95, .99, .995, .999)

for (trial in (1:5)){
  set.seed(26+trial)
  
  conf<- conf_vect[trial]
  out_conc<- get_EC(excl_flag='yes', data_bank=data_adj, nsimul=20000, conf_level= conf, rho_mult=1)
  out_granular<- get_EC(excl_flag='yes', data_bank=data_new, nsimul=20000, conf_level= conf, rho_mult=1) 
  
  ratio1<- out_conc$QLoss/out_granular$QLoss
  ratio2<- out_conc$evd_av/out_granular$evd_av
  
  if(trial==1){trial_df<- data.frame(conf, ratio1, ratio2)
  }else{
    temp<- data.frame(conf, ratio1, ratio2)
    trial_df<- rbind( trial_df, temp)
  }
  
}





# ===========================================
# ==== test PD sensitivity
x11()
bank_list<- c('ADCB_1', 'ADCB_2', 'ADCB_3', 'ADIB_1', 'ADIB_2', 'DIB', 'ENBD', 'FAB', 'HSBC', 'MASHQ', 'SCB')
bank_name<- 'FAB'
file<- paste("/data_", bank_name, ".csv", sep="")
path2<- paste( path1, file, sep=""  )
data <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
data_adj<- data
data_adj$pd<- min(data$pd * 2, 1)


x11()
temp<- ifelse( data$pd>.2, NA , data$pd)
temp2<- ifelse( data_adj$pd>.2, NA , data_adj$pd)
hist(temp, col='grey')


# get exposure and Pillar1 capital 
exposure_total<- data_overall$exposure[ which(data_overall$bank == bank_name) ]
capital_p1<- data_overall$pillar1_capital[ which(data_overall$bank == bank_name) ]


out_1<- compute_capital_mult(excl_flag='no' ,method ='gordi' , use_exp_total='yes', data_bank= data, exposure_total=exposure_total, capital_p1=capital_p1)

pd_mult<- c( .1, .2 ,.5, 1, 1.2, 1.5, 2, 3)
res<- c(0,0,0,0,0,0,0,0)
for (k in 1:8){
  data_adj<- data
  data_adj$pd<- sapply(data$pd, function(x) min(x*pd_mult[k], 1))
  out_2<- compute_capital_mult(excl_flag='no' ,method ='gordi' , use_exp_total='yes', data_bank= data_adj, exposure_total=exposure_total, capital_p1=capital_p1)
  res[k]<- out_2$capital_mult
}
  
plot(pd_mult, res, 'l', main="Capital multiplier (Gordy's) vs. PD multiplier")
plot(data$pd, data_adj$pd)

