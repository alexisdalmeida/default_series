#============================================================================================
#====================  INTEGRATED Simulation with functions ===============================================

#========== WHOLESALE run =======
setwd("//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Wholesale_Inputs")
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Wholesale_Inputs"
folder<- "C:/Users/006804/Documents/6. Economic Capital/Wholesale"
file1<- "ECap_Input_Wholesale_Port.csv"
file2<- "ECap_Input_Wholesale_Sect_Correl_case3.csv"
file3<- "ECap_Input_LGD_parameters.csv"
file4<- "random_factors.csv"

path<- paste( folder, file1, sep="/"  )
DF_Port <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file2, sep="/"  )
DF_corrmat <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file3, sep="/"  )
DF_LGD_param <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file4, sep="/"  )
DF_rand <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)

#=== remove defaults and compute weighted av====
# Store
DF_Port_Store <- DF_Port  
# Exclude default
DF_Port_nodef <- DF_Port_Store[DF_Port_Store$PD!=1,] # remove PD=1
row_vect<- c(nrow(DF_Port_Store), nrow(DF_Port_nodef))    
EAD_vect<- c(sum(DF_Port_Store$EAD), sum(DF_Port_nodef$EAD))
# Check size and weighted av PD and FLGD
PD_vect<- c( weighted.mean(DF_Port_Store$PD, DF_Port_Store$EAD), weighted.mean(DF_Port_nodef$PD, DF_Port_nodef$EAD))
LGD_vect<- c(weighted.mean(DF_Port_Store$LGD, DF_Port_Store$EAD), weighted.mean(DF_Port_nodef$LGD, DF_Port_nodef$EAD))
acorr_vect<- c(weighted.mean(DF_Port_Store$Asset_Corr, DF_Port_Store$EAD), weighted.mean(DF_Port_nodef$Asset_Corr, DF_Port_nodef$EAD))
# create df
df<- data.frame(c('Full', 'Full no defaults'), row_vect,  EAD_vect, PD_vect, LGD_vect, acorr_vect)
names(df)<- c('Portfolio',"#rows", "w-EAD", "w-PD", "w-LGD" , "w-Corr")
print(df)

# === Sub portoflios analysis
n<- nrow(df)
temp<- data.frame(0,0,0,0,0,0) ; names(temp)<- c('Portfolio',"#rows", "w-EAD", "w-PD", "w-LGD" , "w-Corr")
sub_vect<- unique(DF_Port_nodef$BL_Reporting) ; N<- length(sub_vect)
for (sub_index in 1:N){
  DF_Port_Sub <- DF_Port_nodef[DF_Port_nodef$BL_Reporting == sub_vect[sub_index],] ;  
  sub<- sub_vect[sub_index]
  row<- nrow(DF_Port_Sub)
  ead<- sum(DF_Port_Sub$EAD)
  pd<- weighted.mean(DF_Port_Sub$PD, DF_Port_Sub$EAD)
  lgd<- weighted.mean(DF_Port_Sub$LGD, DF_Port_Sub$EAD)
  acorr<-  weighted.mean(DF_Port_Sub$Asset_Corr, DF_Port_Sub$EAD)
  temp[1,1]<-sub ; temp[1, 2]<-row ; temp[1, 3]<-ead ; temp[1, 4]<-pd ; temp[1, 5]<-lgd  ; temp[1, 6]<-acorr
  df<- rbind(df, temp)
}
print(df)



# == Simulate All wholesale portfolios ==
par(mfrow=c(3,1))
start_time <- Sys.time()
Res_vect <- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c(), QLoss_EVD1=c(), QLoss_EVD2=c(), QLoss_EVD3=c(), trial=c())  
maxpop<- 5000
for (trial in 1:40){
  out<- MainFunction(DF_Port=DF_Port_nodef, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'wholesale', 
                     n=2000, maxpop=maxpop, LGD_simul=TRUE, LGD_floor=0.02 , seed=trial*7, tmarginal=TRUE, dfree=20, mig_simul=TRUE, lossmat_extract = FALSE)
  Res<- out[[2]]                                                             #get the direct quantile
  # get the extreme value estimation
  loss<- sort(out[[3]]) ; evd1<- EVD(loss, .993, .999) ; evd2<- EVD(loss, .994, .999) ;  evd3<- EVD(loss, .995, .999) ; 
  Res<- cbind(Res, evd1, evd2, evd3 , trial) ;  print(Res)                        # bind all 
  Res_vect<- rbind(Res_vect, Res)
}
print(Res_vect)  
end_time <- Sys.time() ; print(end_time-start_time)

# === Extreme Value Distribution - approx of quantile


#cut<- .995 ; alpha<- .999
EVD<- function( loss, cut, alpha){
  q<- quantile(loss,cut)
  excess<- rep(0, length(loss)) ; excess<- sapply( loss, function(x){max(x-q,0)})
  l<- loss[excess!=0] ; e<- excess[excess != 0]
  
  loglike<- function(x){
    beta<- x[1] ; ksi<- x[2]
    ml<- sapply( e, function(x){ -log(beta)-(1+1/ksi)*log(1+x*ksi/beta) })
    return(-sum(ml))
  }
  
  # === test the minimisation function 
  #e<- c(9480, 3589, 3419, 3147, 1965, 1794, 1536, 1386, 1027, 923, 680, 316, 314, 243, 77)
  #out<- optim(par=c(1,0.1) , fn=loglike, method = "L-BFGS-B", lower=c(0.01,0.01), upper=c(300000000,3000000))
  #out$par ;# should be  c(1701,0.148)
  
  #===== 
  out_min<- optim(par=c(1,0.1) , fn=loglike, method = "L-BFGS-B", lower=c(0.01,0.01), upper=c(300000000,3000000))
  beta<- out_min$par[1] ; ksi<- out_min$par[2] ; N<- length(loss) ; n<- length(e)
  var<- as.numeric(q) + beta/ksi * (( (1 - alpha) * N/n)^(-ksi) - 1 )
  return(var)
}

# == Backward Marginal wholesale portfolios ==

start_time <- Sys.time()
Res_vect <- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c(), trial=c()) 
sub_vect<- c('WBG', 'ARM', 'REF','CBB', 'PBG', 'Business Banking' , 'Treasury', 'FI', 'Retail Other', 'IBG', 'Strategic')
N<- length(sub_vect); nsimul<-15000 ; ntrial<- 40 ; maxpop<-50000
loss_sub_vect<- matrix(0, nsimul, N+1)

for (trial in 1:ntrial){
  # Demove defaults
  DF_Port_nodef<- DF_Port_Store[DF_Port_Store$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port_nodef)
  # run the simulation
  out<- MainFunction(DF_Port=DF_Port_nodef, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'wholesale', 
                     n=nsimul, maxpop=maxpop, LGD_simul=TRUE, LGD_floor=0.02 , seed=trial*7, tmarginal=TRUE, dfree=20, mig_simul=TRUE, lossmat_extract=TRUE)
  # extract results for the full portfolio
  Res<- out[[2]] ; Res<- cbind(Res, trial) ;  Res[1]<- 'Full'; print(Res)
  loss_mat<- out[[1]]  ; loss<- out[[3]]
  # check Q for full 
  loss_vect<- apply(loss_mat, 2, sum) ; as.numeric(quantile(loss_vect, .999)) ; as.numeric(Res[5])
  
  # extract a loss vector per sub portfolio
  BL<- DF_Port_nodef$BL_Reporting[1:min(maxpop, nrow(DF_Port_nodef))] #get Business Lines
  loss_sub_vect<- matrix(0, nsimul, N+1)
  loss_sub_vect[ ,N+1 ]<-loss
  for (sub_index in 1:N){
    loss_sub<- loss_mat[ BL== sub_vect[sub_index], ] ; loss_sub_sum<- apply(loss_sub, 2, sum)
    loss_sub_vect[ ,sub_index ]<-loss_sub_sum 
  }
  # check - the sum of the collums is equal to the last collum, i.e. proof of decomposition
  sum(loss_sub_vect[1,1:10]) ; loss_sub_vect[1,11]
  
  # Get metrics for full
  Q_full<- Res[5]; Qpc_full<- Res[6] ; Av_full<- Res[4]
  EAD_full<- DF_Port_nodef$EAD[1:min(maxpop, nrow(DF_Port_nodef))] ;  Res[3] ; sum(EAD_full) 
  
  # Compute the marginal impact
  for (sub_index in 1:N ) {
    # Excluding the sub
    loss_sub_out<- loss_sub_vect[ ,-(N+1) ] #remove last collumn
    loss_sub_out<- loss_sub_out[ ,-sub_index ] #remove one portfolio
    loss_sub_total<- apply(loss_sub_out, 1, sum) 
    Q<- quantile(loss_sub_total, .999) ; Av<- mean(loss_sub_total) #recompute quantiles
    
    EAD_sub<- EAD_full[ BL== sub_vect[sub_index] ] ; sum(EAD_sub)  #get EAD sub
    EAD_out<- sum(EAD_full) - sum(EAD_sub)
    Qpc<- Q/EAD_out # get relative loss %
    
    label<- paste(sub_vect[sub_index], "_excl", sep="")
    Res_sub<- data.frame( label , .999, EAD_out, Av, Q, Qpc , trial ) ; 
    names(Res_sub)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc" , 'trial')
    Res<- rbind(Res, Res_sub)
    
    # marginal
    Av_marg<- Av_full-Av ; Q_marg<- Q_full-Q ; Qpc_marg<- Qpc_full - Qpc
    label<- paste(sub_vect[sub_index], "_marg", sep="") ; Res_sub<- data.frame( label , .999, sum(EAD_sub), Av_marg, Q_marg, Qpc_marg, trial  ) ; 
    names(Res_sub)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc", 'trial' )
    Res<- rbind(Res, Res_sub)
  }
  
  Res_vect<- rbind(Res_vect, Res) ; print(Res_vect)
}
end_time <- Sys.time() ; print(end_time-start_time)



# == Forward Marginal standalone wholesale portfolios ==
start_time <- Sys.time()
Res_vect<- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c()) 
sub_vect<- c('WBG', 'ARM', 'REF','CBB', 'PBG', 'Business Banking' , 'Treasury', 'FI', 'Retail Other', 'IBG', 'Strategic')
DF_Port_nodef<- DF_Port_Store[DF_Port_Store$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port_nodef)
for (sub_index in 1:length(sub_vect) ) {
  DF_Port_Sub_in <- DF_Port_nodef[DF_Port_nodef$BL_Reporting == sub_vect[sub_index],] ;  nrow(DF_Port_Sub_in)
  for (trial in 1:20){
    out<- MainFunction(DF_Port=DF_Port_Sub_in, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'wholesale', 
                       n=5000, maxpop=1000000, LGD_simul=TRUE, LGD_floor=0.02 , seed=trial*5, tmarginal=TRUE, dfree=20, mig_simul=TRUE, lossmat_extract=FALSE)
    Res<- out[[2]] ; Res[1]<- paste(sub_vect[sub_index], "_forward", sep="")
    Res_vect<- rbind(Res_vect, Res)
  }
}
print(Res_vect)
end_time <- Sys.time() ; print(end_time-start_time)

#=====  Concentrated portfolio ========

DF_Port_nodef<- DF_Port_Store[DF_Port_Store$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port_nodef)
# == function to create the variables of a group
creategroup<- function(top_group){ 
  top_group$EAD<- sum(top$EAD) ; 
  top_group$PD<- weighted.mean(top$PD,top$EAD ); top_group$ULGD<- weighted.mean(top$ULGD,top$EAD )
  top_group$LGD<- weighted.mean(top$LGD,top$EAD ) ; top_group$Asset_Corr<- weighted.mean(top$Asset_Corr,top$EAD )
  top_group$dECL<- weighted.mean(top$dECL,top$EAD ) ; top_group$Prob_Migration<- weighted.mean(top$Prob_Migration,top$EAD );top_group$Stage<- 1
  return(top_group)
}
# top1 (strategic) - create
top<- subset(DF_Port_nodef, BL_Reporting == 'Strategic') ; top_group<-  top[1,] ; n1<- nrow(top) ; top_group$Sector<- 'Real_Estate'
top_group_1<- creategroup(top_group ) ; top_group_1$EAD
# top2 - create
top2<- c('90288', '479507', '529035', '622938', '971333') 
top<- DF_Port_nodef[ DF_Port_nodef$RIM %in% top2,] ; top_group<-  top[1,] ; n2<- nrow(top) ; top_group$Sector<- 'Transportation'
top_group_2<- creategroup(top_group )
# top3  - create
top3<- c('147468', '482882')
top<- DF_Port_nodef[ DF_Port_nodef$RIM %in% top3,] ; top_group<-  top[1,]  ; n3<- nrow(top) ; top_group$Sector<- 'Real_Estate'
top_group_3<-creategroup(top_group )
# top4 - create
top4<- c('202197', '550467','554901','596923','602023','625927','632048','651442','653609','656129','357163','7000047')
top<- DF_Port_nodef[ DF_Port_nodef$RIM %in% top4,] ; top_group<-  top[1,]  ; n4<- nrow(top) ; top_group$Sector<- 'Real_Estate'
top_group_4<-creategroup(top_group )
# Remove top2,3,4 from full
topall<- c(top2,top3,top4) 
DF_Port_out<- DF_Port_nodef[ !DF_Port_nodef$RIM %in% topall,] ; nrow(DF_Port_nodef) - nrow(DF_Port_out)
# Add back group2,3,4 to full
DF_Port_Adj_234<- rbind(DF_Port_out, top_group_2, top_group_3, top_group_4 ) ; nrow(DF_Port_Adj_234)
# Remove strategic also
DF_Port_out<- DF_Port_out[ DF_Port_out$BL_Reporting!='Strategic',] ; nrow(DF_Port_out) #first remove strategic
# Add back Strategic and all others to full
DF_Port_Adj_1234<- rbind(DF_Port_out, top_group_1,top_group_2, top_group_3, top_group_4 ) ; nrow(DF_Port_Adj_1234)
# Remove only strategic
DF_Port_out<- DF_Port_nodef[ DF_Port_nodef$BL_Reporting!='Strategic',] ; nrow(DF_Port_out) #first remove strategic
# Add back Strategic to full
DF_Port_Adj_1<- rbind(DF_Port_out, top_group_1 ) ; nrow(DF_Port_Adj_1)

#Check
sum(DF_Port_nodef$EAD) ; sum(DF_Port_Adj_234$EAD) ; sum(DF_Port_Adj_1234$EAD) ; sum(DF_Port_Adj_1$EAD)
nrow(DF_Port_Adj_234) ; nrow(DF_Port_nodef) - (n2+n3+n4) + 3
nrow(DF_Port_Adj_1234) ; nrow(DF_Port_nodef) - (n1+n2+n3+n4) + 4
nrow(DF_Port_Adj_1) ; nrow(DF_Port_nodef) - (n1) + 1

# == Simulate
start_time <- Sys.time()
port_list<- list(DF_Port_Adj_234, DF_Port_Adj_1234, DF_Port_Adj_1)
port_names<- c('group 234', 'group 1234','group 1')
Res_vect <- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c(), trial=c()) 
for (port_index in 1:3){
  DF_Port<- port_list[[port_index]]
  maxpop<- 100000000
  for (trial in 1:50){
    out<- MainFunction(DF_Port=DF_Port, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'wholesale', 
                       n=5000, maxpop=maxpop, LGD_simul=TRUE, LGD_floor=0.02 , seed=trial*6, tmarginal=TRUE, dfree=20, mig_simul=TRUE, lossmat_extract = FALSE)
    Res<- out[[2]] ; Res<- cbind(Res, trial) ; Res[1]<- port_names[port_index]
    Res_vect<- rbind(Res_vect, Res)
  }
}
print(Res_vect) 
end_time <- Sys.time() ; print(end_time-start_time)

#=====


# ==== Write files out

folder<- "//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Wholesale_Results"
fileout<- "ECap_Results.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Res_vect , file = path, row.names=FALSE)
fileout<- "ECap_Loss.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(loss_sub_vect , file = path, row.names=FALSE)




# =======  RETAIL run =======

setwd("//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Retail inputs")
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Retail inputs"
file1<- "ECap_Input_Retail_Port.csv"
file2<- "ECap_Input_Retail_Product_Correl_1.csv"
file3<- "ECap_Input_Retail_LGD_parameters.csv"
path<- paste( folder, file1, sep="/"  )
DF_Port <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file2, sep="/"  )
DF_corrmat <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file3, sep="/"  )
DF_LGD_param <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)

# remove defaults
DF_Port_Store<- DF_Port
DF_Port <- DF_Port[DF_Port$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port) 
#aggregate(DF_Port$LGD, list(DF_Port$Product), FUN = weighted.mean, w=DF_Port$EAD) 


# =====  Run all retail portfolios
start_time <- Sys.time()
Res_vect <- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c(), trial=c())  
for (trial in 1:10){
  out<- MainFunction(DF_Port=DF_Port, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'retail', 
                     n=20, maxpop=100, LGD_simul=FALSE, LGD_floor=0.02 , seed=trial*14, tmarginal=TRUE, dfree=20, mig_simul=TRUE)
  Res<- out[[2]] ; Res<- cbind(Res, trial) ;  print(Res)
  Res_vect<- rbind(Res_vect, Res)
}
print(Res_vect)  
end_time <- Sys.time() ; print(end_time-start_time)


# == Backward MARGINAL retail portfolios ==

start_time <- Sys.time()
Res_vect <- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c(), trial=c()) 
sub_vect<- c('HF', 'AF_EXPAT', 'PF_EXPAT','AF_LOCAL', 'CC_LOCAL', 'PF_LOCAL' , 'CC_EXPAT', 'BBDT0')
N<- length(sub_vect); nsimul<-5000 ; ntrial<- 40 ; maxpop<-50000
loss_sub_vect<- matrix(0, nsimul, N+1)

for (trial in 1:ntrial){
  # Remove defaults
  DF_Port_nodef<- DF_Port_Store[DF_Port_Store$PD!=1,] ; nrow(DF_Port_Store) ; totalrow<- nrow(DF_Port_nodef) ; print (totalrow)
  
  # CUT the portfolio in tranches like a juicy german salami with pepper and berries
  loss_agg_vect<- matrix(0, nsimul, N+1) # final matrix containg the loss vectors of each sub
  #cut<- c(0,20000, 100000, 150000, 200000, 250000, 300000, 350000, totalrow) ;  rowcut<-0
  s<- seq(from = 0, to = totalrow, by = 20000) ; cut<- s; cut[length(s)]<- totalrow
  for (k in 1:(length(cut)-1)){
    start<- cut[k]+1 ; end<- min(cut[k+1] , start+ maxpop-1) ; runrow<- end-start+1
    DF_Port_cut<- DF_Port_nodef[ start : end, ]
    rowcut<- rowcut + nrow(DF_Port_cut) 
    # run the simulation
    out<- MainFunction(DF_Port=DF_Port_cut, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'retail', 
                       n=nsimul, maxpop=maxpop, LGD_simul=FALSE, LGD_floor=0.02 , seed=trial*5, tmarginal=TRUE, dfree=20, mig_simul=TRUE, lossmat_extract=TRUE)
    # extract results for the full portfolio
    loss_mat<- out[[1]]  ; loss<- out[[3]] ; Res<- out[[2]]
    # check Q for full 
    loss_vect<- apply(loss_mat, 2, sum) ; print(paste('Qloss1 ',as.numeric( round(quantile(loss_vect, .999), 0)))) ; print(paste( 'Qloss2 ', round(as.numeric(Res[5]), 0)))
    
    # extract a loss vector per sub portfolio
    BL<- DF_Port_nodef$Product_Reporting[start:end ] #get Business Lines
    loss_sub_vect<- matrix(0, nsimul, N+1) 
    loss_sub_vect[ ,N+1 ]<- loss #allocate the full loss to the last col
    for (sub_index in 1:N){
      loss_sub<- loss_mat[ BL== sub_vect[sub_index], ] ; loss_sub_sum<- apply(loss_sub, 2, sum)
      loss_sub_vect[ ,sub_index ]<- loss_sub_sum 
    }
    # check - the sum of the collums is equal to the last collum, i.e. proof of decomposition
    print(sum(loss_sub_vect[1,1:N])) ;  print(loss_sub_vect[1,N+1])
    # aggregate across cut
    loss_agg_vect<-  loss_agg_vect + loss_sub_vect
    print(paste('Cut #', k, ' with ', runrow, ' rows' , sep=""))
  }
  
  print(rowcut) ; print(totalrow)# check
  # reassign the agg vect in a vector called 'sub vect' for simplicity so that the code is the same for wholesale
  loss_sub_vect<- loss_agg_vect
  print(sum(loss_sub_vect[1,1:N])) ;  print(loss_sub_vect[1,N+1])
  
  # Get metrics for full, ie.all sub-portfolios together
  loss_full<- loss_agg_vect[,N+1]
  Q_full<- quantile(loss_full,.999); Av_full<- mean(loss_full); EAD_full<- DF_Port_nodef$EAD[1:min(rowcut, totalrow)] ; sum(EAD_full) 
  Qpc_full<- Q_full/sum(EAD_full); 
  Res<- data.frame('Full', .999, sum(EAD_full), Av_full, Q_full, Qpc_full, trial) 
  names(Res)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc" , 'trial')
  
  BL<- DF_Port_nodef$Product_Reporting #get Business Lines
  # Compute the marginal impact
  for (sub_index in 1:N ) {
    # Excluding the sub
    loss_sub_out<- loss_sub_vect[ ,-(N+1) ] #remove last collum
    loss_sub_out<- loss_sub_out[ ,-sub_index ] #remove one portfolio
    loss_sub_total<- apply(loss_sub_out, 1, sum) 
    Q<- quantile(loss_sub_total, .999) ; Av<- mean(loss_sub_total) #recompute quantiles
    
    EAD_sub<- EAD_full[ BL== sub_vect[sub_index] ] ; sum(EAD_sub)  #get EAD for the sub
    EAD_out<- sum(EAD_full) - sum(EAD_sub) #get EAD for the total but the sub
    Qpc<- Q/EAD_out # get relative loss %
    
    label<- paste(sub_vect[sub_index], "_excl", sep="")
    Res_sub<- data.frame( label , .999, EAD_out, Av, Q, Qpc , trial ) ; 
    names(Res_sub)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc" , 'trial')
    Res<- rbind(Res, Res_sub)
    
    # marginal
    Av_marg<- Av_full-Av ; Q_marg<- Q_full-Q ; Qpc_marg<- Qpc_full - Qpc
    label<- paste(sub_vect[sub_index], "_marg", sep="") ; Res_sub<- data.frame( label , .999, EAD_out, Av_marg, Q_marg, Qpc_marg, trial  ) ; 
    names(Res_sub)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc", 'trial' )
    Res<- rbind(Res, Res_sub)
  }
  
  Res_vect<- rbind(Res_vect, Res) ; print(Res_vect)
}
end_time <- Sys.time() ; print(end_time-start_time)


# == Forward Standalone Marginal retail portfolios ==
start_time <- Sys.time()
Res_vect<- data.frame(Portolio=c(), QLevel=c(), EAD=c(), MeanLoss=c(), QLoss=c(), Qpc=c()) 
sub_vect<- c('HF', 'AF_EXPAT', 'PF_EXPAT','AF_LOCAL', 'CC_LOCAL', 'PF_LOCAL' , 'CC_EXPAT', 'BBDT0')
for (sub_index in 1:length(sub_vect) ) {
  DF_Port_nodef<- DF_Port_Store[DF_Port_Store$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port_nodef)
  DF_Port_Sub_in <- DF_Port_nodef[DF_Port_nodef$Product_Reporting == sub_vect[sub_index],] ;  nrow(DF_Port_Sub_in)
  for (trial in 1:2){
    out<- MainFunction(DF_Port=DF_Port_Sub_in, DF_LGD_param=DF_LGD_param, DF_corrmat=DF_corrmat, type= 'retail', 
                       n=50, maxpop=100, LGD_simul=FALSE, LGD_floor=0.02 , seed=trial*5, tmarginal=TRUE, dfree=20, mig_simul=TRUE)
    Res<- out[[2]] ; Res[1]<- paste(sub_vect[sub_index], "_forward", sep="")
    Res_vect<- rbind(Res_vect, Res)
  }
}
print(Res_vect)
end_time <- Sys.time() ; print(end_time-start_time)



# == print out
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/ICAAP - Stress Testing - ECap/07. Economic_Capital/4. Credit_Models/1. Simulation/Retail_Results"
fileout<- "ECap_Results_Retail.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Res_vect, file = path, row.names=FALSE)

fileout<- "ECap_LossMat_Retail.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Port_sub_test, file = path, row.names=FALSE)






#==================================================
# =============== FUNCTIONS ======================


# ************ Main function ********
#nsimul<- 1000 ;  maxpop <- 200000 ; LGD_simul<- FALSE ;  LGD_floor<- 0.02 ; type<- 'wholesale'
MainFunction<- function(DF_Port, DF_LGD_param, DF_corrmat, type, n, maxpop, LGD_simul, LGD_floor, seed, tmarginal, dfree, mig_simul, lossmat_extract){
  # key parameters
  
  # data constrution
  idtype<- if( type == 'wholesale'){DF_Port$Sector}else{DF_Port$Product}
  bltype<- if( type == 'wholesale'){DF_Port$BL}
  corrmat<- as.matrix(DF_corrmat[,-1]) 
  PD<- as.numeric(DF_Port$PD)    ; PD[is.na(PD)] <- 0.02
  EAD<- as.numeric(DF_Port$EAD)  ; EAD[is.na(EAD)] <- 1 
  LGD<- as.numeric(DF_Port$LGD)  ; LGD<- sapply( LGD, function(x) max( LGD_floor,min(1,x)))
  ULGD<- DF_Port$ULGD            ; ULGD <- if( is.null(ULGD)==TRUE){ LGD}else{ULGD} ;
  ULGD<- sapply(ULGD, function(x) max( LGD_floor,min(1,x)))
  collcov<- DF_Port$Coll_Cov     ; collcov<- if( is.null(collcov)==TRUE){ rep(0, length(PD))}else{collcov}
  LGDparam<- DF_LGD_param
  asset_corr<- DF_Port$Asset_Corr
  dECL<- DF_Port$dECL ;   stage<- DF_Port$Stage ; PM<- DF_Port$Prob_Migration
  popsize<- nrow(DF_Port)
  
  # systemic factor
  set.seed(seed) ; zsys<- GenCopul(2, nsimul = n, corrmat = corrmat) ;   pairs.panels(zsys)
  # loss generation
  
  loss_list<- SimulateLoss_with_migration ( pd_vect=PD, lgd_vect=LGD, ulgd_vect=ULGD, collcov_vect=collcov, lgd_floor=LGD_floor ,lgd_param=LGDparam,lgd_simul=LGD_simul, 
                                            ead_vect=EAD, assetcorr_vect=asset_corr, id_vect=idtype, bl_vect=bltype, z_mat=zsys, maxpop=maxpop, type=type, tmarginal=tmarginal, dfree=dfree,
                                            decl_vect=dECL, stage_vect=stage, pm_vect=PM, mig_simul=mig_simul, lossmat_extract=lossmat_extract )
  
  # For debugging
  #pd_vect<-PD; lgd_vect<-LGD; ulgd_vect<-ULGD; collcov_vect<-collcov; lgd_param<-LGDparam; lgd_simul <-  LGD_simul 
  #ead_vect<-EAD; assetcorr_vect<-asset_corr; id_vect<-idtype; z_mat<-zsys; maxpop<-maxpop ; LGD_simul<-TRUE ; type<-'wholesale'
  #seed<- 234;n<-5000; dfree<-20 ; tmarginal<-TRUE; mig_simul<-TRUE ; lgd_floor<-0.02 ; mig_simul<-TRUE 
  #decl_vect<- dECL; stage_vect<- stage; pm_vect<-PM;lossmat_extract=TRUE 
  
  # Plot Historgamme
  #h<- hist(loss[1:2000], freq=FALSE, density=10, breaks=40)
  #lines(density(loss,adjust=1), col = 2)
  
  # Compare both methods
  loss<- loss_list[[1]] ; 
  if(lossmat_extract==TRUE ){loss_mat<- loss_list[[2]]; l<- apply(loss_mat,2,sum ); plot(l, loss, main='loss vs sum loss_mat across accounts')} #check
  # Get percentile
  EAD_total = sum(EAD[1: min(maxpop, nrow(DF_Port))  ]      )
  Q<- quantile(loss, .999)  ; Qpc<- Q/EAD_total ; Av<- mean(loss)                         
  Res<- data.frame( type, .999, EAD_total, Av, Q, Qpc  ) ; 
  names(Res)<- c("Portfolio","QLevel", "EAD", "MeanLoss", "QLoss", "Qpc" )
  # Get Accounts contributions
  #Qexact<- sort(loss)[round(nsimul*.999, 0)] ; scen<- which(loss==Qexact); 
  #loss_acc_contrib <- loss_mat[ , scen] #; sum(loss_mat[ , scen]) #check
  
  return(list(loss_mat, Res, loss))  
}


# *************** Function: Generate various Copulas **********
GenCopul<- function(type, nsimul, corrmat){
  L <- t(chol(corrmat)) ; nvariables = dim(L)[1]
  #Simulation of z in one step
  z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) #hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) #; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree) #; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
  # Choose systemic factor
  temp<- list(z_NCop_NMarg, z_TCop_NMarg) ; zsys<- temp[[type]]
  return(zsys)
}


# ***************** LGD Generalissed Beta Regression Model (GBR) ******************
gbr<- function(z, xmean, a2, xstd, plotdist){
  nsimul<- length(z)
  a1<- log(xmean/(1 - xmean))        # (mu is the stressed LGD mean)
  mu <- 1/(  1 + exp(- (a1 + a2 * z ) ) )
  phi<- mu * (1- mu ) /  xstd^2 - 1
  alpha<- phi*mu ; beta<- (1-mu) * phi
  xsimul<- rep(0, nsimul)
  for (j in 1:nsimul){ xsimul[j]<- rbeta(1, alpha[j], beta[j] )} 
  if(plotdist == TRUE){
    xaxis<- z[order(z)] ; yaxis<- xsimul[order(z)] ; plot(xaxis, yaxis, type='l', main='LGD against z values') ; lines(xaxis, rep( mean(xsimul), nsimul), col='2')
    fit<- glm(yaxis ~ xaxis) ; lines(xaxis,fit$fitted.values, col='4'  )
  }
  return(xsimul)
}


#================== simulation with stage migration ================
SimulateLoss_with_migration<- function( pd_vect, lgd_vect, ulgd_vect, collcov_vect, lgd_floor, lgd_param, lgd_simul, 
                                        ead_vect, assetcorr_vect, id_vect, bl_vect, z_mat, maxpop, type, tmarginal, dfree, 
                                        decl_vect, stage_vect, pm_vect, mig_simul, lossmat_extract){   
  #loop through borrowers, scenarios are vectorised
  popsize<- min( length(pd_vect), maxpop) 
  nsimul<- nrow( z_mat)
  loss<- rep(0, nsimul)
  chi<- rchisq(nsimul,dfree) ; tadj<- dfree^0.5 / chi^0.5 
  PD_realised<- rep(0, maxpop) ; PM_realised<- rep(0, maxpop) 
  loss_mat<- matrix( 0, nrow = popsize, ncol = nsimul )
  #DefMat<- matrix( 0, nrow = nsimul, ncol = popsize ) ; LossMat<- DefMat  # for extraction only
  #o<- matrix(0, nrow=popsize, ncol=nsimul )                              # for extraction only 
  loss_nomig<-  rep(0, nsimul) ; loss_ecl<-  rep(0, nsimul)
  
  k<- 0
  for(i in 1 : popsize){
    k<- k+1
    z_vect <- z_mat[, id_vect[i] ]       # get the industry factor
    
    if( lgd_simul == FALSE | lgd_vect[i]>0.95 ){lgd_use<- lgd_vect[i]} else{             # Get the LGD
      if(type == 'wholesale'){ 
        a2<- lgd_param[1 , bl_vect[i]] ; lgd_std<- lgd_param[2 , bl_vect[i]]          # get simulation parameters for wholesale
      }else{a2<- lgd_param[1 , id_vect[i]] ; lgd_std<- lgd_param[2 , id_vect[i]]}
      lgd_rand<- gbr(z_vect, ulgd_vect[i],a2, lgd_std, plotdist = FALSE )                # used the unsecured lgd as mean 
      lgd_use<- (1-collcov_vect[i])* lgd_rand                                           #apply coll coverage
    } 
    
    ead_vect[i]<- max(0, ead_vect[i])       # floor the EAD scaler
    lgd_use<- sapply( lgd_use, function(x) max(x, lgd_floor))    # floor the LGD 
    
    e<- rnorm(nsimul,0,1)                   # Generate idiosyncratic term
    A<-  assetcorr_vect[i]^0.5 * z_vect + (1-assetcorr_vect[i])^0.5 * e
    #== Compute treashold
    if( tmarginal==TRUE){                    # choose normal or T dist
      A<- A * tadj                           # adjust A to get T dist
      d<- qt(pd_vect[i],dfree )              # Compute threshold T
      m<- qt(pm_vect[i], dfree)
    }else{
      d<- qnorm(pd_vect[i], 0,1)             # Compute threshold Norm
      m<- qnorm(pm_vect[i], 0,1)  
    }
    #== Compute loss and migration
    loss<- ifelse( A<= d, loss + ead_vect[i] * lgd_use, loss)
    #loss_nomig<- ifelse( A< d, loss_nomig + ead_vect[i] * lgd_use, loss_nomig)       #for display
    if(mig_simul==TRUE & stage_vect[i]==1 ){
      loss<- ifelse( A> d & A< m, loss + decl_vect[i], loss) 
      #loss_ecl<- ifelse( A> d & A< m, loss_ecl + decl_vect[i], loss_ecl)             #for display
    }
    #==== Compute loss vector for each account
    if(lossmat_extract ==TRUE){
      loss_account<- rep(0, nsimul) ; loss_account_mig<- rep(0, nsimul) #create empty vectors
      loss_account_def<- ifelse( A<= d, ead_vect[i] * lgd_use, 0)
      if(mig_simul==TRUE & stage_vect[i]==1 ){loss_account_mig<- ifelse( A> d & A< m, decl_vect[i], 0)}
      loss_mat[i,]<- loss_account_def + loss_account_mig
    }
    
    #lossT<- ifelse( A< d, lossT + ead_vect[i] * lgd_use, lossT)       # for debug
    #DefMat[,i]<- ifelse( A<d, 1, 0)                                   # for extraction only 
    #LossMat[,i]<- ifelse( A<d,EAD[i]*LGD[i] , 0)                      # for extraction only
    PD_realised[i]<- sum(A<d)/nsimul
    PM_realised[i]<- sum(A<m & A>d)/nsimul
    cat("\r", i, "of", popsize) 
    flush.console()
  }
  
  #a<-apply(loss_mat, 2, sum)
  #b<-data.frame(a,loss) ; sum(b[,1]);sum(b[,2]) #check that both methods leads to the same loss
  
  #par(mfrow=c(2,2))
  plot(pd_vect[1:min(500, popsize)], PD_realised[1:min(500, popsize)], main='Simulated v Input PD', xlab="Input PD", ylab="Simulated PD") 
  lines(pd_vect[1:min(500, popsize)], pd_vect[1:min(500, popsize)] , type='l', col='blue') 
  
  temp<- pm_vect[1:min(500, popsize)] - pd_vect[1:min(500, popsize)]
  temp<- sapply(temp, function(x) max(x,0))
  plot(temp, PM_realised[1:min(500, popsize)], main='Simulated v Input Prob of Migration minus PD', xlab="Input PM-PD", ylab="Simulated PM-PD") 
  lines(temp,temp , type='l', col='blue') 
  
  #plot(density(loss_ecl), main='loss from ECL migration', col='blue')                             # plot dECL dist
  #plot(density(loss_nomig), main='final loss distribution') ; lines(density(loss), col='red')     # plot loss dist
  #legend("topright", lty=c(1,1), col = c("black", "red"), legend = c('no stage migration', 'with stage migration'))
  
  return(list(loss, loss_mat))
}


#======= debug ==
par(mfrow=c(1,1))
plot(density(loss_ecl), main='loss from ECL migration', col='blue')
plot(density(loss_nomig), main='final loss distribution') ; lines(density(loss), col='red')  
legend("topright", lty=c(1,1), col = c("black", "red"), legend = c('no migration', 'with migration'))
lines(density(loss_ecl), col='blue')
q1<- quantile(loss_nomig, .999) ; q2<- quantile(loss, .999)
q1/sum(ead_vect[1:popsize]) ; q2/sum(ead_vect[1:popsize])
l<- apply(loss_mat,2,sum ); plot(l, loss)



#== distributions
par(mfrow=c(1,1))
x<- seq(from = -4, to = 4, by = 0.1)
d1<- dnorm(x, mean = 0, sd = 1, log = FALSE) #density
d2<- dt(x, 60,  log = FALSE) ; d3<- dt(x, 40,  log = FALSE) ; d4<- dt(x, 20,  log = FALSE) ;  d5<- dt(x, 10,  log = FALSE)
plot(d1, type='l') ; lines(d3, col='red') ; lines(d4, col='blue') ; lines(d5, col='green')


# Absolute contribution
pd_vect<- c(0.06, 0.05) ; ead_vect<- c(100, 50) ; lgd_vect<- c(1, 1) ; maxpop<- 1000
popsize<- min( length(pd_vect), maxpop) ; corrmat<- matrix( c(1,0.1, 0.1, 1), 2,2) ; assetcorr_vect<- c(1,1)

vol<- sapply(pd_vect, function(x){ sqrt( x*(1-x)) }) * lgd_vect * ead_vect



for (i in 1: popsize){
  
}

# == Eigen value decomposition
corrmat<- matrix( c(1,0.5, 0.5,0.5,1,0.5,0.5,0.5,1), 3,3) 
e<- eigen(corrmat, symmetric=TRUE, only.values = FALSE, EISPACK = FALSE)
q<- e$values ; d<- e$vectors
q<- matrix( c(q[1],0, 0,0, q[2],0,0,0,q[3]), 3,3  )
d %*% q %*% solve(d)






