
library(xts)
library(quantmod)
library(forecast)
library("tseries", lib.loc="~/R/4. Econometrics")
library("ggplot2", lib.loc="~/R/win-library/3.4")
library(tibble)
library(mvtnorm)
library(Quandl)

#============================================================================================
#====================  WHOLESALE ECap Simulation =======================================================


library(quantmod)
library(forecast)
'library (copula)'
library (ggplot2)
library(psych)
setwd("//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Wholesale inputs")
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Wholesale inputs"
file1<- "ECap_Input_Wholesale_Port.csv"
file2<- "ECap_Input_Wholesale_Sect_Correl_case3.csv"
file3<- "ECap_Input_Wholesale_Asset_Correl_case1.csv"
file4<- "ECap_Input_LGD_parameters.csv"
file5<- "random_factors.csv"

path<- paste( folder, file1, sep="/"  )
DF_Port <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file2, sep="/"  )
DF_Sec_Corr <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file3, sep="/"  )
DF_Asset_Corr <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file4, sep="/"  )
DF_LGD <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file5, sep="/"  )
DF_rand <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)


# === extract parameters: sectorial corr, PD, LGD, EAD
Sec_Corr<- as.matrix(DF_Sec_Corr[,-1]) 
PD_orig<- as.numeric(DF_Port$PD) ; PD_orig[is.na(PD)] <- 0.0175
EAD_orig<- as.numeric(DF_Port$EAD) ; EAD_orig[is.na(EAD)] <- 1
Sector_orig<- DF_Port$Sector
BL<- DF_Port$BL
CollCov<- DF_Port$Coll_Cov
ULGD<- DF_Port$ULGD
FLGD_orig<- as.numeric(DF_Port$LGD_Final)
LGDParam<- DF_LGD
Asset_Corr_orig<- DF_Port$Asset_Corr
PopSize<- nrow(DF_Port)

# === parameters for model validation only
#n<- ncol(Sec_Corr) ; Sec_Corr_Val<- matrix(rep(.3,n*n), n,n)  
#for (i in 1:n){for (j in 1:n){ if(i==j){ Sec_Corr_Val[ i,j ]<- 1} } }
Size<- ncol(DF_rand)-1
PD_Val<- rep(0.05, Size)
LGD_Val<- rep(0.45, Size)
EAD_Val<- rep(1000, Size)
Sector_Val<- rep("Real_Estate", Size)
Asset_Corr_Val<- rep(0.03, Size)

# ************ Main ********
# Generate systemic factor per sector: function 1
set.seed(3) ; zsys<- GenCopul(3) ;   pairs.panels(zsys[,1:4])
# Simulate: function 2 
FLGD_floor<- 0.06
val<-FALSE ; LGD_simul<- TRUE ; maxpop <- 20000
Loss<- Simulate(maxpop)
# Plot Historgamme
h<- hist(Loss, freq=FALSE, density=10, breaks=40)
lines(density(Loss,adjust=1), col = 2)
# Get percentile
TotalEAD = sum(DF_Port$EAD)
Loss_quant<- quantile(Loss, c(.95, .99, .999))  ; Loss_quant_perc<- Loss_quant/TotalEAD
Loss_mean<- mean(Loss)                          ; Loss_mean_perc<-  Loss_mean/TotalEAD
Res<- data.frame( c(.95, .99, .999), TotalEAD, Loss_quant, Loss_quant_perc, Loss_mean ) ; 
print(Res)
# ===Export
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Results"
fileout<- "ECap_Results.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Res , file = path, row.names=FALSE)


# ================= Function: Generate various Copulas=================
GenCopul<- function(CopType){
  par(mfrow = c(1,1))
  L <- t(chol(Sec_Corr))
  nvariables = dim(L)[1]
  nsimul <- 5000
  #Simulation of z in one step
  z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) #hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) #; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree) #; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
  z_TCop_TMarg<- qt(u_copula_T, 10) 
  # Display
  #par(mfrow = c(1,3))
  #plot(z_NCop_NMarg[,4:5]) ; title(main="Normal Copula, Normal Marginal")
  #plot(z_TCop_NMarg[,4:5]) ; title(main="T2 Copula, Normal Marginal")
  #plot(z_TCop_TMarg[,4:5]) ; title(main="T2 Copula, T8 Marginal")
  
  # Choose systemic factor
  temp<- list(z_NCop_NMarg, z_TCop_NMarg, z_TCop_TMarg) ; zsys<- temp[[CopType]]
  return(zsys)
}


# ======  Function Simulation function ======

Simulate<- function(maxpop){   
  # for validation 
  if (val == TRUE ){ PD<- PD_Val ; FLGD<- LGD_Val ; EAD<- EAD_Val; Sector<- Sector_Val ; Asset_Corr<- Asset_Corr_Val
    } else    {PD<- PD_orig ; FLGD<- FLGD_orig ; EAD<- EAD_orig; Sector<- Sector_orig ; Asset_Corr<- Asset_Corr_orig}     
  #loop through borrowers, scenarios are vectorised
  PopSize<- min( nrow(DF_Port), maxpop) 
  if (val == TRUE){PopSize<- length(PD)}
  ULGD_Simul<- rep(0, nsimul)
  Loss<- rep(0, nsimul)
  #DefMat<- matrix( 0, nrow = nsimul, ncol =PopSize ) ; LossMat<- DefMat  # for extraction only
  #o<- matrix(0, nrow=PopSize, ncol=nsimul )                              # for extraction only 
 
  k<- 0
  for(i in 1 : PopSize){
    k<- k+1
    # get the industry factor
    if (val == TRUE){zsys_k<- DF_rand[,1] }else{ IndName<- Sector[i] ; zsys_k<- zsys[,IndName] }
     
    # ======== LGD Generalissed Beta Regression Model (GBR)
    if( LGD_simul == FALSE ){FLGD_use<-FLGD[i]} else{
      # Get parameters
      ULGDmean<- ULGD[i] ; ULGDa1<- log(ULGDmean/(1-ULGDmean)) 
      ULGDa2<- LGDParam[1 , BL[i]] ; ULGDstd<- LGDParam[2 , BL[i]] 
      # Compute (mu is the stressed ULGD mean)
      mu <- 1/(  1 + exp(- (ULGDa1 + ULGDa2 * zsys_k ) ) )
      phi<- mu * (1- mu ) /  ULGDstd^2 - 1
      alpha<- phi*mu ; beta<- (1-mu) * phi
      
      for (j in 1:nsimul){ ULGD_Simul[j]<- rbeta(1, alpha[j], beta[j] )   } 
      FLGD_Simul<- (1-CollCov[i])* ULGD_Simul    ; #o[k,] <- ULGD_Simul #for extraction
      # plot LGD
        #xaxis<- zsys_k[order(zsys_k)] ; yaxis<- ULGD_Simul[order(zsys_k)] ; plot(xaxis, yaxis, type='l') ; lines(xaxis, rep( mean(ULGD_Simul), nsimul), col='2')
        #fit<- glm(yaxis ~ xaxis) ; lines(xaxis,fit$fitted.values, col='4'  )
      FLGD_use<- FLGD_Simul  
      } 
        
    # ======================================
    # Generate idiosyncratic term
    if (val == TRUE){ e<- DF_rand[,1+i] }else{ e<- rnorm(nsimul,0,1)}
    # Compute threshold
    d<- qnorm(PD[i], 0,1) 
    # for model validation only
    "zsys_k<- DF_rand[1] ;  e<- DF_rand[1+i] "
    # Compute default
    FLGD_use<- max( FLGD_use, FLGD_floor)
    A<-  Asset_Corr[i]^0.5 * zsys_k + (1-Asset_Corr[i])^0.5 * e
    Loss<- ifelse( A<d, Loss + EAD[i] * FLGD_use, Loss)
    'DefMat[,i]<- ifelse( A<d, 1, 0)'
    'LossMat[,i]<- ifelse( A<d,EAD[i]*LGD[i] , 0)'
    # display counter
    cat("\r", i, "of", PopSize) 
    flush.console()
  }
  return(Loss)
}


#***********************************************

#============================================================================================
#====================  RETAIL ECap Simulation ===============================================

setwd("//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Retail inputs")
folder<- "C:/Users/DELL/Documents/3. R_code/Ecap"
file1<- "Input.csv"
file2<- "ECap_Input_Retail_Product_Correl.csv"
file3<- "ECap_Input_Retail_LGD_parameters.csv"

path<- paste( folder, file1, sep="/"  )
DF_Port <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file2, sep="/"  )
DF_Prod_Corr <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
path<- paste( folder, file3, sep="/"  )
DF_LGD <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)



# === extract parameters: sectorial corr, PD, LGD, EAD
# Sub-portfolio selection
DF_Port_Store <- DF_Port 
DF_Port <- DF_Port_Store[DF_Port_Store$Product=='PF_LOCAL',] ; nrow(DF_Port_Store) ; nrow(DF_Port)
DF_Port <- DF_Port[DF_Port$PD!=1,] ; nrow(DF_Port_Store) ; nrow(DF_Port)


# Parameters
Prod_Corr<- as.matrix(DF_Prod_Corr[,-1]) 
PD_orig<- as.numeric(DF_Port$PD) ; PD_orig[PD_orig==1] <- 0.95
EAD_orig<- as.numeric(DF_Port$EAD) ; EAD_orig[is.na(EAD_orig)] <- 1
Prod_orig<- DF_Port$Product
FLGD_orig<- as.numeric(DF_Port$LGD) ; plot( FLGD_orig[order(FLGD_orig )])
FLGD_floor<- 0.06 ; FLGD_orig[ FLGD_orig< FLGD_floor]<- FLGD_floor ; plot( FLGD_orig[order(FLGD_orig )], main='Final sorted LGD')
LGDParam<- DF_LGD
Asset_Corr_orig<- DF_Port$Asset_Corr
PopSize<- nrow(DF_Port)
# Check size and weighted av PD and FLGD
length(PD_orig) ; length(EAD_orig) ;length(FLGD_orig) ;length(Asset_Corr_orig)
pr<- PD_orig * EAD_orig ;  sum(pr)/ sum(EAD_orig)
pr<- FLGD_orig * EAD_orig ;  sum(pr)/ sum(EAD_orig)

# === parameters for model validation only
#n<- ncol(Sec_Corr) ; Sec_Corr_Val<- matrix(rep(.3,n*n), n,n)  
#for (i in 1:n){for (j in 1:n){ if(i==j){ Sec_Corr_Val[ i,j ]<- 1} } }
Size<- ncol(DF_rand)-1
PD_Val<- rep(0.05, Size)
LGD_Val<- rep(0.45, Size)
EAD_Val<- rep(1000, Size)
Sector_Val<- rep("Real_Estate", Size)
Asset_Corr_Val<- rep(0.03, Size)

# ************ Main ********
# Generate systemic factor per sector: function 1
set.seed(1) 
z_mat<- GenCopul(type=3, nsimul=1000, corrmat=Prod_Corr)
pairs.panels(z[,1:3])


# Simulate: function 2 

val<-FALSE ; LGD_simul<- TRUE ; maxpop <- 500
Loss<- Simulate(maxpop)
# Plot Historgamme
h<- hist(Loss[1:1000], freq=FALSE, density=10, breaks=40)
lines(density(Loss,adjust=1), col = 2)
# Get percentile
TotalEAD = sum(EAD_orig[1: min(maxpop, nrow(DF_Port))  ]      )
loss_quant<- quantile(loss, c(.95, .99, .999))  ; loss_quant_perc<- loss_quant/TotalEAD
loss_mean<- mean(Loss)                          ; loss_mean_perc<-  loss_mean/TotalEAD
Res<- data.frame( c(.95, .99, .999), TotalEAD, loss_quant, loss_quant_perc, loss_mean ) ; 
print(Res)
# ===Export
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Retail_Results"
fileout<- "ECap_Results_Retail_PF_EXPAT_LGDFlat.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Res , file = path, row.names=FALSE)
#Loss_temp<- Loss

# ================= Function: Generate various Copulas=================

type<-1; nsimul<-1000; corrmat<- Prod_Corr

GenCopul_IS<- function( nsimul, corrmat, shift ){
  L <- t(chol(corrmat)) ; nvariables = dim(L)[1]
  #Simulation of z in two steps
  u<- matrix( runif(nvariables*nsimul, min = 0, max = 1), nrow=nsimul, ncol=nvariables) ; hist(u[,1])
  
  #uh<- matrix( rep(0,nvariables*nsimul ), nrow=nsimul, ncol=nvariables) ; hist(uh[,2])
  #uh<- apply(uh,2,function(x){ halton_vect(nsimul)  } )
  #uh<- apply(uh,2,function(x){ sample(x,nsimul, replace=FALSE)  } )
  
  z<- matrix( qnorm(u, mean = 0, sd = 1), nrow=nsimul, ncol=nvariables) #; hist(z[,1])
  #Simulation of z in one step
  #z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) ;hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr) #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) ; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree) #; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
  # Choose systemic factor
  zsys<- z_TCop_NMarg
  zsys[ , 2:7]<- zsys[,1  ]
  # Extract uncorrelated zsys
  zsys_uncor<- t( solve(L) %*% t(zsys) ) ; cor(zsys_uncor[,2:3]) ; cor(zsys[,1:2])
  # == Variance Adjustment - shift
  zsys_uncor[ , 2:7]<- zsys_uncor[,1  ]
  
  #shift = -1 
  mu<- rep(shift, nrow(corrmat)) #; mu[1]<- shift
  zsys_uncor_shift<- zsys_uncor
  for (row in 1:nsimul){zsys_uncor_shift[row,] <-zsys_uncor[row,]+mu   }
  hist(zsys_uncor[,1], breaks=50, probability=TRUE) ;  lines( density(zsys_uncor_shift[,1]), col='red')
  
  # compute first density f(x)
  p1<- apply (zsys_uncor_shift, 1, function(x){ dmvnorm(x,log = FALSE)})   
  #p1<- apply (zsys_shift, 1, function(x){ dmvt(x,delta= rep(0, nrow(corrmat)),  sigma = corrmat, df = df, log = FALSE)})   
  # compute second density g(x)
  p2<- apply (zsys_uncor_shift, 1, function(x){ dmvnorm(x,mean= mu,  log = FALSE)})    
  plot(  p1[ order(p1)], type='l') ; lines(p2[ order(p2)], col='red')
  plot(  p1[ order(p1)], type='l') ; lines(p2[ order(p1)], col='red')

  # compare for a given scenario
  a<- zsys[,] ; b<- zsys_uncor_shift[699,]
  dmvnorm(b,log = FALSE)
  dmvnorm(b,mean= mu,  log = FALSE)
  
  # likelihood ratio f(x)/g(x)
  lr1<- p1/p2 ; plot(lratio, type='l') ; lr1<- sapply( lr1,  function(x){min(x,200)} ) ; plot(lr1, type='l')
  #compute directly the ratio with close form
  part1<- -t(t(mu)%*%t(zsys_uncor_shift)) ; part2<- t(mu)%*%mu/2 
  lr2<- exp(part1 + rep(part2, length(part1))) ; lr2<- sapply( lr2,  function(x){min(x,200)} ) ; plot(lr2, type='l')
  plot(lr1, lr2)
  # compute prob of scenario
  scen_prob<- lr1/nsimul
  out<- list(zsys, cbind(zsys_shift, scen_prob))
  return(out)
}

zsys1<- GenCopul(type=1, nsimul=1000, corrmat=corrmat, shift=0 )
zsys2<- GenCopul(type=1, nsimul=1000, corrmat=corrmat, shift=-1 )


GenCopul<- function(type, nsimul, corrmat ){
  L <- t(chol(corrmat)) ; nvariables = dim(L)[1]
  #Simulation of z in two steps
  u<- matrix( runif(nvariables*nsimul, min = 0, max = 1), nrow=nsimul, ncol=nvariables) ; hist(u[,1])
  
  z<- matrix( qnorm(u, mean = 0, sd = 1), nrow=nsimul, ncol=nvariables) #; hist(z[,1])
  #Simulation of z in one step
  #z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables) ;hist(z[,1])
  z_corr <- L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
  u_copula_N<- pnorm(z_corr, 0,1) #; pairs.panels(u_copula_N[,1:4])
  # t copula
  dfree<- 3 ; chi<- rchisq(nsimul,dfree) ; hist(chi)
  x_corr<- z_corr * dfree^0.5 / chi^0.5
  u_copula_T<- pt(x_corr, dfree) #; pairs.panels(u_copula_T[,1:4])
  # Apply the marginal distribution to u 
  z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
  z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
  df<-10
  z_TCop_TMarg<- qt(u_copula_T, df) 
  z_NCop_TMarg<- qt(u_copula_N, df)
  # Choose systemic factor
  temp<- list(z_NCop_NMarg, z_TCop_NMarg, z_TCop_TMarg) ; zsys<- temp[[type]]
 
  return(zsys)
}

#========= TRIALS =================

PD<- PD_orig*2 ; LGD<- FLGD_orig ; EAD<- EAD_orig; Sector<- Prod_orig ; Asset_Corr<- Asset_Corr_orig
popsize<- 1000

Q_vect<- matrix(rep(0, 60), 30, 2)
for(trial in 1:30){

loss<- rep(0, nsimul) ; lossT<- rep(0, nsimul) ; lossis<- rep(0, nsimul) ; lossTis<- rep(0, nsimul)
out<- GenCopul_IS(nsimul=5000, corrmat=corrmat, -3 )  
#factormat<- GenCopul(type<-2, nsimul=5000, corrmat=corrmat ) 
factormat<- out[[1]] ; factormat_IS<- out[[2]]
dfree<- 40 ; chi<- rchisq(nsimul,dfree) ; tadj<- dfree^0.5 / chi^0.5 #; hist(chi)

  for(i in 1 : popsize){
      z<- factormat[,1]                  # get the industry factor
      zis<- factormat_IS[,1]
      e<- rnorm(nsimul,0,1)              # Generate idiosyncratic term
      
      # credit factor generation          
      A<-  Asset_Corr[i]^0.5 * z + (1-Asset_Corr[i])^0.5 * e
      AT<- A * tadj 
      #threshold
      d<- qnorm(PD[i], 0,1)
      dT<- qt(PD[i], 40)
      #loss
      loss<- ifelse( A<d, loss + max(0,EAD[i]) * LGD[i], loss)
      lossT<- ifelse( AT<dT, lossT + max(0,EAD[i]) * LGD[i], lossT)
      #========
      # credit factor generation          
      Ais<-  Asset_Corr[i]^0.5 * zis + (1-Asset_Corr[i])^0.5 * e
      ATis<- Ais * tadj 
      #loss
      lossis<- ifelse( Ais<d, lossis + max(0,EAD[i]) * LGD[i], lossis)
      lossTis<- ifelse( ATis<dT, lossTis + max(0,EAD[i]) * LGD[i], lossTis)
 
      cat("\r", i, "of", popsize) 
      flush.console()
  }
  
  hist(loss[1:1000], breaks=20, col='green', probability=TRUE) ; lines(density(lossis[1:1000]), col='red')
  
  Q<- quantile(loss, .999)/sum(EAD[1:popsize]) ; print(Q)
  
  lossis<- cbind(lossis, factormat_IS[,ncol(factormat_IS)]) #create a single datafame
  loss_sort<- lossis[ order(lossis[,1], decreasing = TRUE), ] # sort
  loss_sort<- cbind( loss_sort,  cumsum( loss_sort[,2] ))
  loc<- findInterval(1-.999, loss_sort[,3]) ; l1<- loss_sort[ loc,1];l2<- loss_sort[ loc+1,1]; print(l1);print(l2)
  Qis<- 0.5*(l1+l2)/sum(EAD[1:popsize]) ; print(Qis)
  
  Q_vect[trial, 1]<- Q ; Q_vect[trial, 2]<- Qis
}
barplot(Q_vect[,2]) 
lines(Q_vect[,1], col='red')
plot(Q_vect[,2])


sum(A<d)/nsimul ; sum(AT<dT)/nsimul
quantile(loss, .99) ; quantile(lossT, .99)
par(mfrow = c(2,1))
hist(loss, breaks=50, col='green');hist(lossT, breaks=50, col='blue')
mean(loss) ; mean(lossT)

plot(Q_vect) ; sd(Q_vect)

a<- factormat[,ncol(factormat)]
b<- loss_sort[,2]

Q_vect_MC<- Q_vect ; sd(Q_vect_MC) ; plot(Q_vect_MC)
Q_vect_MCIS<- Q_vect
Q_vect_QMC<- Q_vect; sd(Q_vect_QMC) ; plot(Q_vect_QMC)


#==========================

halton<- function(j, base){
  h<-0
  invbase<- 1/base
  i<-j
  repeat{ 
    digit<- i %% base
    h<- h + digit * invbase
    i<- (i-digit)/ base ; invbase<- invbase / base
    if(i<=0){break}
  }
  return(h)
}

halton_vect<- function(n,base){
  v<- rep(0,  n) ; sim<- 1:n
  v<- sapply(sim , function(x){ halton(x,2)  })
  return(v)
}

a<- halton_vect(100, 2) ; plot(a)




# ======== LGD Generalissed Beta Regression Model (GBR)
gbr<- function(z, xmean, a2, xstd, plotdist){
  nsimul<- length(z)
  a1<- log(xmean/(1 - xmean))        # (mu is the stressed LGD mean)
  mu <- 1/(  1 + exp(- (a1 + a2 * z ) ) )
  phi<- mu * (1- mu ) /  xstd^2 - 1
  alpha<- phi*mu ; beta<- (1-mu) * phi
  xsimul<- rep(0, nsimul)
  for (j in 1:nsimul){ xsimul[j]<- rbeta(1, alpha[j], beta[j] )} 
  if(plotdist == TRUE){
    xaxis<- z[order(z)] ; yaxis<- xsimul[order(z)] ; plot(xaxis, yaxis, type='l') ; lines(xaxis, rep( mean(xsimul), nsimul), col='2')
    fit<- glm(yaxis ~ xaxis) ; lines(xaxis,fit$fitted.values, col='4'  )
  }
  return(xsimul)
}


# ======  Function Simulation function ======
pd_vect<- PD_orig ; lgd_vect<- FLGD_orig ; ead_vect<- EAD_orig  
id_vect<- Prod_orig ; assetcorr_vect<- Asset_Corr_orig ; maxpop<- 500 ; lgd_simul=TRUE ; collcov_vect<- rep(0,length(pd_vect))

loss<- Simulate(pd_vect = PD_orig , lgd_vect = FLGD_orig, collcov_vect = rep(0,length(pd_vect)) ,ead_vect = EAD_orig ,
          assetcorr_vect = Asset_Corr_orig, id_vect =Prod_orig , z_mat = z_mat, maxpop = 500, lgd_simul = FALSE )
quantile(loss, .999)

Simulate<- function( pd_vect, lgd_vect, collcov_vect, ead_vect, assetcorr_vect, id_vect, z_mat, maxpop, lgd_simul ){   
  
  #loop through borrowers, scenarios are vectorised
  popsize<- min( length(pd_vect), maxpop) 
  loss<- rep(0, nsimul)
  #DefMat<- matrix( 0, nrow = nsimul, ncol = PopSize ) ; LossMat<- DefMat  # for extraction only
  #o<- matrix(0, nrow=PopSize, ncol=nsimul )                              # for extraction only 
  
  k<- 0
  for(i in 1 : popsize){
    k<- k+1
    z_vect <- z_mat[, id_vect[i] ]       # get the industry factor
    
    e<- rnorm(nsimul,0,1)              # Generate idiosyncratic term
    d<- qnorm(PD[i], 0,1)              # Compute threshold
    ead_vect[i]<- max(0, ead_vect[i])
    A<-  assetcorr_vect[i]^0.5 * z_vect + (1-assetcorr_vect[i])^0.5 * e
    loss<- ifelse( A<d, loss + max(0,ead_vect[i]) * lgd_use, loss)
    #DefMat[,i]<- ifelse( A<d, 1, 0)                                   # for extraction only 
    #LossMat[,i]<- ifelse( A<d,EAD[i]*LGD[i] , 0)                      # for extraction only

    cat("\r", i, "of", popsize) 
    flush.console()
  }
  
  return(loss)
}



# plot PD vs LGD
xaxis<- zsys_k[order(zsys_k)] ; yaxis<- A[order(zsys_k)] ; plot(xaxis, yaxis, type='l')
zaxis<- FLGD_Simul[order(zsys_k)] ;  plot(zaxis, yaxis, type='l')


#***********************************************
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Wholesale inputs"
fileout<- "LGD_out.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(o , file = path, row.names=FALSE)


#================= model validation
PD<- PD_Val ; LGD<- LGD_Val ; EAD<- EAD_Val; Sector<- Sector_Val ; Asset_Corr<- Asset_Corr_Val
Loss<- rep(0, nsimul)
    for(s in 1 : nsimul){
      #zsys_k<- rnorm(1,0,1)
        zsys_k<- DF_rand[s,1]
        for(i in 1 : PopSize){
          d<- qnorm(PD[i], 0,1) 
          e<- DF_rand[s,1+i]         
          #e<- rnorm(1,0,1)
          A<-  Asset_Corr[i]^0.5 * zsys_k + (1-Asset_Corr[i])^0.5 * e
          Loss[s]<- ifelse( A<d, Loss[s] + EAD[i]*LGD[i], Loss[s])  
        }
    }
   h<- hist(Loss, breaks=40)
   temp<- h$counts

folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Wholesale inputs"
fileout<- "Loss_out.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Loss , file = path, row.names=FALSE)

#insert PD and EAD on top
DefMat<- rbind(  PD, DefMat)
LossMat<- rbind(  EAD, LossMat)
# test distribution of A
shapiro.test(zsys_k) ; shapiro.test(e) ; shapiro.test(A) 
quantile(A, PD[i])

# ======  Analyse of results ======

#== Get Hist
par(mfrow = c(1,1))
h1<- hist(Loss, plot=FALSE, breaks=50)
length(h1$counts)
h1$density = h1$counts/sum(h$counts)
plot(h1, freq=FALSE,density=20 )

# Analytical 
xfit <- h1$breaks ; length(xfit) #seq(min(Loss), max(Loss), length = 42) 
Loss_prop<- xfit/sum(EAD) 
Dist<- pnorm( ( (1-Asset_Corr[1])^0.5 * qnorm(Loss_prop/LGD[1]) - qnorm(PD[1]) ) / Asset_Corr[1]^0.5  )     
Dens<- diff(Dist) ; Dens<- c( Dist[1], Dens) ;  sum(Dens)
lines(xfit, Dens, col = 4) #; plot(xfit, Dens)

#Add original Density adj - bug don't get it
mydensity <- density(Loss)
lines(mydensity$y, col = 2)
multiplier <- h$counts / h$density
mydensity <- density(Loss) ; mydensity$y <- mydensity$y * multiplier[1]
lines(mydensity, col=4)

h<- hist(Loss, freq=FALSE, density=10, breaks=40)
lines(density(Loss,adjust=1), col = 2)


# export dataframe
DensOut<- data.frame( seq(1:42), xfit, h$mids, Loss_prop, h$density, Dist,Dens )

# == Get percentile
TotalEAD = sum(DF_Port$EAD)
Loss_quant<- quantile(Loss, c(.95, .99, .999))  ; Loss_quant_perc<- Loss_quant/TotalEAD
Loss_mean<- mean(Loss)                          ; Loss_mean_perc<-  Loss_mean/TotalEAD


#==================  Analysis of LGD (pivoting and charts) ==============================================

hist(ULGD,freq=FALSE, breaks = 30, density=20)
lines(density(ULGD,adjust=1), col = 2)

hist(FLGD,freq=FALSE, breaks = 50, density=20)
lines(density(FLGD,adjust=1), col = 2)

hist(CollCov,freq=FALSE, breaks = 50, density=20)
lines(density(CollCov,adjust=1), col = 2)

dflgd<- data.frame(ULGD, CollCov,FLGD, EAD, PD )
dflgd<- data.frame(FLGD_orig, EAD_orig, PD_orig )
table(cut(dlgd$CollCov, 10))

#=== test for pivoting ====
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Wholesale inputs"
path<- paste( folder, 'temp.csv', sep="/"  )
df<- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
df1 <- transform(df, group=cut(C2,  breaks=c(-Inf,0.005, 0.010, 0.014, Inf), labels=c('<0.005', 0.005, 0.01, 0.014)))
res <- do.call(data.frame,aggregate(cbind(C1,C3) ~ group, df1, FUN=function(x) c(Count=length(x), Sum=sum(x))))
#==== pivot CollCov ==================
dflgd_cut1 <- transform(dflgd, group=cut(CollCov,  breaks=c(-0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.01 ), labels=c( '0-.1', '.1-.2', '.2-.3','.3-.4','.4-.5','.5-.6','.6-.7','.7-.8','.8-.9', '.9-1')))
dflgd_agg1 <- do.call(data.frame,aggregate( EAD ~ group, dflgd_cut1, FUN=function(x) c(Count=length(x), Sum=sum(x))))
dflgd_agg1$a<- dflgd_agg1$EAD.Count/sum(dflgd_agg1$EAD.Count) ; dflgd_agg1$b<- dflgd_agg1$EAD.Sum/sum(dflgd_agg1$EAD.Sum)

plot(dflgd_agg1$group, dflgd_agg1$b, type='p', col='1', main='Coll Coverage') ; lines( dflgd_agg1$a, type='h', col='2')
legend("topright",  pch = c(1, 1),col = c('1', '2'), legend = c('By EAD', 'By Count'))

barplot(dflgd_agg1$b, names.arg=dflgd_agg1$group, main='Coll Coverage', col=14) 
legend("topright", legend = c('By EAD', 'By Count') , cex = 1.3, fill = c('1','2'))

#============pivot ULGD ================
dflgd_cut2 <- transform(dflgd, group=cut(ULGD,  breaks=c(-0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.01 ), labels=c( '0-.1', '.1-.2', '.2-.3','.3-.4','.4-.5','.5-.6','.6-.7','.7-.8','.8-.9', '.9-1')))
dflgd_agg2 <- do.call(data.frame,aggregate( EAD ~ group, dflgd_cut2, FUN=function(x) c(Count=length(x), Sum=sum(x))))
dflgd_agg2$a<- dflgd_agg2$EAD.Count/sum(dflgd_agg2$EAD.Count) ; dflgd_agg2$b<- dflgd_agg2$EAD.Sum/sum(dflgd_agg2$EAD.Sum)

#========== pivot FLGD =================
dflgd_cut3 <- transform(dflgd, group=cut(FLGD,  breaks=c(-0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.01 ), labels=c( '0-.1', '.1-.2', '.2-.3','.3-.4','.4-.5','.5-.6','.6-.7','.7-.8','.8-.9', '.9-1')))
dflgd_agg3 <- do.call(data.frame,aggregate( EAD ~ group, dflgd_cut3, FUN=function(x) c(Count=length(x), Sum=sum(x))))
dflgd_agg3$a<- dflgd_agg3$EAD.Count/sum(dflgd_agg3$EAD.Count) ; dflgd_agg3$b<- dflgd_agg3$EAD.Sum/sum(dflgd_agg3$EAD.Sum)

#========== final comparison table  =================

# construct a single table
d1<- dflgd_agg1[,c(1,5)] ; d2<- dflgd_agg2[,c(1,5)] ; d3<- dflgd_agg3[,c(1,5)] 
df<- merge(d1, d2, by="group", all.x = TRUE)  ; df<- merge(df, d3, by="group", all.x = TRUE)  ; df[is.na(df)] <- 0 ; df$x<- 1:10

plot(df[,5], df[,3], type='b')
lines(x = df.bar, y = dflgd_agg3$b, col='2') ; points(x = df.bar, y = dflgd_agg3$b, col='2')
Axis()

#============pivot PD ================
dfpd_cut<- transform(dflgd, group=cut(PD_orig, breaks= c( -0.000001, 0.00009,	0.000215,	0.000325,	0.000495	,0.00075,	0.00115	,0.0018,	0.00275,	0.004,	0.0042,	0.0049,	0.0062,	0.00655,	0.00765,	0.01,	0.0175	,0.033,	0.0545,	0.083,	0.125,	0.195	,0.285,	1.00001),
                                  labels=c( 1, 2,	3,	4,5,6,7,8,9,10,11,12,13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23)))
dfpd_agg <- do.call(data.frame,aggregate( EAD_orig ~ group, dfpd_cut, FUN=function(x) c(Count=length(x), Sum=sum(x))))
dflgd_agg4$a<- dflgd_agg2$EAD.Count/sum(dflgd_agg2$EAD.Count) ; dflgd_agg2$b<- dflgd_agg2$EAD.Sum/sum(dflgd_agg2$EAD.Sum)

plot(dfpd_agg$EAD.Count, type='l')


# ========  Export ============
Res<- data.frame( c(.95, .99, .999), TotalEAD, Loss_quant, Loss_quant_perc, Loss_mean )
folder<- "//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/12. Economic_Capital/6. Models/Simulation/Results"
fileout<- "ECap_Results.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(Res , file = path, row.names=FALSE)
fileout<- "DefaultMat.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(DefMat , file = path, row.names=FALSE)
fileout<- "LossMat.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(LossMat , file = path, row.names=FALSE)
fileout<- "AnalyticalDist.csv"
path<- paste( folder, fileout, sep="/"  )
write.csv(DensOut , file = path, row.names=FALSE)



#============================================
# ======  Display two density curves ======
Loss1<- Loss
Loss2<- Loss
h1<- hist(Loss1/1000, freq = TRUE, density=20, breaks=20) #smaller amount for memory purpose
multiplier1 <- h1$counts / h1$density
mydensity1 <- density(Loss1/1000) ; mydensity1$y <- mydensity1$y * multiplier1[1]
lines(mydensity1, col = 2)

h2<- hist(Loss2/1000, freq = TRUE, density=20, breaks=20, plot = FALSE) #smaller amount for memory purpose
multiplier2 <- h2$counts / h2$density
mydensity2 <- density(Loss2/1000) ; mydensity2$y <- mydensity2$y * multiplier1[1]
lines(mydensity2, col = 4)




#=====================================================
# ========== COPULA ANALYSIS ======================

par(mfrow = c(1,1))
'R = matrix(cbind(1,.80,.2,  .80,1,.7,  .2,.7,1),nrow=3)'

L = t(chol(Sec_Corr))
nvariables = dim(L)[1]
nsimul = 1000
set.seed(3)

# Separate the steps
u<- matrix( runif(nvariables*nsimul, min = 0, max = 1), nrow=nsimul, ncol=nvariables); hist(u[,1])
z<- matrix( qnorm(u, mean = 0, sd = 1), nrow=nsimul, ncol=nvariables) ; hist(Z[,1])
plot(u); plot(z)
#Simulation of z in one step
z<- matrix( rnorm(nvariables*nsimul,0,1), nrow=nsimul, ncol=nvariables); hist(Z[,1])
z_corr = L %*% t(z)   ;  z_corr<- t(z_corr)  #t for transpose
u_copula_N<- pnorm(z_corr, 0,1) # here t is transpose

# Display Z and u before and after correlation
par(mfrow = c(1,1))
before_z = as.data.frame(z) ; after_z = as.data.frame(z_corr)
plot(head(before_z[1:4],1000)) 
plot(head(after_z[1:4], 1000))
pairs.panels(after_z[,1:4])
before_u= as.data.frame(u) ; after_u_N = as.data.frame(u_copula_N)
plot(head(before_u[1:4],1000))
plot(head(after_u_N[1:4], 1000))
pairs.panels(after_u_N[1:4])
# t copula
dfree<- 2
chi<- rchisq(nsimul,dfree) ; hist(chi)
x_corr<- z_corr * dfree^0.5 / chi^0.5; pairs.panels(x_corr)
u_copula_T<- pt(x_corr, dfree)
# display t and N copula
before_u = as.data.frame(u) ; after_u_T = as.data.frame(u_copula_T) #t() as transpose
plot(head(before_u[1:4],1000))
plot(head(after_u_T[1:4], 1000))
pairs.panels(after_u_T[,1:4])
par(mfrow = c(1,2))
plot(head(after_u_N[,1:4], 1000))
plot(head(after_u_T[,1:4], 1000))
pairs.panels(after_u_N[,1:4])

#  Apply the marginal distribution to u 
z_NCop_NMarg<- qnorm(u_copula_N,0,1) 
z_TCop_NMarg<- qnorm(u_copula_T,0,1) 
z_TCop_TMarg<- qt(u_copula_T, 10) 
pairs.panels(z_TCop_NMarg[,1:4])
'Final display'
par(mfrow = c(1,3))
plot(z_NCop_NMarg[,2:3]) ; title(main="Normal Copula, Normal Marginal")
plot(z_TCop_NMarg[,2:3]) ; title(main="T2 Copula, Normal Marginal")
plot(z_TCop_TMarg[,2:3]) ; title(main="T2 Copula, T8 Marginal")


# ============== uniform dist functions
dunif(x, min = 0, max = 1, log = FALSE)
punif(q, min = 0, max = 1, lower.tail = TRUE, log.p = FALSE)
qunif(p, min = 0, max = 1, lower.tail = TRUE, log.p = FALSE)
runif(n, min = 0, max = 1)
# normal dist functions
dnorm(1.644854, mean = 0, sd = 1, log = FALSE) #density
pnorm( 1.644854, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)#CDF
qnorm(0.95, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)# N^-1
rnorm(100, mean = 0, sd = 1)
# chisqr dist functions
dchisq(x, df, ncp = 0, log = FALSE)
pchisq(q, df, ncp = 0, lower.tail = TRUE, log.p = FALSE)
qchisq(p, df, ncp = 0, lower.tail = TRUE, log.p = FALSE)
rchisq(n, df, ncp = 0)
# t distr function
dt(x, df, ncp, log = FALSE)
pt(q, df, ncp, lower.tail = TRUE, log.p = FALSE)
qt(p, df, ncp, lower.tail = TRUE, log.p = FALSE)
rt(n, df, ncp)
# beta distr function
dbeta(x, shape1, shape2, ncp = 0, log = FALSE)
pbeta(q, shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE)
qbeta(p, shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE)
rbeta(n, shape1, shape2, ncp = 0)


# === extract asset corr - not used
#Asset_Corr<- c()
#for (i in 1:nrow(DF_Port)) {
#row<- match(DF_Port$New.Sector[i], DF_Asset_Corr[,1]) ; col<- match(DF_Port$New.BL[i], names(DF_Asset_Corr))
#temp<- as.numeric( DF_Asset_Corr[row, col] )
#Asset_Corr<- c(Asset_Corr, temp)
#}
#DF_Port[ , ncol(DF_Port)+1]<- Asset_Corr
#names(DF_Port)[ncol(DF_Port)]<- "Asset.Corr2"

# == data extraction

spy<- getSymbols('SPY', auto.assign=FALSE )
oil_data <- Quandl(code = c("CME/CLH2016", "CME/BZH2016"), type = "xts")
cl_open <- getPrice(oil_data, symbol = "CLH2016", prefer = "Open$")

