library(xts)
install.packages("xts")
library(quantmod)
library(forecast)
library(car)
library(lmtest)
library(data.table)
library(CADFtest)


install.packages("xts", repos="https://cran.ma.imperial.ac.uk/")
library(quantmod)
library(forecast)
library(car)
library(lmtest)
library(data.table)
library(CADFtest)

#********************************************************************************
#************* PART1: FILE CONSTRUCTION  *******************************************************

path1<- "data"

file<- "/macro_v3.2.csv"
path2<- paste( path1, file, sep=""  )
DF <- read.csv(path2, stringsAsFactors=FALSE, check.names = TRUE)
DF$date<- as.Date(DF$date, format='%d/%m/%Y')
#DF$date <- as.Date(DF$date,origin = "1899-12-30")
mdf<- as.xts(DF[,-1], order.by = DF$date)
file<- "/variable_list_v3.csv"
path3<- paste( path1, file, sep=""  )
DF_list <- read.csv(path3, stringsAsFactors=FALSE, check.names = TRUE)
file<- "/defaults_v3.csv"
path4<- paste( path1, file, sep=""  )
DF_def <- read.csv(path4, stringsAsFactors=FALSE, check.names = TRUE)
DF_def$date<- as.Date(DF_def$date, format='%d/%m/%Y')
#DF_def$date<- as.Date(DF_def$date,origin = "1899-12-30")
def<- as.xts(DF_def[,-1], order.by = DF_def$date)

# ========== Returns  ==========
#extract macro, separate between levels and perc
select_level<- DF_list$var_name[DF_list$type == 'level'  ]
m_sub_level<- mdf[,select_level] ; ncol(m_sub_level) ;names(m_sub_level) ; ncol(m_sub_level) # select macro
select_ret<- DF_list$var_name[DF_list$type == 'ret' ]
m_sub_ret<- mdf[,select_ret] ; ncol(m_sub_ret) ; names(m_sub_ret) ; ncol(m_sub_ret)  # select macro
#compute returns on levels
m_ret<- apply(m_sub_level,2,function(x){ Delt(x, k=4, type="arithmetic")}) # compute returns
m_ret<- as.xts(m_ret, order.by = DF$date)
#merge
m_all<- cbind(m_ret, m_sub_ret ) ; names(m_all) ; ncol(m_all)


#========== Final with mid, Up and Down

# == CHOOSE DATES HERE ==
hist_last<-  "2020-12-31" 
fcst_first<- "2021-01-31"
hist_dates<- index(m_all[ paste("/", hist_last, sep="")] )   
fcst_dates<- index(m_all[ paste( fcst_first, "/", sep="")] )

# == history only =====
select<- DF_list$var_name[DF_list$scen =='base' & DF_list$source =='cbuae']
m_past<- m_all[ paste("/", hist_last, sep=""),select ]
names(m_past)<- DF_list$short_name[DF_list$scen =='base' & DF_list$source =='cbuae']
# == IFRS9 mid forecast only =====
#select<- DF_list$var_name[DF_list$scen =='mid' & DF_list$source =='bank']
#m_f_mid<-  m_all[ paste( fcst_first, "/", sep=""), select ]
#names(m_f_mid)<- DF_list$short_name[DF_list$scen =='mid' & DF_list$source =='bank']
# == IFRS9 stress forecast only =====
#select<- DF_list$var_name[DF_list$scen =='down' & DF_list$source =='bank']
#m_f_down<-  m_all[ paste( fcst_first, "/", sep=""), select ]
#names(m_f_down)<- DF_list$short_name[DF_list$scen =='down' & DF_list$source =='bank']
# == IFRS9 up forecast only =====
#select<- DF_list$var_name[DF_list$scen =='up' & DF_list$source =='bank']
#m_f_up<-  m_all[ paste( fcst_first, "/", sep=""), select ]
#names(m_f_up)<- DF_list$short_name[DF_list$scen =='up']
# == CBUAE FSU stress forecast only =====
select<- DF_list$var_name[DF_list$scen =='stress' & DF_list$source =='cbuae']
m_f_cb_stress<-  m_all[ paste( fcst_first, "/", sep=""), select ]
names(m_f_cb_stress)<- DF_list$short_name[DF_list$scen =='stress']
# == CBUAE FSU base forecast only =====
select<- DF_list$var_name[DF_list$scen =='base' & DF_list$source =='cbuae']
m_f_cb_base<-  m_all[ paste( fcst_first, "/", sep=""), select ]
names(m_f_cb_base)<- DF_list$short_name[DF_list$scen =='stress']


# === Final data sets
m_past  # the cbuae
#m_f_mid # the bank
#m_f_down # the bank
#m_f_up # the bank
m_f_cb_stress # cbuae
m_f_cb_base #cbuae


#==Export to test
file<- paste( './output/', "m_all.csv", sep=""  )
write.csv(m_all, file = file, row.names=FALSE)

#= chart
#|dev.off() # this will disable the plot inside the console
# x11()
# source("code/charts.R")
# get_chart( 'ECI' ) 
 # 
 # 
 # m_f_down$ARE_GDP
 # m_f_mid$ARE_GDP
 # m_f_up$ARE_GDP
 # 
 #********************************************************************************
 #************* PART2: INVESTIGATION  *******************************************************
 
# == Chose the default series

 a<-na.omit(def[ ,1 ])
 a_smooth<- rollmean(a, k=3)
 a_smooth<- a_smooth[hist_dates]
 plot(a, col='black', main ='Corporate Default Rates'); lines(a_smooth, col='red', lwd=2)
 Y<- log(a_smooth/(1-a_smooth))
 plot(Y)
 
 #Y<- diff(log(a_smooth/(1-a_smooth)), lag=4)
 #plot(Y)
 
 # == stationarity 
 #par(mfrow=c(2,1))
 plot(Y, main = names(Y))
 addLegend(legend.loc="topright", legend.names=c("Default Rate"), col=c("black"), lty=1:2, cex=0.8, box.lty=1);
 
 acf( na.omit(Y), main = names(Y))
 CADFtest(Y,type = c("none"), max.lag.y = 1, criterion = c("AIC"))
 CADFtest(Y,type = c("drift"), max.lag.y = 1, criterion = c("AIC"))
 CADFtest(Y,type = c("trend"), max.lag.y = 1, criterion = c("AIC"))
 
 
 # === Univariateb
 source("code/univariate.R")
 a<- univariate(d=m_past, Y=Y , pos=FALSE )
 write.table(a, "clipboard", sep="\t", row.names=FALSE)
 
 # =========== MULTIREG =================== 
 
 source("code/multireg.R")
 r<- multireg_simple(univ_sort = a, d=m_past, Y=Y)
 r_sort<- r[order(-r$Rsq_vect),]
 
 # remove positive coef
 r_sort<- r_sort[ -c( which(r_sort$coef_vect1>0), which(r_sort$coef_vect2>0) ),  ]
 r_sort<- r_sort[ -c( which(r_sort$p_vect1>0.15), which(r_sort$p_vect2>0.15)),  ]
 r_sort<- cbind( 1:nrow(r_sort), r_sort)
 
 # === Predict 
 start<- 1 ; end<- min(80, nrow(r_sort)) #model number
 out<- pred_multireg(start=start, end=end, r_sort=r_sort, m_past=m_past, m_f=m_f_cb_stress, 
                     Y=Y, hist_dates = hist_dates, fcst_dates=fcst_dates )
 predicted<- out[[1]] ; 
 fitted<- out[[2]]
 
# plot background chart
 temp<- as.xts(rep(Y[hist_last], length(fcst_dates)   ), fcst_dates)
 Y_temp<- rbind(Y[hist_dates], temp)
 plot(Y_temp, main=names(Y), ylim = c( min(Y), max(predicted, fitted, na.rm=TRUE)), xlim =c('2007-03-31','2024-09-30' ))
 # plot fitted and predicted
 #fitted[ hist_last ,  ]<- Y[hist_last]
 # to adjust
 lines(predicted[ fcst_dates], lwd = 1) ; 
 lines(fitted, col='blue', lwd = 1) 

 # =============== ARIMAX =============== 
 source("code/arimax.R")
 out<- arimax(univ_sort=a, Y=Y, 
              m_past=m_past, m_f=m_f_cb_stress,  hist_dates=hist_dates, 
              fcst_dates=fcst_dates, 
              box_cut=.05, coeff_sign= 'negative', rsq_cut=0.3 , onlyAR1 = FALSE)
 modlist<- out[[1]]; predicted<- out[[2]] ; fitted<- out[[3]]
 

 # plot background chart
 temp<- as.xts(rep(Y[hist_last], length(fcst_dates)   ), fcst_dates)
 Y_temp<- rbind(Y[hist_dates], temp)
 plot(Y_temp, main=names(Y), ylim = c( min(Y), max(predicted, fitted, na.rm=TRUE)), xlim =c('2007-03-31','2024-09-30' ))
 lines(predicted, lwd = 2) ; lines(fitted, col='blue', lwd = 2) ; print(modlist)
 
 #==== macro variables
 
 plot(m_all$real_estate_DB_stress)
 
 path1<- "output"
 file<- "/models.csv"
 path3<- paste( path1, file, sep=""  )
 write.csv( modlist , path3)
 