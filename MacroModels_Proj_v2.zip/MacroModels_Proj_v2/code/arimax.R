
#========== ARIMAX2 with forecast package =================


#arimax(univ_sort=a, Y=Y, m_past=m_past, m_f=m_f_down,  hist_dates=hist_dates, fcst_dates=fcst_dates, box_cut=.05, coeff_sign= 'negative', rsq_cut=0.3 , onlyAR1 = FALSE)

arimax<- function(univ_sort, Y, m_past, m_f,  hist_dates, fcst_dates, box_cut , coeff_sign, rsq_cut, onlyAR1 ){ 
  #create recipients
  
  pred_mat<- as.xts( rep(0, length(fcst_dates)), order.by = fcst_dates) #create recipient
  fitted_mat<- as.xts( rep(0, length(hist_dates)), order.by = hist_dates ) #create recipient

  Res_sort<- univ_sort ; LO<- Y
  Rsq_vect<- c()
  name_vect0<- c() ; name_vect1<- c() ; name_vect2<- c() ; name_vect3<- c()
  Lag_vect0<- c() ; Lag_vect1<- c() ; Lag_vect2<- c() ;  Lag_vect3<- c() ; 
  i_vect<- c() ; j_vect<- c()
  # prepare loop
  n<- max(which(Res_sort$Rsq_vect>rsq_cut)) 
  count<-0 ; count_vect<-c()
  'loop over the first variable'
  for (i in 1:(n-1)) {
    #ID1<- Res_sort$ID_vect[i]
    ID1<- toString(Res_sort$name_vect[i])
    Lag1<-  Res_sort$Lag_vect[i]
    x1<-  m_past[,ID1] ; names(x1) 
    
    'loop over the second variable'
    for (j in (i+1):(n)){
      #ID2<- Res_sort$ID_vect[j]
      ID2<- toString(Res_sort$name_vect[j])
      
      if(ID2!= ID1){ 
        ' == retrieve the second macro variable'
        Lag2<-  Res_sort$Lag_vect[j]
        x2<- m_past[,ID2]
        ' == construct the joined data'
        
        mer<- merge( LO , lag(x1,Lag1), lag(x2, Lag2)) #; plot.xts(lag(x2,4)) ; lines(x2)
        mer<- na.omit(mer) ; xreg<-mer[,2:3]
        
        if( onlyAR1==TRUE){
          fit<- arima(mer[,1], order=c(1,0,0), xreg = xreg)
        }else{fit<- auto.arima(mer[,1], xreg = xreg, max.p=3, max.q=3, max.d=1, max.P=0, max.Q=0, max.D=0)}
        
        #get p value fo the macro variable
        #c<- coeftest(fit)[,4] ; 
        #beta1_p<-  c[length(c)-1] ; beta2_p<- c[length(c)] 
        # get Ljung-Box test p
        b<- Box.test(fit$residuals,type='Ljung', lag=8)
        
        sign<- if(coeff_sign=='positive'){1}else{-1}
        # Proceed if (i) coefs are positives (ii) macro val are significant and (iii) errors are not autocorrelated 
        if ( sign * fit$coef[length(fit$coef)] > 0 & sign * fit$coef[length(fit$coef)-1] > 0 & b$p.value> box_cut) { #& beta1_p<.2 & beta2_p<.2
          count<-count+1 ; count_vect<-c(count_vect, count)
          i_vect<- c(i_vect, i) ; j_vect<- c(j_vect, j)
          name_vect1<- c(name_vect1,ID1 ) ; name_vect2<- c(name_vect2,ID2 ) 
          Lag_vect1<- c(Lag_vect1, Lag1) ; Lag_vect2<- c(Lag_vect2, Lag2) 
          
          # ==== forecast ====
           
          # use model to predict
          x1p<- m_f[,ID1 ]   # here we use x1p to indicate that it is for prediction
          x2p<- m_f[,ID2 ]
          # add history to account for the lag
          rows<- nrow(m_past)
          x1p<- rbind( m_past[ rows:(rows-Lag1) , ID1] , x1p ) 
          x1p<-lag(x1p,Lag1) ; x1p<- x1p[fcst_dates]
          x2p<- rbind( m_past[ rows:(rows-Lag2) , ID2] , x2p ) 
          x2p<-lag(x2p,Lag2) ; x2p<- x2p[fcst_dates]
          # predict
          newdata<- merge(x1p, x2p) ; names(newdata)<- c(ID1, ID2)
          fc<- forecast(fit, xreg = newdata, h=nrow(newdata) ) 
          y_pred<- as.xts(as.numeric(fc$mean), order.by=index(newdata)) 
          y_pred<- rbind(LO[hist_last], y_pred) #add the starting point
          pred_mat<- cbind(pred_mat, y_pred)
          
          # extract fitted
          y_fitted<- as.xts(as.numeric( fit$residuals) + as.numeric(mer[,1]), index(mer) )
          fitted_mat<- cbind(fitted_mat, y_fitted) 
          Rsq<- cor( as.numeric(y_fitted), as.numeric(mer[,1]))^2 ; Rsq_vect<- c(Rsq_vect, Rsq)
        }
      }
    }
    cat("\r", i, "of", n) 
    flush.console()
  }
  
  df_result<- data.frame( rep(names(Y), length(count_vect)), count_vect, Rsq_vect, name_vect1, Lag_vect1 , name_vect2, Lag_vect2)
  pred_mat<- pred_mat[,-1]
  fitted_mat<- fitted_mat[,-1]
  names(pred_mat)<- count_vect 
  names(fitted_mat)<- count_vect
  
  return( list(df_result, pred_mat, fitted_mat))
}





# ===== Percentile check ============
#qt<- data.frame(  .9, .95, .99) ; names(qt)<- c( '90%', '95%', '99%')
#var_name<- c(); mo_select<- m_past[ "2011-01-01/2017-12-01" ]

#n<- 'GDP_base' ; pos<- match(n, names(m_past))
#qt<- rbind( qt, getperc(pos)); var_name<- n
#n<- 'Oil_Brent_base' ; pos<- match(n, names(mo_select))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
#n<- 'Domestic_Demand_base' ; pos<- match(n, names(mo_select))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
#n<-  'Private_Consumption_base' ; pos<- match(n, names(mo_select))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
#n<- 'Import_base' ; pos<- match(n, names(m_past))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
#n<- "Real_Estate_base" ; pos<- match(n, names(mo_select))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)
#n<- "Gov_BaltoGDP_base" ; pos<- match(n, names(mo_select))
#qt<- rbind( qt, getperc(pos)) ; var_name<- c(var_name, n)

#qt<- cbind( var_name, qt[-1,])      

#file<- paste( path1, "Marco_perc_temp.csv", sep=""  )
#write.table(qt, "clipboard", sep="\t", row.names=TRUE, col.names=TRUE)

#getperc<- function (num_macro){
 # a1<- quantile( mo_select[,num_macro], .1, na.rm=TRUE)
#  a2<- quantile( mo_select[,num_macro], .05, na.rm=TRUE)
 # a3<- quantile( mo_select[,num_macro], .01, na.rm=TRUE)
#  row<- c( a1, a2, a3) ; names(row)<- c('90%', '95%', '99%')
 # return(row)
#}
