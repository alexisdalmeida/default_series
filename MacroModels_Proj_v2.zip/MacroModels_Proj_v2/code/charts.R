


get_chart<- function( var ){

  var1<- paste(var, '_mid', sep='')
  var2<- paste(var, '_down', sep='')
  var3<- paste(var, '_up', sep='')
  plot(m_all[,var1], main=var, col='black', lwd=2) ;
  
  temp<- rbind(m_all[ hist_last, var1] ,  m_f_mid[,var] )
  lines(  temp , col='blue', lwd=2) ;
  
  temp<- rbind(m_all[ hist_last, var1] ,  m_f_down[,var] )
  lines( temp, col='red', lwd=2) ;
  
  temp<- rbind(m_all[ hist_last, var1] ,  m_f_up[,var] )
  lines(  temp, col='green', lwd=2);
  
  addLegend(legend.loc="topright", title="Scenarios", legend.names=c("Past", "mid","down", "Up"),
            col=c("black","blue", "red", "green"), lty=1, cex=0.8, box.lty=1);
}

