
setwd("//Fileprintho/Deptfolders/Credir Risk Management/Model Validation/06. Macroeconomics/8. Macro_Models_validation/Stationary")

DF <- read.csv("data/macro.csv", stringsAsFactors=FALSE, check.names = TRUE)

#path1<- "C:/Users/006804/Documents/9. macro_model/"
#path1<- "//Fileprintho/Deptfolders/Credir Risk Management/model validation/06. Macroeconomics/8. Macro_Models_validation/R_code/"
path1<- "data/"
path<- paste( path1, "macro.csv", sep=""  )
DF <- read.csv(path, stringsAsFactors=FALSE, check.names = TRUE)
file<- "variable_list.csv"
path3<- paste( path1, file, sep=""  )
DF_list <- read.csv(path3, stringsAsFactors=FALSE, check.names = TRUE)

# === create macro in xts and #== remove cbuae series
DF$date <- as.Date(DF$date, format = '%d/%m/%Y')
x_xts<- as.xts(DF[,-1], order.by = DF$date)

# focus on moodys plus PD
remove_name<- DF_list$Scenario[which( DF_list$Source=='CBUAE')]
remove_loc<- match( remove_name , names(x_xts))
x_xts<- x_xts[ ,-remove_loc ] 
#get just moody
#get mo_past from the enrichment code


# focus on CBUAE 
remove_name<- DF_list$Scenario[which( DF_list$Source=='Moodys')]
remove_loc<- match( remove_name , names(x_xts))
x_xts<- x_xts[ ,-remove_loc ]
remove_name<- DF_list$Scenario[which( DF_list$Scen_type=='stress')]
remove_loc<- match( remove_name , names(x_xts))
x_xts<- x_xts[ ,-remove_loc ]

#smooth roocupancy occupancy upfront
smooth<- rollmean(na.omit(x_xts$room_occ_AD_base), 4) ; x_xts$room_occ_AD_base[index(smooth)]<-smooth  
smooth<- rollmean(na.omit(x_xts$room_occ_DB_base), 4) ; x_xts$room_occ_DB_base[index(smooth)]<-smooth 
plot(na.omit(x_xts$room_occ_DB_base), main='room_occ_AD' ) ;lines(smooth, col='red')


#===== METHOD2 ===


CADFtest(dx, type = c("none"), max.lag.y = 4, criterion = c("AIC"))
CADFtest(dx, type = c("drift"), max.lag.y = 10, criterion = c("AIC"))
CADFtest(dx, type = c("trend"), max.lag.y = 3, criterion = c("AIC"))
adf.test(dx, k=3)
CADFtest(mer[,2],type = c("none"), max.lag.y = 4, criterion = c("AIC"))



#============== new 2019 CO-integration Moody's ==>  PD


PD_type<- c('LO', 'dLO') ; macro_ret<- c('Q','Y' )
y<- data.frame(def$LC, diff(def$LC, 4) )
h_vect<- c(1,4) 

DF_out<-data.frame(1,2,'Name',1,0,0,0 )
names(DF_out)<- c('PD_type', 'macro_ret', 'macro', 'lag' ,  'p_val', 'model_num', 'integr_order')

count<- 0
for (h in 1:2){  # return horizon loop
  mo<- get_return(mdf= mdf, DF_list = DF_list, horizon = h_vect[h])
  mo_past<- mo[ "/2018-12-01", DF_list$Scenario[ DF_list$Scen_type=='base' ]]
  
  for (type in 1:2){ # PD loop
    for (icol in 1:1){  # macro loop ncol(mo_past)
      y_select<- y[,type] # select PD  
      x_select<- na.omit(mo_past[,icol]) # select macro
      
      for (lag in 0:4){              # lag loop
        x_select_lag<- lag(x_select, lag)
        
        mer<- na.omit( merge(y_select, x_select_lag))
        fit<- lm(mer[,2] ~ mer[,1]) ; err<- as.numeric(fit$residuals)
        out<- ADF_new_2(err)
        
        # export
        DF_temp<- data.frame( PD_type[type], macro_ret[h] ,names(x_select), lag,  out$p_final,out$model_num, out$integr_order )
        names(DF_temp)<- c('PD_type', 'macro_ret', 'macro', 'lag' ,  'p_val', 'model_num', 'integr_order')
        DF_out<- rbind( DF_out  , DF_temp )
      }  
      count<- count+1
      cat("\r", count, "of", 2*2*ncol(mo_past)) 
      flush.console()
    }
  }
  DF_out<- DF_out[-1,]
}



DF_out<- data.frame(name_vect, model_num_vect,integr_order, p_vect  )
DF_out$Y<- 'dLOPD_year'
DF_out$Y<- 'dLOPD'

file<- "out_stationarity.csv"
path<- paste( path1,file, sep=""  )
write.csv(DF_out, file = path, row.names=FALSE)


#============== CO-integration Moody's ==>  PD

n_vect<- c()
p1_vect<- c()  ; order_vect<-c() ; model_num_vect<-c()
p2_mat<- c(0,0,0,0,0,0,0) ; p3_mat<- c(0,0,0,0,0,0,0) 
num_macro<- (ncol(x_xts)-12)
for(k in 1:num_macro){
  x<- na.omit(x_xts["/2017-12-01",k]) ; macro_name<- names(x_xts)[k]
  if( macro_name == 'ECI_base' | macro_name == 'ECI_nonOil_base' ){
    dx<- x #already diff
  }else{
    if(  macro_name != 'Gov_BaltoGDP_base' ){
      dx<- na.omit(diff(x, 4))  #absolute diff
    }else{ dx<- na.omit(Delt(x, k=4, type="arithmetic"))  }
  }
  
  plot(x, main=paste(names(x), '- level')) ; plot(dx, main=paste(names(dx), '- change'))
  #use created function
  out<- ADF_new_2(dx)
  p1_vect<- c(p1_vect, out$p_final) ; order_vect<- c(order_vect, out$integr_order) ; model_num_vect<- c(model_num_vect, out$model_num)
  n_vect<- c(n_vect, names(x))
  
  # compute cointegrated ADF
  #=== loop through PDs
  pd_name<- c(	'AF_6',	'CC_6',	'PF_6',	'HF_6',	'CORP',	'SME',		'REF_NEW')
  
  #p2_vect<- c() 
  p3_vect<- c()
  for( i in 1:length(pd_name)){
    # with PD
    pd<- x_xts[ , pd_name[i]]
    mer<- na.omit(merge(dx, pd))
    
    # === use the cointegration function of CADF.test
    #if( names(x)=='Gov_Balance_base' ){
    #p2<-0
    #}else{
    #a1<- CADFtest(mer[,2], X=mer[ ,1], type = c("none"), max.lag.y = 4, max.lag.X = 1, criterion = c("AIC"))
    #a2<- CADFtest(mer[,2], X=mer[ ,1],type = c("drift"), max.lag.y = 4, max.lag.X = 1, criterion = c("AIC"))
    #a3<- CADFtest(mer[,2], X=mer[ ,1], type = c("trend"), max.lag.y = 4, max.lag.X = 1, criterion = c("AIC"))
    #p2<- min(a1$p.value, a2$p.value, a3$p.value)
    #}
    #p2_vect<- c( p2_vect, p2)
    # === apply it on the residuals
    fit<- lm(mer[,2] ~ mer[,1]) ; err<- as.numeric(fit$residuals)
    out<- ADF_new_2(err)
    p3_vect<- c(p3_vect, out$p_final)
  }
  #===
  #p2_mat<- rbind(p2_mat, p2_vect) 
  p3_mat<- rbind(p3_mat, p3_vect) 
  cat("\r", k, "of", num_macro) 
  flush.console()
} #=======end loop =========

# aggregate
#p2_mat<- p2_mat[-1,] ; row.names(p2_mat)<- n_vect
p3_mat<- p3_mat[-1,] ; row.names(p3_mat)<- n_vect
#df_res<- data.frame(n_vect, p1_vect, order_vect, model_num_vect, p2_mat, p3_mat )
df_res<- data.frame(n_vect, p1_vect, order_vect, model_num_vect, p3_mat )
names(df_res)[5:11]<- pd_name

# print file
file<- paste( path1, "stationary_test_out_method2.csv", sep=""  )
write.csv(df_res, file = file, row.names=FALSE)



#============== CO-integration CBUAE ==> with OTHER MOODYS MACRO

n_vect<- c()
p1_vect<- c()  ; order_vect<-c() ; model_num_vect<-c()
p2_mat<- c(0,0,0,0,0,0,0) ; p3_mat<- c(0,0,0,0,0,0,0) 
num_macro<- (ncol(cb_past))
for(k in 1:num_macro){
  x<- na.omit(cb_past["/2017-12-01",k]) ; macro_name<- names(cb_past)[k]
  #use created function
  dx<-x #already diff
  out<- ADF_new_2(dx)
  p1_vect<- c(p1_vect, out$p_final) ; order_vect<- c(order_vect, out$integr_order) ; model_num_vect<- c(model_num_vect, out$model_num)
  n_vect<- c(n_vect, names(x))
  
  # compute cointegrated ADF
  p3_vect<- c()
  for( i in 1:ncol( mo_past )) {
    mer<- na.omit(merge(dx, mo_past[,i]))
    fit<- lm(mer[,2] ~ mer[,1]) ; err<- as.numeric(fit$residuals)
    out<- ADF_new_2(err)
    p3_vect<- c(p3_vect, out$p_final)
  }
  #===
  p3_mat<- rbind(p3_mat, p3_vect) 
  cat("\r", k, "of", num_macro) 
  flush.console()
} #=======end loop =========

# aggregate
p3_mat<- p3_mat[-1,] ; row.names(p3_mat)<- n_vect
df_res<- data.frame(n_vect, p1_vect, order_vect, model_num_vect, p3_mat )
names(df_res)[5:25]<- names(mo_past)

# print file
file<- paste( path1, "stationary_test_out_method2_moodys_cbuae.csv", sep=""  )
write.csv(df_res, file = file, row.names=FALSE)


#*********************start of function ****************

ADF_new_2<- function( x ){
  
  # =============== Loop through models ======================================
  
  a1<- CADFtest(x, type = c("none"), max.lag.y = 4, criterion = c("AIC"));    s1<- summary(a1)$model.summary
  a2<- CADFtest(x, type = c("drift"), max.lag.y = 4,  criterion = c("AIC")) ; s2<- summary(a2)$model.summary
  a3<- CADFtest(x, type = c("trend"), max.lag.y = 4,  criterion = c("AIC")) ; s3<- summary(a3)$model.summary
  
  dx<- na.omit(diff(x))
  model_num<- 0
  integrated<- 0
  p_final<-0
  # === model3 ======
  
  #if(fit3_tx < model3_cut ){
  if( a3$p.value < .15 ){ 
    # reject H0, phi is not 0, x(t) is I(0), stationary but we need to confirm the model
    if( s3$coefficients[2,4] < .1  ){ #symertrical test 
      #reject H0, beta is not 0 and the model3 is the right one
      model_num<- 3
      integr_order<- 0
    }else{ # accept H0, beta is 0 model 3 is not the right one
      model_num<- 2
      integr_order<- 0
    }
  }else{ 
    #c<- s3$coefficients[1,1] ; c<- as.numeric(rep(c,nrow(dx))) ; 
    #mer<- na.omit(merge( dx, c, lag(dx,1), lag(dx,2))) ; names(mer)<- c('dx', 'c', 'l1', 'l2')
    #fit<- lm(mer$dx ~ mer$c + mer$l1 + mer$l2)
    #SCR3C<- sum( fit$residuals^2  )
    #SCR3<- sum( s3$residuals^2  )
    #F3<- (SCR3C - SCR3)/2 / ( SCR3 /(s3$df[2]-5))
    #if(F3>F3_cut){
    if(s3$coefficients[2,4] < .1){
      #reject H0, c and Beta are not zero, then model 3 is right
      model_num<- 3
      integr_order<- 1
    }else{
      #accept H0, c and Beta are zero, then model 3 is not right
      model_num<- 2
      integr_order<- 1
    }
  }
  
  # === model 2 ====
  if(model_num == 2){
    #if( fit2_tx < model2_cut ){
    if( a2$p.value < .15 ){
      # reject H0, phi is not 0, x(t) is I(0), stationary but we need to confirm the model
      #if( abs(fit2_tc)> qnorm(0.95)  ){ #symertrical test
      if( s2$coefficients[1,4]<.1){
        #reject H0, beta is not 0 and the model 2 is the right one
        model_num<- 2
        integr_order<- 0
      }else{ # accept H0, beta is 0 model 2 is not the right one
        model_num<- 1
        integr_order<- 0
      }
    }else{ 
      #mer<- na.omit(merge( dx, lag(dx,1), lag(dx,2))) ; names(mer)<- c('dx', 'l1', 'l2')
      #fit<- lm(mer$dx ~  mer$l1 + mer$l2)
      #SCR3C<- sum( fit$residuals^2  )
      #SCR2<- sum( s2$residuals^2  )
      #F2<- (SCR2C - SCR2)/2 / (  SCR2/  (s2$df[2]-2))
      #if(F2>F2_cut){
      if( s2$coefficients[1,4] < .1){
        #reject H0, c is not zero, then model 2 right
        model_num<- 2
        integr_order<- 1
      }else{
        #accept H0, c is zero, then model 2 is not right
        model_num<- 1
        integr_order<- 1
      }
    }
  }
  
  # === model 1 ====
  if(model_num == 1){
    
    #if(fit1_tx < model1_cut ){ #smaller than a negative cutoff e.g -5 < -3.5 
    if(a1$p.value < .15 ){ 
      # reject H0, phi is not 0, x(t) is I(0), stationary but we need to confirm the model
      integr_order<- 0
    }else{ 
      # accept H0, phi is 0, x(t) is I(1), not stationary but we need to confirm the model
      integr_order<- 1
    }
  }
  
  p_final<- if(model_num==1){a1$p.value }else{if(model_num==2 ){ a3$p.value   }else{a3$p.value }}
  df_res<- data.frame(integr_order, model_num, p_final )
  return( df_res)
  
} # end of function 

