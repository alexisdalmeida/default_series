
# ============= multireg ====================

multireg_simple<- function(univ_sort, d, Y){    
  Res_sort<- univ_sort ; LO<- Y
  Rsq_vect<- c()
  name_vect0<- c() ; name_vect1<- c() ; name_vect2<- c() ; name_vect3<- c()
  coef_vect0<- c()  ; coef_vect1<- c() ; coef_vect2<- c() ; coef_vect3<- c()
  p_vect0<- c() ; p_vect1<- c() ; p_vect2<- c() ; p_vect3<- c()
  Lag_vect0<- c() ; Lag_vect1<- c() ; Lag_vect2<- c() ;  Lag_vect3<- c() ; 
  ID_vect1<- c() ; ID_vect2<- c()
  
  n<- max(which(Res_sort$Rsq_vect>0.05)) # get the numb of R^2 > 5%
  'loop over the first variable'
  for (i in 1:(n-1)) {
    #ID1<- Res_sort$ID_vect[i]
    ID1<- toString(Res_sort$name_vect[i])
    Lag1<-  Res_sort$Lag_vect[i]
    x1<-  d[,ID1] ; names(x1)
    
    'loop over the second variable'
    for (j in (i+1):(n)){
      #ID2<- Res_sort$ID_vect[j]
      ID2<- toString(Res_sort$name_vect[j])
      
      if(ID2!= ID1){ 
        ' == retrieve the second macro variable'
        Lag2<-  Res_sort$Lag_vect[j]
        x2<- d[,ID2]
        ' == construct the joined data'
        
        mer<- merge( LO , lag(x1,Lag1), lag(x2, Lag2)) #; plot.xts(lag(x2,4)) ; lines(x2)
        mer<- na.omit(mer)
        fit<- lm(mer[,1] ~ mer[,2]+ mer[,3]) 
        s<- summary(fit)
        
        '== Store results'
        ' Extract'
        Rsq<- summary(fit)$r.square 
        
        n0<- 'intercept' ; n1<- ID1 ; n2<- ID2
        
        coef0<- s$coefficients[1,1]
        coef1<- s$coefficients[2,1]
        coef2<- s$coefficients[3,1]
        
        p0<- s$coefficients[1,4]
        p1<- s$coefficients[2,4]
        p2<- s$coefficients[3,4]
        
        '== Store in vectors'
        Rsq_vect<- c(Rsq_vect,Rsq)
        name_vect0<- c(name_vect0,n0)
        name_vect1<- c(name_vect1,n1)
        name_vect2<- c(name_vect2,n2)
        
        coef_vect0<- c(coef_vect0,coef0)
        coef_vect1<- c(coef_vect1,coef1)
        coef_vect2<- c(coef_vect2,coef2)
        
        p_vect0<- c(p_vect0,p0)
        p_vect1<- c(p_vect1,p1)
        p_vect2<- c(p_vect2,p2)
        
        Lag_vect1<- c(Lag_vect1,Lag1) ; Lag_vect2<- c(Lag_vect2,Lag2)
        
      }
    }
    
  }
  Res_mult<- data.frame(Rsq_vect,
                        name_vect0, coef_vect0, p_vect0,
                        name_vect1, coef_vect1, p_vect1, Lag_vect1,
                        name_vect2, coef_vect2, p_vect2, Lag_vect2)
  return(Res_mult)
}



#=== Prediction using multireg ==============

#pred_multireg(start=start, end=end, r_sort=r_sort, m_past=m_past, m_f=m_f_down, Y=Y, hist_dates = hist_dates, fcst_dates=fcst_dates )


pred_multireg<- function(start, end, r_sort, m_past, m_f, Y, hist_dates, fcst_dates ){
  
  pred_mat<- as.xts( rep(0, length(fcst_dates)), order.by = fcst_dates) #create recipient
  fitted_mat<- as.xts( rep(0, length(hist_dates)), order.by = hist_dates ) #create recipient
  
  for (k in start:end){
    #replicate model of choice
    choice<- k
    n1<- toString(r_sort$name_vect1[choice]) ; l1<-r_sort$Lag_vect1[choice]
    n2<- toString(r_sort$name_vect2[choice]) ; l2<- r_sort$Lag_vect2[choice]
    mer<- merge(Y, lag(m_past[,n1], l1), lag(m_past[,n2], l2) ) ; mer<- na.omit(mer)
    names(mer)<- c('y', 'x1', 'x2') ; fit<- lm( y ~ x1+x2, data=mer)
    # use model to predict
    x1<- m_f[,n1 ]
    x2<- m_f[,n2 ]
    # add history to account for the lag
    rows<- nrow(m_past)
    x1<- rbind( m_past[ rows:(rows-l1) , n1] , x1 ) 
    x1<-lag(x1,l1) ; x1<- x1[fcst_dates]
    x2<- rbind( m_past[ rows:(rows-l2) , n2] , x2 ) 
    x2<-lag(x2,l2) ; x2<- x2[fcst_dates]
    # predict
    newdata<- merge(x1, x2) ; names(newdata)<- c('x1', 'x2')
    pred<- predict.lm(fit,newdata=newdata ) 
    pred_xts<- as.xts(pred, order.by = index(x1))
    # extract fitted
    fitted<- lm( mer[,1] ~ mer[,2] + mer[,3])$fitted.values 
    
    # === on on top of background plot
    #lines(mo_stress[, mo_name]) ; lines(pred_xts, col='red', lwd = 2) # plot prediction
    #lines(fitted, col='blue') # plot fitted
    # add to recipient
    pred_mat<- cbind(pred_mat, pred_xts) 
    fitted_mat<- cbind(fitted_mat, fitted) 
  }
  # return a matrix of prediction
  pred_mat<- pred_mat[,-1] ; names(pred_mat)<-start:end
  fitted_mat<- fitted_mat[,-1] ; names(fitted_mat)<- start:end
  return(list( pred_mat, fitted_mat))
}


